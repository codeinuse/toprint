## Summary

[Brief description of changes in this PR]

## Linked Issue

Closes #XXXX

## References

- **Spec:** `docs/specs/XXXX-feature.md`
- **Plan:** `docs/plans/XXXX-feature.md`
- **ADRs:** `docs/research/XXXX-decision.md` (if applicable)

## Type of Change

- [ ] Feature
- [ ] Bug fix
- [ ] Refactor (no behavior change)
- [ ] Documentation
- [ ] Dependency update
- [ ] Hot fix

## Test Results

- [ ] Unit tests: ✅ All passing
- [ ] Integration tests: ✅ All passing
- [ ] Acceptance tests: ✅ All scenarios passing
- [ ] Coverage delta: +X.X% (target: ≥80% for new code)

## Checklist

### Code

- [ ] Follows coding standards in `AGENTS.md`
- [ ] Passes linting and formatting checks (zero warnings)
- [ ] No TODO/FIXME comments in production code
- [ ] No hardcoded secrets or credentials

### Tests

- [ ] All new tests are written (TDD approach followed)
- [ ] All existing tests still pass
- [ ] Coverage meets minimum thresholds
- [ ] Tests are clear and maintainable

### Git

- [ ] Branch is up to date with `main`
- [ ] Conventional commit messages used
- [ ] One commit per plan step (no stray commits)
- [ ] No merge commits in history (rebase-merge only)

### Documentation

- [ ] `CHANGELOG.md` updated (if user-facing changes)
- [ ] API docs updated (if applicable)
- [ ] ADRs in Accepted status (if applicable)
- [ ] Code comments added where necessary (complex logic only)

### Security

- [ ] No new security vulnerabilities introduced
- [ ] Security scan passed (if applicable)
- [ ] Input validation in place (where applicable)
- [ ] No sensitive data in commits

## Implementation Details

[Describe how this was implemented, any trade-offs made, or architectural decisions]

## Known Issues / Limitations

[Any known limitations, incomplete work, or decisions to revisit later]

---

**Note to reviewers:**

1. Verify the plan was followed exactly
2. Check that tests cover the acceptance criteria
3. Review commit messages for clarity and consistency
4. Look for any unintended side effects or regressions
5. Confirm coverage thresholds are met

**Note to agents:**

This PR template is required. All sections must be completed. If a section does not apply, write "N/A" — do not leave sections blank.
