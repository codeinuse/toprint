# Copilot Project Instructions

> Always-on project context for GitHub Copilot. Read automatically for every chat session.
> This is an orientation card — not a replacement for #file:../AGENTS.md which is the **source of truth** for all agent behavior, conventions, and workflows.

---

## Project Overview

This project follows an **agentic SDLC** where coding agents are first-class team members. All work produces durable, versioned Git artifacts — not ephemeral chat.

## Agent Model

Four agents, each with distinct modes. The only hard boundary: **the agent that writes code must not review it.**

| Agent | Modes | Owns |
|-------|-------|------|
| **Discovery** | `research` · `architecture` · `planning` | Problem understanding → solution design → build plan |
| **Builder** | `test-first` · `implement` · `refactor` | TDD loop: failing tests → production code → cleanup |
| **Reviewer** | `code-review` · `security-audit` | Independent quality gate on PRs (cannot approve/merge) |
| **Release** | `documentation` · `deployment` · `monitoring` | Post-merge: docs, deploy, metrics |

Human gates: spec approval, plan approval, PR merge, infrastructure changes.

## Universal Conventions

These apply to **every** agent and mode:

### Commits & Branches
- Conventional commits: `<type>(<scope>): <summary>` — types: `feat`, `fix`, `refactor`, `test`, `docs`, `chore`
- Branch naming: `{type}/{issue-number}-{short-description}`
- Atomic commits: one logical change per commit

### Artifacts Live in Git
- Research → `docs/research/`
- Specs (with structured acceptance criteria) → `docs/specs/`
- ADRs → `docs/research/`
- Plans → `docs/plans/`
- Lessons learned → `tasks/lessons.md`

### Testing
- **Tests are the contract.** TDD workflow: red → green → refactor.
- Unit tests, integration tests, acceptance tests (native test framework).
- Never skip, disable, or `xfail` tests to make CI green.

### Changelog
- Update `CHANGELOG.md` for every user-facing change, during implementation — not after release.

### Escalation Triggers
**Stop and escalate to a human** when:
- Ambiguity in spec or requirements
- Security-sensitive changes (auth, crypto, secrets, permissions)
- Scope exceeds **>10 files** or **>500 lines** net new code
- **3 failed attempts** at fixing an issue
- Uncertainty about the correct approach

## Detailed Guidance

| Topic | Location |
|-------|----------|
| Agent mindset, workflow, coding standards | #file:AGENTS.md |
| Security rules | #file:../rules/security.md |
| Testing standards & TDD | #file:../rules/testing.md |
| Code review checklist | #file:../rules/code-review.md |
| Refactoring patterns & design principles | #file:../rules/REFACTORING.md |
| Writing specs | `.github/skills/write-spec/SKILL.md` |
| Writing plans | `.github/skills/write-plan/SKILL.md` |
| Research & architectural decisions | `.github/skills/research-topic/SKILL.md` |

## Coordination Model

Agents coordinate through **Git artifacts**, not direct messages. Each agent reads the output of the previous phase from committed files. If it isn't committed to Git, it didn't happen.
