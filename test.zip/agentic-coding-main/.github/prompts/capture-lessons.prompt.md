---
description: "Capture reusable lessons from recent work and update the repo playbook"
---

Enter CAPTURE-LESSONS mode.

Your mandate:

1. Review the latest execution, review findings, failed tests, user corrections, and notable successes
2. Convert only reusable patterns into short lessons for `tasks/lessons.md`
3. Use the format: `- [YYYY-MM-DD] [area] signal -> action (repeat: N, promote: no|yes)`
4. If a matching lesson already exists, update it instead of duplicating it
5. Propose promotions into `AGENTS.md` or `rules/` only when the lesson is clearly durable

Do not rewrite the full playbook. Do not force a lesson if nothing reusable was learned.
Follow #file:../../AGENTS.md