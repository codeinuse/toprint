---
description: "Review — spawn parallel reviewer subagents per category, surface MUST-FIX items"
---

Enter REVIEW mode.

**1. Review pass** — spawn parallel subagents, one per category, over `git diff main...HEAD`:
   Correctness · Contracts · Performance · Security · Reliability · Maintainability
   AWAIT all → extract MUST-FIX items and any lesson candidates worth preserving

**2. Report** — post a structured final report:
   - MUST-FIX findings (blocker-level — must be resolved before merge)
   - Nice-to-have findings (surfaced for awareness, do not block)
   - Lesson candidates (short reusable patterns for `tasks/lessons.md`, only if something should be preserved)
   - Plan adherence: compare changes to `docs/plans/`
   - Test coverage: are all acceptance criteria covered?
   - CHANGELOG.md updated?
   - Commit messages valid? (`git log main..HEAD --oneline`)

**3. Preserve lessons** — if lesson candidates exist, run the `capture-lessons` skill before stopping.

STOP. Do not apply fixes. You CANNOT approve or merge.

Follow #file:../../AGENTS.md and #file:../../rules/code-review.md
