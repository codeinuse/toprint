---
description: "Enter deployment mode — ensure CI/CD picks up changes"
---

Enter DEPLOYMENT mode. The PR has been merged. Your mandate:

1. Run `git log --oneline -5` to confirm the merge landed
2. Verify CI/CD pipeline configuration picks up the change and deploys to the appropriate environment
3. Check for test structure changes that require CI workflow updates
4. Review environment variable configuration — ensure nothing is missing or stale
5. Configure deployment pipelines if new services or targets were added
6. Troubleshoot build failures if CI is red

Propose infrastructure or pipeline changes — **do NOT apply without human approval**.
Follow conventions in #file:AGENTS.md.
Do NOT write feature code. Infrastructure and deployment only.

Commit format: `chore(deploy): description`
When done, tell me so I can review infrastructure changes before applying.
