---
description: "Enter documentation mode — update docs after merge"
---

Enter DOCUMENTATION mode. The PR has been merged. Your mandate:

1. Run `git diff main...$(git merge-base main HEAD) --name-only` to identify changed files
2. Update README if user-facing behaviour changed
3. Regenerate API docs if endpoints changed
4. Read `docs/research/INDEX.md` and update it with any new ADRs
5. Verify `CHANGELOG.md` is current and accurate

Follow conventions in #file:../../AGENTS.md
Do NOT write feature code. Documentation only.

Commit format: `docs(scope): update documentation for XXXX`
When done, tell me so I can review.
