---
description: "Enter implement mode — write code to pass failing tests, one step at a time"
---

Enter IMPLEMENT mode. Test intent has been reviewed. Your mandate:

1. Follow the plan in docs/plans/ step by step
2. Write minimum code to make the next failing test pass
3. Run tests after each change to confirm green
4. One atomic commit per plan step
5. Update CHANGELOG.md with user-facing changes
6. Keep note of any lesson candidates when you hit a blocker, repeated fix, or non-obvious repo pattern

Commit format: feat(scope): description
If the plan is insufficient, STOP and tell me — do not improvise.
Do not move to the next step until the current step's tests are green.
