---
description: "Start from a GitHub issue and run the repo workflow until completion or a required human gate"
---

Enter ISSUE-TO-RELEASE mode.

Proceed through the workflow in order and continue automatically until you hit a required human approval point, blocker, or completion:

Use these procedures as you work:

- `task-tracking` for non-trivial issues
- `write-spec` when a spec is needed
- `write-plan` when a plan is needed
- Builder agent for build work
- Code Reviewer agent for review
- Release agent for documentation, deployment, and monitoring follow-up
- `post-change-checklist` after code changes
- `capture-lessons` after subagent work, before handoff, and before compaction when supported

Use 5 parallel subagents in research, planning, build strategy, and review when the work benefits from diversity of thought.

- Give each subagent one clear angle or responsibility.
- After each subagent round, run a critique step: compare outputs, identify convergence/divergence, reject weak ideas, and choose the next path explicitly.
- For build work, do not let 5 subagents edit overlapping files blindly. If ownership is unclear, use them to propose or critique approaches first, then assign isolated subtasks or choose one path.
- The parent agent merges results and runs `capture-lessons` if reusable patterns emerged.

1. Intake — run `task-tracking`, then read the issue plus `AGENTS.md`, relevant `rules/`, and `tasks/lessons.md`
2. Research — investigate affected code, risks, dependencies, and unknowns; prefer 5 focused subagents with different angles, then run a critique step and synthesize one direction
3. Spec — use `write-spec`, then write or update a spec in `docs/specs/`
4. Plan — use `write-plan`, then use 5 planning subagents with different planning priorities, run a critique step, and write one implementation plan in `docs/plans/`
5. Human gates — stop only when the spec or plan requires human approval
6. Build — use the Builder agent, use 5 builder subagents for approach diversity or isolated subtasks, run a critique step after each round, then execute the chosen path, update `CHANGELOG.md`, and run `post-change-checklist`
7. Review — use the Code Reviewer agent, spawn 5 reviewer subagents, run a critique step, and separate must-fix from nice-to-have findings
8. Capture lessons — run `capture-lessons`, update `tasks/lessons.md`, and promote durable patterns into `AGENTS.md` or `rules/`
9. Finish — fix must-fix findings, repeat review as needed, then use the Release agent to update docs and release artifacts and report what changed

Keep artifacts in Git. Do not skip human approval points. Stop and escalate on ambiguity, security-sensitive changes, repeated failure, or scope overrun.
Follow #file:../../AGENTS.md