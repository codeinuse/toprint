---
description: "Enter refactor mode — clean up code without changing behaviour"
---

Enter REFACTOR mode. All tests are green. Your mandate:

1. Run the full test suite to confirm green — do not proceed if any test fails
2. Identify refactoring opportunities: improve naming, extract abstractions, reduce duplication
3. Apply one refactoring at a time — run tests after each change
4. Refactoring must NOT change observable behaviour or break any passing test
5. Follow patterns and size limits in #file:rules/REFACTORING.md: Extract Method, Compose Method, Replace Magic Numbers, Introduce Parameter Object
6. Audit for dead code after extractions — remove unused types, orphaned imports, test-only functions

Commit format: refactor(scope): description
Do NOT add new features or change public API contracts.
When done, tell me so I can review the refactored code.
