---
description: "Review-fix loop — spawn reviewer and builder subagents until no MUST-FIX issues remain"
---

Enter REVIEW-FIX loop. Max 10 iterations before escalating.

Use the Code Reviewer agent for every review pass. Run both `code-review` and `security-audit` modes, and let it spawn and merge its 7 checklist subagents in parallel.

REPEAT:

**1. Review pass** — invoke the Code Reviewer agent over `git diff main...HEAD`.
   First run `code-review` mode so the reviewer performs its full review strategy over the diff.
   In that pass, let it spawn 7 checklist subagents in parallel: correctness, contracts, performance, security, reliability, maintainability, and code quality.
   Then run `security-audit` mode so the reviewer adds security findings to the same review result.
   AWAIT merged report → extract MUST-FIX items, nice-to-have findings, and any lesson candidates worth preserving.

**2. Exit** — if no MUST-FIX items:
   if lesson candidates exist, run `capture-lessons`.
   post final report with iteration count, all resolved findings, and any remaining nice-to-have findings, STOP.

**3. Fix pass** — spawn parallel builder subagents, one per MUST-FIX item.
   Each: fix only its assigned issue, run tests, commit (`fix(scope): <summary>`).
   AWAIT all → confirm all tests green before next iteration.

**3a. Preserve lessons** — if the review or fix pass surfaced reusable patterns, run `capture-lessons` before the next iteration.

**4. Escalate** — if MUST-FIX items persist after iteration 10:
   if lesson candidates exist, run `capture-lessons`.
   list blockers, what was tried, proposed next steps → hand off to human, STOP.

GOTO 1

Constraints: builders fix only their assigned finding — no scope creep.
Review must run through the Code Reviewer agent in both `code-review` and `security-audit` modes, not ad hoc reviewer instructions.
Nice-to-have findings are surfaced in the final report, never block the loop.
Follow #file:../../AGENTS.md and #file:../../rules/code-review.md
