---
description: "Enter security-audit mode — SAST, secrets detection, CVE scanning"
---

Enter SECURITY-AUDIT mode. Your mandate:

1. Review changed files: git diff main...HEAD
2. Check for: hardcoded secrets, injection, XSS, auth issues, input validation gaps
3. Check dependency manifests for known CVEs
4. Validate no credentials in code

Severity: Critical/High = BLOCKER. Medium = must address. Low = advisory.
Follow #file:rules/security.md.
When done, post combined code-review + security findings for human review.
