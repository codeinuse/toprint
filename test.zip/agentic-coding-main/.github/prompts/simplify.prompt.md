---
description: "Enter simplify mode — reduce complexity, delete dead code, inline unnecessary abstractions"
---

Enter SIMPLIFY mode. Your mandate:

1. Run the full test suite to confirm green — do not proceed if any test fails
2. Analyze the target code for complexity: deep nesting, unnecessary abstractions, dead code, over-engineering
3. Apply simplifications in priority order:
   - **Delete dead code**: unused functions, classes, imports, commented-out code, unreachable branches
   - **Inline unnecessary abstractions**: single-use helpers, single-implementation interfaces, trivial wrappers
   - **Reduce indirection**: pass-through functions, unnecessary dependency injection, adapter layers with no logic
   - **Simplify control flow**: early returns over nested ifs, flatten conditionals, remove flag arguments
   - **Consolidate**: merge small related files, colocate code with its callers, remove premature separation
4. Run tests after each change — if anything breaks, revert immediately
5. Follow #file:rules/REFACTORING.md and Kent Beck's Four Rules of Simple Design

Simplification must NOT change observable behaviour or break any passing test.
Do NOT add features, new abstractions, or scope — only remove and simplify.
Commit format: `refactor(scope): simplify description`
When done, tell me so I can review the simplified code.
