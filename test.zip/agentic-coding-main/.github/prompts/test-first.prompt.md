---
description: "Enter test-first mode — write failing tests from spec"
---

Enter TEST-FIRST mode. The plan has been approved. Your mandate:

1. Read the approved spec (Gherkin acceptance criteria) and plan
2. Write .feature files with all scenarios
3. Write step definition stubs
4. Write unit test stubs for expected functions/modules

All tests MUST FAIL — there is no implementation yet.
Commit: test(scope): scaffold failing tests for XXXX
Do NOT write production code.
When done, tell me so I can review test intent before implementation.
