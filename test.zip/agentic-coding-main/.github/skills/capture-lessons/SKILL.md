---
name: capture-lessons
description: "Capture short reusable lessons from recent work, reviews, failures, and subagent output before handoff or compaction."
---

# Capture Lessons

## Trigger

Invoke this skill when:
- Finishing a meaningful task or subtask
- A review finds reusable problems or patterns
- The user corrects the approach
- A subagent returns findings worth preserving
- Before handing off context or ending a long session
- Before context compaction if the host supports a pre-compaction hook

Do NOT invoke for: trivial edits with no reusable lesson, raw brainstorming, or one-off noise with no future value.

## Inputs

1. **Recent signals** — failed tests, review findings, user corrections, incidents, notable successes
2. **Subagent output** — if subagents were used, their final findings or summaries
3. **Current lessons** — existing entries in `tasks/lessons.md`

## Steps

1. Review recent signals and isolate what is reusable
2. Convert each reusable pattern into a one-line lesson: `signal -> action`
3. Assign metadata:
   - **confidence**: L (observed once) / M (2–3 times) / H (proven pattern)
   - **scope**: repo (project-specific) / global (applies everywhere)
4. Update `tasks/lessons.md` using the repo format:
   `- [YYYY-MM-DD] [area] signal -> action (repeat: N, confidence: L|M|H, scope: repo|global, promote: no|yes)`
5. If a lesson already exists, increment `repeat` and upgrade `confidence` if evidence warrants
6. Set `promote: yes` only when confidence is **H** and the lesson is clearly repo-wide
7. If subagents were used, the parent agent curates their output — subagents do not directly rewrite the repo playbook

## Output

- Updated `tasks/lessons.md`, or
- An explicit statement that no reusable lesson was found

## Verification

Before marking complete:
- [ ] Lessons are short and reusable, not case-study narratives
- [ ] Duplicate lessons were merged instead of appended
- [ ] Promotion is proposed only for durable conventions
- [ ] If a handoff or compaction is about to happen, the useful lessons were captured first