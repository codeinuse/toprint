---
name: iterative-retrieval
description: "Progressive context retrieval for subagents — solve the 'what files do I need?' problem with a search-evaluate-refine loop."
---

# Iterative Retrieval

## Trigger

Invoke this pattern when:
- A subagent needs codebase context it **cannot predict upfront**
- Initial search returns too much noise or misses key files
- The codebase uses terminology the agent hasn't encountered yet
- A task requires understanding **cross-cutting concerns** across modules

Do NOT use for: tasks where the relevant files are already known, trivial single-file edits, pure documentation work.

## The Problem

Subagents are spawned with limited context. Standard approaches fail:
- **Send everything** — exceeds context limits, drowns the signal
- **Send nothing** — agent lacks critical information
- **Guess what's needed** — often wrong, especially in unfamiliar codebases

## Steps

Run a **search → evaluate → refine** loop, max 3 cycles:

### Cycle 1: Broad Discovery

1. Start with **high-level keywords** from the task description
2. Search broadly: `grep`, `file_search`, `semantic_search` across likely directories
3. Score each result for relevance (High / Medium / Low / None)
4. Note **codebase terminology** — the project may use different names than expected

### Cycle 2: Targeted Refinement

1. **Add discovered terms** — if the codebase says "throttle" not "rate-limit", search for "throttle"
2. **Follow imports** — high-relevance files import dependencies worth reading
3. **Exclude confirmed noise** — drop files scored Low/None
4. Check: do we have **≥3 high-relevance files** covering the task? If yes, stop.

### Cycle 3: Gap Filling (if needed)

1. Identify **specific gaps** — e.g., "found the handler but not the data model"
2. Target those gaps with precise searches
3. Accept "good enough" — 3 high-relevance files beats 10 mediocre ones

## Relevance Scoring

| Score | Meaning | Action |
|-------|---------|--------|
| **High** (0.8–1.0) | Directly implements target functionality | Include |
| **Medium** (0.5–0.7) | Contains related types, patterns, interfaces | Include if needed |
| **Low** (0.2–0.4) | Tangentially related | Exclude |
| **None** (0–0.2) | Not relevant | Exclude and add to exclusion list |

## Worked Example

**Task:** "Fix the authentication token expiry bug"

```
Cycle 1 — Broad Discovery:
  Search: "token", "auth", "expiry" in src/**
  Results:
    auth.ts          → High (0.9) — contains token validation logic
    tokens.ts        → High (0.8) — token creation and refresh
    user-model.ts    → Low (0.3)  — user data, no token logic
    config.ts        → None (0.1) — app config, unrelated
  Terminology learned: project uses "refresh" not "renew"

Cycle 2 — Targeted Refinement:
  Search: "refresh", "jwt", "session" (terms from Cycle 1)
  Exclude: user-model.ts, config.ts
  Results:
    session-manager.ts → High (0.95) — manages token lifecycle
    jwt-utils.ts       → High (0.85) — JWT encode/decode/verify
  Check: 4 high-relevance files ✓ → STOP

Final context: auth.ts, tokens.ts, session-manager.ts, jwt-utils.ts
```

## Integration with Agent Prompts

When spawning a subagent, include this instruction:

```
Before implementing, gather context using the iterative-retrieval pattern:
1. Search broadly for keywords related to the task
2. Score results: High (include) / Medium (maybe) / Low-None (exclude)
3. Refine search terms based on codebase terminology
4. Stop when you have ≥3 high-relevance files or after 3 cycles
```

## Verification

Before marking retrieval complete:
- [ ] At least 3 high-relevance files identified
- [ ] Codebase terminology discovered and used in searches
- [ ] No more than 3 search cycles executed
- [ ] Low/None results excluded — context is signal-rich, not noisy
