---
name: mode-contexts
description: "Lightweight behavior overlays for different working modes — dev, review, research. Load the right context for the right task."
---

# Mode Contexts

## Trigger

Invoke this skill when:
- Switching between **development**, **review**, and **research** modes within a session
- A subagent needs a **focused behavioral profile** for its task
- The agent is doing the wrong type of work (e.g., over-explaining during implementation, or coding during research)

Do NOT invoke for: single-purpose tasks where the mode is obvious.

## The Problem

Agents perform differently depending on the mode. A development session needs "code first, explain after." A review session needs "read thoroughly before commenting." Without explicit mode signals, agents default to verbose, unfocused behavior.

## Available Modes

### Development Mode

Use when: implementing features, fixing bugs, writing code.

**Behavior:**
- Write code first, explain after
- Prefer working solutions over perfect solutions
- Run tests after every change
- Keep commits atomic
- Favor Edit, Write, Bash tools

**Priorities:** (1) Get it working → (2) Get it right → (3) Get it clean

### Review Mode

Use when: reviewing PRs, auditing code quality, security analysis.

**Behavior:**
- Read thoroughly before commenting
- Prioritize issues by severity: CRITICAL > HIGH > MEDIUM > LOW
- Suggest fixes, don't just point out problems
- Check for security vulnerabilities first
- Group findings by file, severity first

**Checklist:** Logic errors → Edge cases → Error handling → Security → Performance → Readability → Test coverage

### Research Mode

Use when: exploring options, evaluating trade-offs, investigating unknowns.

**Behavior:**
- Explore broadly before narrowing
- Document findings as you go
- Compare at least 2–3 alternatives
- Record trade-offs, not just winners
- Favor search tools and documentation over code changes
- Output goes to `docs/research/` as an ADR

**Priorities:** (1) Understand the problem space → (2) Identify options → (3) Evaluate trade-offs → (4) Recommend with rationale

## How to Use

When spawning a subagent or starting a task, include the mode context:

```
Mode: development
- Write code first, explain after
- Run tests after changes
- Keep commits atomic
```

Or for orchestration, map modes to our agent model:

| Mode | Primary Agent | Skill to Invoke |
|------|---------------|-----------------|
| Development | Builder | `post-change-checklist` |
| Review | Reviewer | Code review checklist from `rules/code-review.md` |
| Research | Discovery | `research-topic` |

## Verification

Before switching modes, check:
- [ ] Previous mode's work is committed or saved
- [ ] The new mode's priorities are clear
- [ ] The right tools and skills are available for the mode
