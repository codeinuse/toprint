---
name: post-change-checklist
description: "Format, lint, test, review, stage, and commit sequence to run after every code change. Never skip steps. Never commit if any step fails."
---

# Post-Change Checklist

## Trigger

Invoke this skill **after every code change** — before committing.

Also invoke the Smoke Test section after any structural change (moves, renames, dependency changes).

## Inputs

1. **Changed files** — which files were modified
2. **Change type** — does it affect API or behavior? (determines whether integration tests run)

## Steps

Run **in order**. Do not skip steps. Do not commit if any step fails.

1. **Format**: `[formatter] src/ tests/`
2. **Lint**: `[linter] src/ tests/ --fix`
3. **Unit tests**: `[test-runner] tests/unit/ -x -q`
4. **Integration tests**: `[test-runner] tests/integration/ -x -q` (if API or behavior changed)
5. **Review**: `git diff --stat`
6. **Stage**: `git add <files you changed>` — **never `git add -A`** when other agents share the workspace
7. **Commit**: `git commit -m "<type>(<scope>): <summary>"` — **only if steps 1–6 pass**

### Smoke Test

After any **structural change** (moves, renames, dependency changes), validate imports before step 1:

```bash
# [customize] Quick import check
[language-runtime] -c "import [your_package]; print('OK')"
```

If the smoke test fails, fix the import issue before proceeding.

## Commit Message Format

Use conventional commits: `<type>(<scope>): <summary>`

Types: `feat`, `fix`, `refactor`, `test`, `docs`, `chore`

## Verification

Before marking complete:
- [ ] All formatter, linter, and test steps passed
- [ ] Only your files are staged (not `git add -A`)
- [ ] Commit message follows conventional commit format
- [ ] One logical change per commit (atomic)
