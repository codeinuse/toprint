---
name: research-topic
description: "Research options for a technical decision, evaluate trade-offs, and record the outcome as an ADR."
---

# Research & Decide

## Trigger

Invoke this skill when:
- Evaluating **≥ 2 options** for a technical decision
- A choice is **hard to reverse** (database, framework, auth strategy, infra)
- A new **external dependency** is being introduced
- Investigating an **unknown** before committing to an approach
- The team asks "should we use X?" or "how does Y work?"

Do NOT invoke when: the answer is in the codebase (search first), the decision is trivial or easily reversible, or the question is opinion-based with no technical trade-offs.

## Inputs

Gather before starting:
1. **Problem statement** — what decision is needed and why now
2. **Constraints** — what limits the options (existing stack, budget, timeline, team skills, compliance)
3. **Time-box** — how deep to go (default: 1 hour equivalent of analysis)

## Steps

1. Analyze current state — how does the system handle this today? (code pointers)
2. Review prior decisions — relevant ADRs, past choices, lessons learned
3. Research externally — industry practices, libraries, standards, benchmarks
4. Evaluate options — pros, cons, effort, confidence for each
5. Recommend — pick one with clear reasoning tied to constraints
6. Record the decision and update `docs/research/INDEX.md`
7. Escalate to human for review and approval

## Output Format

Save to `docs/research/NNNN-kebab-case-title.md`:

```markdown
# NNNN: [Decision Title]

**Date:** YYYY-MM-DD
**Status:** Proposed | Accepted | Deprecated | Superseded by NNNN
**Question:** [The specific question being investigated]

## Summary
[One paragraph: key findings, decision made, and next step.]

## Current State
[How the system handles this today. Include file pointers.]

## Options

### Option A: [Name]
- **How it works:** [brief description]
- **Pros:** [list]
- **Cons:** [list]
- **Effort:** Low | Medium | High
- **Confidence:** Low | Medium | High

### Option B: [Name]
[Same format]

## Decision
**We have decided to [state the decision clearly].**
[2-3 sentence reasoning tied to constraints.]

## Consequences
### Positive
- [What becomes easier or better]

### Negative
- [Trade-offs we are accepting]

## Risks & Unknowns
- [What could go wrong]
- [What remains uncertain]

## Next Steps
1. [First action — e.g., write spec, begin implementation]
2. [Second action]

## References
- [Links to docs, articles, RFCs, benchmarks]
```

## Verification

Before marking complete:
- [ ] ≥ 2 options compared with pros/cons
- [ ] Recommendation is specific (not "it depends")
- [ ] Decision records positive and negative consequences
- [ ] Status is `Proposed` (not `Accepted` — human gates that)
- [ ] `docs/research/INDEX.md` updated with new entry
- [ ] Next steps are actionable (not vague)
- [ ] Evidence-based — links to sources, benchmarks, or code analysis
- [ ] Time-box respected — don't over-research; good enough beats perfect
