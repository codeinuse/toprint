---
name: task-tracking
description: "Plan, track progress, and capture lessons for complex multi-step tasks. Review lessons at session start."
---

# Task Tracking

## Trigger

Invoke this skill when:
- Starting a **complex multi-step task** (3+ steps)
- An issue needs to be **decomposed before implementation**
- Work requires careful **sequencing or checkpointing**
- At **session start** — to review prior lessons

Do NOT invoke for: single-commit fixes, trivial changes, documentation-only edits.

## Inputs

1. **Task description** — what needs to be accomplished
2. **Scope estimate** — rough number of steps or files involved

## Steps

### Starting a Task

1. **Review lessons**: Read `tasks/lessons.md` for relevant project patterns and past mistakes
2. **Plan**: Break work into checkable items and write them to `tasks/todo.md` (or `tasks/<agent-name>-todo.md` in shared workspaces)
3. **Track**: Mark items complete as you go; write a brief explanation of changes at each step
4. **Commit checkpoint**: After each meaningful step, run the [post-change checklist](../post-change-checklist/SKILL.md)
5. **Handoff checkpoint**: Before handing off, ending a long session, or compacting context, run the [capture-lessons](../capture-lessons/SKILL.md) skill

### After a Correction

When the user corrects your approach or a failure reveals a missing convention:

1. Run the [capture-lessons](../capture-lessons/SKILL.md) skill
2. Update `tasks/lessons.md` with the pattern — **ultra concise**, one line per lesson
3. Format: `- [YYYY-MM-DD] <what went wrong> → <what to do instead>`

### After Subagent Work

1. Review the subagent's final output
2. Extract any reusable lesson before the context is dropped
3. The parent agent updates `tasks/lessons.md`; subagents do not write repo rules directly

### Session Start

1. Read `tasks/lessons.md` — apply relevant patterns to current work
2. Read `tasks/todo.md` — resume any incomplete work

## Output Format

### `tasks/todo.md`

```markdown
# TODO: [Task Title]

**Date:** YYYY-MM-DD
**Status:** In Progress | Complete

- [x] Step 1 description
- [x] Step 2 description
- [ ] Step 3 description
- [ ] Step 4 description
```

### `tasks/lessons.md`

```markdown
# Lessons Learned

- [2026-01-15] Never use `git add -A` in shared workspace → stage only your files
- [2026-01-16] ORM `.get()` fails on composite keys → use `.filter()` instead
```

## Verification

Before marking complete:
- [ ] All todo items checked off or explicitly deferred with reason
- [ ] `tasks/lessons.md` updated if any corrections occurred
- [ ] No half-implemented work left uncommitted
