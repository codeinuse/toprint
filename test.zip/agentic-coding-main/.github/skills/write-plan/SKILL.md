---
name: write-plan
description: "Write an atomic implementation plan from an approved spec, breaking work into one-commit steps with TDD strategy."
---

# Write an Implementation Plan

## Trigger

Invoke this skill when:
- A **spec is approved** and needs to be broken into implementable steps
- The implementation spans **3+ commits** or touches **multiple components**
- The work requires a **specific execution order** (dependencies between steps)

Do NOT write a plan for: single-commit fixes, documentation-only changes, config tweaks.

## Inputs

Gather before writing:
1. **Approved spec** — with Gherkin acceptance criteria
2. **Relevant ADRs** — architectural constraints that apply
3. **Codebase context** — which files/modules will be affected

## Steps

1. Decompose the spec into **atomic steps** — each completable in one commit
2. Order steps by dependency — identify critical path and parallelizable work
3. Map tests to steps — which tests get written/updated at each step
4. Define the test strategy (TDD: tests first, then implementation)
5. Identify risks and mitigations
6. Set status to `Draft` — escalate to human for approval before implementation

## Output Format

Save to `docs/plans/NNNN-feature-name.md`:

```markdown
# Plan: [Feature Title]

**Spec:** [link to spec]
**ADRs:** [links to relevant ADRs]
**Date:** YYYY-MM-DD
**Status:** Draft | Approved
**Branch:** `feat/NNNN-short-description`

## Steps

### Step 1: [Short description]
**Changes:** [files/components affected]
**Tests:** [test files to write/update]
**Commit:** `test(scope): [description]`
**Done when:** [concrete success criteria]

### Step 2: [Short description]
**Depends on:** Step 1
**Changes:** [files affected]
**Tests:** [test files]
**Commit:** `feat(scope): [description]`
**Done when:** [criteria] + all prior tests still pass

[Continue for each step...]

## Dependency Order
Step 1 → Step 2 → Step 3
**Parallelizable:** [e.g., Steps 2 and 3 share no code]

## Test Strategy
- **Step 1:** Write failing tests from spec (Red)
- **Steps 2+:** Write code to pass tests (Green), then refactor
- **Coverage:** 80% unit, all boundaries integration, all Gherkin acceptance

## Risks
| Risk | Impact | Mitigation |
|------|--------|------------|
| [description] | [H/M/L] | [how to handle] |

## Definition of Done
- [ ] All tests pass (unit, integration, acceptance)
- [ ] Coverage meets thresholds
- [ ] Linting and formatting pass
- [ ] CHANGELOG.md updated
- [ ] Human approved and rebase-merged
```

## Worked Example

Spec: "Add Stripe subscription billing with free/pro/enterprise tiers"

```markdown
# Plan: Stripe Subscription Billing

**Spec:** docs/specs/0042-stripe-billing.md
**ADRs:** docs/research/0010-payment-provider.md
**Date:** 2026-03-20
**Status:** Draft
**Branch:** `feat/42-stripe-billing`

## Steps

### Step 1: Create subscription data model
**Changes:** supabase/migrations/004_subscriptions.sql
**Tests:** tests/models/subscription.test.ts
**Commit:** `test(billing): add subscription model tests`
**Done when:** Migration runs, RLS policies enforce row-level access

### Step 2: Stripe webhook handler
**Depends on:** Step 1
**Changes:** src/app/api/webhooks/stripe/route.ts
**Tests:** tests/api/stripe-webhook.test.ts
**Commit:** `feat(billing): handle Stripe webhook events`
**Done when:** checkout.session.completed, subscription.updated, subscription.deleted handled with signature verification

### Step 3: Checkout session API
**Depends on:** Step 1
**Changes:** src/app/api/checkout/route.ts
**Tests:** tests/api/checkout.test.ts
**Commit:** `feat(billing): create checkout session endpoint`
**Done when:** Authenticated users can create Stripe Checkout sessions with correct price_id

### Step 4: Tier-based feature gating
**Depends on:** Steps 1–2
**Changes:** src/middleware.ts
**Tests:** tests/middleware/tier-gate.test.ts
**Commit:** `feat(billing): gate features by subscription tier`
**Done when:** Free users blocked from Pro features, handles expired/past_due states

## Dependency Order
Step 1 → Step 2, Step 3 (parallel) → Step 4
**Parallelizable:** Steps 2 and 3 share no code

## Test Strategy
- **Step 1:** Failing model tests (Red)
- **Steps 2–4:** Tests first, then implementation (Green), refactor
- **Coverage:** 80% unit, webhook signature integration test, full upgrade E2E

## Risks
| Risk | Impact | Mitigation |
|------|--------|------------|
| Webhook events arrive out of order | H | Use event timestamps, idempotent upserts |
| User upgrades but webhook fails | M | Poll Stripe as fallback, show "processing" |

## Definition of Done
- [ ] All tests pass (unit, integration, acceptance)
- [ ] Coverage meets thresholds
- [ ] Linting and formatting pass
- [ ] CHANGELOG.md updated
- [ ] Human approved and rebase-merged
```

Notice: **exact file paths**, **concrete commit messages**, **testable done-when criteria**, and **risks with mitigations** — not vague summaries.

## Verification

Before marking complete:
- [ ] Every step is **one commit** — atomic and reviewable
- [ ] Steps map to spec acceptance criteria — nothing missed
- [ ] Dependency order is clear — no circular or missing dependencies
- [ ] Test strategy follows TDD (tests before implementation)
- [ ] Status is `Draft` (human approves before execution)
- [ ] Risks identified with concrete mitigations
