---
name: write-spec
description: "Write a feature specification with Gherkin acceptance criteria from a user story or problem statement."
---

# Write a Feature Spec

## Trigger

Invoke this skill when:
- A **new feature** or significant behavior change is requested
- The work spans **multiple files or components**
- **Acceptance criteria** need to be defined before implementation
- An issue needs to be decomposed into testable requirements

Do NOT write a spec for: bug fixes with obvious root cause, config changes, dependency upgrades, documentation-only changes.

## Inputs

Gather before writing:
1. **User story or problem statement** — who is affected and what pain exists
2. **Desired outcome** — what should be true after shipping
3. **Scope boundaries** — what's included and explicitly excluded
4. **Dependencies** — other features, services, or decisions this depends on

## Steps

1. Define the problem and current state
2. Write acceptance criteria as Gherkin scenarios (happy path + edge cases + errors)
3. Define scope boundaries — be explicit about exclusions
4. List non-functional requirements (performance, security, accessibility)
5. Identify dependencies and blockers
6. Add architecture notes if the design is non-obvious
7. Set status to `Draft` — escalate to human for approval

## Output Format

Save to `docs/specs/NNNN-feature-name.md`:

```markdown
# Spec: [Feature Title]

**Issue:** #NNNN
**Date:** YYYY-MM-DD
**Status:** Draft | Under Review | Approved | Implemented

## Problem Statement
[Who is affected, what pain exists, why this matters now.]

## Desired Outcome
[What should be true after shipping. Success metrics if quantifiable.]

## Acceptance Criteria

​```gherkin
Feature: [Feature Title]

  Scenario: [Happy path]
    Given [precondition]
    When [action]
    Then [expected outcome]

  Scenario: [Edge case]
    Given [precondition]
    When [action]
    Then [expected outcome]

  Scenario: [Error condition]
    Given [precondition]
    When [invalid action]
    Then [error handling]
​```

## Scope
**Included:** [specific features, endpoints, behaviors]
**Excluded:** [explicitly deferred work]

## Non-Functional Requirements
| Requirement | Target | How Verified |
|---|---|---|
| [e.g., Latency] | [e.g., p99 < 200ms] | [e.g., Load test] |

## Dependencies
- [Other features, services, ADRs this depends on]
- **Blocked by:** [unresolved decisions or prerequisites]

## Architecture Notes
[High-level design, data flow, API changes — only if non-obvious.]

## Related Documents
- ADRs: [links]
- Research: [links]
```

## Worked Example

User story: "As a team admin, I want to invite members by email so I can onboard new colleagues."

```markdown
# Spec: Team Member Invitation

**Issue:** #27
**Date:** 2026-03-20
**Status:** Draft

## Problem Statement
Team admins currently must ask a system admin to add members manually. This creates
a bottleneck — admins wait 1–2 days for new members to get access.

## Desired Outcome
Admins can invite members directly via email. Invitees receive a link, accept, and
join the team — no system admin needed. Target: <30s from invite to email delivery.

## Acceptance Criteria

```gherkin
Feature: Team Member Invitation

  Scenario: Admin invites a new member
    Given I am a team admin
    When I enter "alice@example.com" and click "Send Invite"
    Then an invitation email is sent to "alice@example.com"
    And a pending invitation appears in the team members list

  Scenario: Invitee accepts the invitation
    Given I received an invitation email
    When I click the invitation link
    And I complete registration
    Then I am added to the team with "member" role
    And the pending invitation is removed

  Scenario: Invitation expires after 7 days
    Given an invitation was sent 8 days ago
    When the invitee clicks the link
    Then they see "This invitation has expired"
    And the admin can resend the invitation

  Scenario: Non-admin attempts to invite
    Given I am a team member (not admin)
    When I try to access the invite form
    Then I see "You don't have permission to invite members"
```

## Scope
**Included:** Email invitation, accept flow, expiry, permission check, pending list
**Excluded:** Bulk CSV import, SSO/SAML invitation, role selection at invite time

## Non-Functional Requirements
| Requirement | Target | How Verified |
|---|---|---|
| Email delivery | <30s p95 | Integration test with email service |
| Invitation link security | Single-use, signed token | Security review |

## Dependencies
- Email service configured (SendGrid / SES)
- **Blocked by:** None

## Architecture Notes
Invitation tokens are signed JWTs with 7-day expiry. Stored in `invitations` table
with status enum: pending → accepted | expired | revoked.
```

Notice: **behavior-only Gherkin** (no implementation details), **explicit exclusions**, **at least one error scenario**, and **concrete NFR targets**.

## Verification

Before marking complete:
- [ ] Every Gherkin scenario is testable and unambiguous
- [ ] Scope clearly states what's included AND excluded
- [ ] No implementation details in acceptance criteria (behavior only)
- [ ] At least one error/edge case scenario defined
- [ ] Status is `Draft` (human approves before implementation)
- [ ] Dependencies identified — nothing will block implementation unexpectedly
