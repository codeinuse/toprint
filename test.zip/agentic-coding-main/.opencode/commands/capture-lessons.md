# Capture Lessons

Enter CAPTURE-LESSONS mode. Update the repo playbook with short lessons learned from recent work.

## Purpose

- The work already happened.
- This command looks at the latest execution, review, or correction and saves only the reusable lessons.

## Steps

### 1. Collect signals

- `RUN git diff main...HEAD --stat`
- Gather failed tests, review findings, user corrections, incident notes, and notable successes.
- Ignore one-off noise unless it changes future behavior.

### 2. Reflect

- Convert raw signals into reusable lessons.
- Prefer concrete patterns: failure mode -> future action.
- Separate transient task details from durable heuristics.

### 3. Curate

- Append lessons to `tasks/lessons.md` using:
  `- [YYYY-MM-DD] [area] signal -> action (repeat: N, promote: no|yes)`
- If a matching lesson already exists, increment `repeat` instead of duplicating it.
- De-duplicate near-identical entries.
- Do not rewrite the full file or collapse it into a summary.

### 4. Promote

- If a lesson is repeated or clearly repo-wide, propose or update `AGENTS.md` or `rules/`.
- Keep promotions small and evidence-based.
- Infrastructure and security conventions still require human review.

## Output

Post:

- New lessons added
- Existing lessons updated
- Promotions proposed

## Constraints

- No monolithic prompt rewrites
- No case-study essays
- If no reusable lesson exists, report that explicitly and do not force an entry
