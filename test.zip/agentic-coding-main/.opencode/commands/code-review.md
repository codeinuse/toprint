# Code Review

Enter REVIEW mode. Run 5 review passes, collecting findings across all rounds.

## Loop (5 iterations)

REPEAT for iterations 1–5:

**Review pass** — spawn parallel reviewer subagents (one per category):

- Correctness · Contracts · Performance · Security · Reliability · Maintainability
- Each receives: `RUN git diff main...HEAD`
- AWAIT all → collect MUST-FIX items, nice-to-have findings, and lesson candidates into a running list
- Log iteration number with each finding to track when it was discovered

GOTO next iteration until 5 complete.

## Report

After all 5 passes, post a consolidated final report:

- **MUST-FIX** findings (blocker-level — must be resolved before merge)
- **Nice-to-have** findings (surfaced for awareness, do not block)
- **Lesson candidates** (short reusable patterns for `tasks/lessons.md`, only when worth preserving)
- Plan adherence: compare changes to `docs/plans/`
- Test coverage: are all acceptance criteria covered?
- CHANGELOG.md updated?
- Commit messages valid? (`RUN git log main..HEAD --oneline`)

If lesson candidates exist, run `capture-lessons` before STOP.

STOP. Do not apply fixes. You CANNOT approve or merge.

Follow AGENTS.md and rules/code-review.md.
