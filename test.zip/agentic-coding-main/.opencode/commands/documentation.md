Enter DOCUMENTATION mode.

RUN git diff main...$(git merge-base main HEAD) --name-only

1. Update README if user-facing behaviour changed
2. Regenerate API docs if endpoints changed
3. RUN cat docs/research/INDEX.md and update with any new ADRs
4. Verify CHANGELOG.md is current and accurate

Commit: docs(scope): update documentation for XXXX
