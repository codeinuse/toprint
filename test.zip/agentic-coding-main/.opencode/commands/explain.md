# Explain

Enter EXPLAIN mode. Use the Feynman technique to explain the target code or architecture.

## Method

The Feynman technique has four steps — follow them in order:

**1. Identify** — locate and read the target (file, function, module, or architecture).

- `RUN git ls-files` or read the specified file/directory to understand scope
- Map dependencies: what does it import? What calls it?

**2. Explain simply** — write an explanation as if teaching someone with no prior context:

- Use plain language. No jargon without immediate definition.
- Use concrete analogies and real-world comparisons.
- Describe *what it does* before *how it does it*.
- Walk through a specific example with real values end-to-end.

**3. Find the gaps** — identify where the explanation becomes vague or hand-wavy:

- Mark any part you had to gloss over.
- Dig into those parts and simplify until the explanation holds.

**4. Refine** — rewrite the explanation removing all gaps:

- Strip technical noise. If a term needs more than one sentence to define, replace it with an analogy.
- Use diagrams (ASCII or Mermaid) when flow or structure is clearer visually.

## Output format

```
## What is this?
<one sentence — what problem does it solve>

## How does it work?
<plain language walkthrough with a concrete example>

## Key concepts
<bullet list — one analogy per concept>

## Where does it fit?
<how it connects to the rest of the codebase>

## What to watch out for
<gotchas, non-obvious behaviours, things that surprised you>
```

Do NOT modify any code. This is a read-only analysis.
