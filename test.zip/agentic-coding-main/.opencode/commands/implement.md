# Implement Mode

Enter IMPLEMENT mode. Test intent reviewed.

1. RUN cat docs/plans/$(ls docs/plans/ | tail -1)
2. Work through the plan step by step
3. Write minimum code to pass the next failing test
4. RUN tests after each change — confirm green before moving on
5. One commit per plan step
6. Update CHANGELOG.md with user-facing changes
7. Keep note of any lesson candidates when you hit a blocker, repeated fix, or non-obvious repo pattern

Commit format: feat(scope): description
If the plan is insufficient, STOP and tell me — do not improvise.
