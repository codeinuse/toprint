# Issue To Release

Enter ISSUE-TO-RELEASE mode. Start from a GitHub issue and drive the work through the full repo workflow automatically until completion or a required human gate.

## Goal

Turn one issue into durable artifacts, reviewed code, and updated repo knowledge.

## Use These Skills And Agents

- Start with the `task-tracking` skill for any non-trivial issue.
- Use the `write-spec` skill when the issue needs a spec.
- Use the `write-plan` skill when the work needs an implementation plan.
- Use the Builder agent for test-first, implementation, and refactor work.
- Use the Code Reviewer agent for review and security audit.
- Use the Release agent for documentation, deployment, and monitoring follow-up.
- Use the `post-change-checklist` skill after every code change.
- Use the `capture-lessons` skill after subagent work, before handoff, and before compaction when the host supports it.

## Subagent Strategy

- For research, planning, build strategy, and review, prefer **5 parallel subagents** to increase diversity of thought.
- Give each subagent one clear angle or responsibility.
- After every subagent round, run a **critique step**: compare results, identify convergence/divergence, reject weak ideas, and choose the next path explicitly.
- Good uses: codebase exploration, parallel risk analysis, alternative plans, critique of implementation approaches, category-based review, and isolated implementation subtasks.
- For build work, do not let 5 subagents edit overlapping files blindly. If file ownership is unclear, use the 5 subagents to propose or critique approaches first, then have the parent agent choose one path or assign isolated subtasks.
- After subagents return, the parent agent merges results, runs the critique step, decides next steps, and runs `capture-lessons` if reusable patterns emerged.

## Workflow

Proceed through the steps in order. Do not stop between steps unless you hit a required human approval point, a blocker, or completion.

### 1. Intake

- Run the `task-tracking` skill.
- Read the issue.
- Read `AGENTS.md`, relevant files in `rules/`, and `tasks/lessons.md`.
- Gather current repo context before proposing changes.
- If the issue is broad, use a focused subagent for codebase exploration or dependency/risk discovery.

### 2. Research

- Spawn 5 focused read-only subagents when research can be split cleanly.
- Give them different angles where possible: codebase history, dependency/risk analysis, architecture fit, edge cases, and alternative approaches.
- Run a critique step after they return and synthesize one research direction.
- Investigate the affected code and surrounding behavior.
- Write research notes only if the problem is non-obvious.
- Surface risks, unknowns, and dependencies.

### 3. Spec

- Use the `write-spec` skill when a spec is needed.
- Write or update a spec in `docs/specs/`.
- Define the problem, desired outcome, acceptance criteria, scope, and exclusions.

### 4. Plan

- Use the `write-plan` skill when a plan is needed.
- Spawn 5 planning subagents when the implementation has meaningful complexity or multiple viable approaches.
- Ask each to propose an atomic plan from a different angle: lowest risk, fastest path, strongest testability, simplest implementation, and best long-term maintainability.
- Run a critique step after they return and choose or merge the strongest plan.
- Write an implementation plan in `docs/plans/`.
- Break the work into atomic, reviewable steps.
- Map tests to each step.

### 5. Human gates

- Stop for human approval when the spec or plan requires approval.
- Do not continue through a required gate silently.
- Report exactly what is ready for review.

### 6. Build

- Use the Builder agent.
- Use 5 builder subagents when diversity of implementation thought is valuable.
- Safe default: have the 5 subagents propose implementations, identify risks, or own isolated subtasks. Do not let them edit overlapping files without explicit ownership.
- Run a critique step after each builder round before accepting a direction or moving to the next step.
- Execute the approved plan.
- Write tests and code in small steps.
- Update `CHANGELOG.md` for user-facing changes.
- Use subagents for actual code changes only when implementation subtasks are clearly separable and file ownership stays clear.
- Run the `post-change-checklist` skill after each code change.

### 7. Review

- Use the Code Reviewer agent.
- Spawn 5 reviewer subagents by default.
- Give them distinct review lenses such as correctness, contracts, performance, security, and maintainability/reliability.
- Run a critique step after they return and merge the strongest findings into one review decision.
- Run code review and security review.
- Separate must-fix findings from nice-to-have suggestions.
- Encourage parallel review subagents whenever categories can be reviewed independently.

### 8. Capture lessons

- Run the `capture-lessons` skill over failures, review findings, subagent output, and user corrections.
- Update `tasks/lessons.md` with short reusable patterns.
- Promote repeated lessons into `AGENTS.md` or `rules/` when they become durable conventions.

### 9. Finish

- If review finds must-fix issues, fix them and repeat review.
- When the change is complete, use the Release agent to update docs and release-related artifacts as needed.
- End with a summary of what changed, what still needs human action, and what lessons were captured.

## Constraints

- Keep artifacts in Git: specs, plans, lessons, changelog, code, and docs.
- Do not skip human approval points.
- Do not rewrite the full repo playbook when a short lesson will do.
- Stop and escalate on ambiguity, security-sensitive changes, repeated failure, or scope overrun.
