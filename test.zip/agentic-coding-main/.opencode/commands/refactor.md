Enter REFACTOR mode.

1. RUN the full test suite — confirm all green before touching code
2. Identify refactoring targets: poor naming, duplication, long functions, deep nesting
3. Apply one refactoring at a time
4. RUN tests after each change — if anything breaks, revert immediately
5. Follow rules/REFACTORING.md: Extract Method, Compose Method, Replace Magic Numbers, Introduce Parameter Object
6. Respect AGENTS.md limits: functions ≤ 15 lines, ≤ 4 params, classes ≤ 200 lines
7. Audit for dead code: unused types, orphaned imports, test-only functions

Refactoring must NOT change observable behaviour.
Commit format: refactor(scope): description
Do NOT add features or change public API contracts.
Tell me when done so I can review.
