# Review-Fix

Enter REVIEW-FIX loop. Max 10 iterations before escalating to human.

Use the Code Reviewer agent for every review pass. Run both `code-review` and `security-audit` modes, and let it spawn and merge its 7 checklist subagents in parallel.

## Loop

REPEAT:

**1. Review pass** — invoke the Code Reviewer agent over `git diff main...HEAD`.

- First run `code-review` mode so the reviewer performs its full review strategy over the diff
- In that pass, let it spawn 7 checklist subagents in parallel: correctness, contracts, performance, security, reliability, maintainability, and code quality
- Then run `security-audit` mode so the reviewer adds security findings to the same review result
- AWAIT merged report → collect MUST-FIX items, nice-to-have findings, and any lesson candidates worth preserving

**2. Exit condition** — if no MUST-FIX items found:

- If lesson candidates exist, run `capture-lessons`
- Post final report with iteration count, all resolved findings, and any remaining nice-to-have findings
- STOP

**3. Fix pass** — spawn parallel builder subagents, one per MUST-FIX item:

- Each subagent: fix only its assigned issue, run tests, commit
- Commit format: `fix(scope): <finding summary>`
- AWAIT all builders → confirm tests green

**3a. Preserve lessons** — if the review pass or fix pass surfaced reusable patterns, run `capture-lessons` before the next iteration.

**4. Escalate** — if iteration 10 completes and MUST-FIX items persist:

- List remaining blockers, what was attempted, proposed next steps
- If lesson candidates exist, run `capture-lessons`
- STOP and hand off to human

GOTO 1

## Constraints

- Builder subagents fix only the assigned finding — no scope creep
- The review pass must go through the Code Reviewer agent in both `code-review` and `security-audit` modes, not ad hoc reviewer instructions
- Tests must be green after every fix pass before the next review pass
- Nice-to-have findings are reported but never block the loop
