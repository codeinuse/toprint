Enter SECURITY-AUDIT mode.

RUN git diff main...HEAD

Check for:

- Hardcoded secrets, API keys, credentials
- SQL injection, XSS, input validation gaps
- Auth/authz logic issues
- Dependency CVEs — check lock files
- Output encoding gaps

Severity: Critical/High = BLOCKER. Medium = must address. Low = advisory.
Follow rules/security.md.
Append findings to the code-review report above.
