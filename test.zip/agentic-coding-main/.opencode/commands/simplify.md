Enter SIMPLIFY mode.

1. RUN the full test suite — confirm all green before touching code
2. Analyze target code for complexity: deep nesting, unnecessary abstractions, dead code, over-engineering
3. Apply simplifications in priority order:
   - **Delete dead code**: unused functions, classes, imports, commented-out code, unreachable branches
   - **Inline unnecessary abstractions**: single-use helpers, single-implementation interfaces, trivial wrappers
   - **Reduce indirection**: pass-through functions, unnecessary DI, adapter layers with no logic
   - **Simplify control flow**: early returns over nested ifs, flatten conditionals, remove flag arguments
   - **Consolidate**: merge small related files, colocate code with its callers, remove premature separation
4. RUN tests after each change — if anything breaks, revert immediately
5. Follow rules/REFACTORING.md and Kent Beck's Four Rules of Simple Design

Simplification must NOT change observable behaviour.
Do NOT add features, new abstractions, or scope — only remove and simplify.
Commit format: refactor(scope): simplify description
Tell me when done so I can review.
