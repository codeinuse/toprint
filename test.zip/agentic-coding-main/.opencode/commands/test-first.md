Enter TEST-FIRST mode. Plan has been approved.

1. RUN cat docs/plans/$(ls docs/plans/ | tail -1)
2. Write .feature files with all Gherkin scenarios
3. Write step definition stubs
4. Write unit test stubs for expected functions

All tests MUST FAIL — no implementation yet.
RUN the test suite to confirm all fail.
Commit: test(scope): scaffold failing tests for XXXX
Tell me when done so I can review test intent.
