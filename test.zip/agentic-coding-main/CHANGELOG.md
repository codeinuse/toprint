# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Unreleased

### Changed
- Replace Gherkin/BDD toolchain requirement with structured prose acceptance criteria translated directly to native test code. The Given/When/Then thinking pattern is retained in specs as prose; `.feature` files, step definitions, and Cucumber/Behave are no longer required.
- Document a lessons-based workflow so repo context evolves through short reusable updates instead of monolithic prompt rewrites.
- Rewrite the lesson-curation guidance in plain language and document the issue-to-release flow in the README.
- Make the issue-to-release flow explicitly call named skills, best-fit agents, and focused subagents where appropriate.
- Add a 5-subagent plus critique pattern to research, planning, build strategy, and review inside issue orchestration.
- Route review-fix through the Code Reviewer agent so category subagents, lesson candidates, and lesson capture are handled consistently.
- Restore review-fix behavior so it runs both code review and security audit modes before extracting fixable findings.
- Add an explicit correctness checklist to the Code Reviewer agents so correctness review checks behavior, edge cases, invariants, and test evidence directly.

### Added
- [Feature description and issue reference]
- OpenCode `capture-lessons` command for capturing reusable lessons from reviews, failures, and user corrections.
- OpenCode `issue-to-release` command to run the full workflow from GitHub issue through review, lessons, and release handoff.
- GitHub Copilot prompts for `capture-lessons` and `issue-to-release` workflows.
- GitHub Copilot and OpenCode `capture-lessons` skills for preserving reusable lessons before handoff, subagent context loss, or compaction.

### Changed
- [Breaking or significant change and issue reference]

### Fixed
- [Bug fix and issue reference]

### Deprecated
- [Deprecated feature and issue reference]

### Removed
- [Removed feature and issue reference]

### Security
- [Security fix and issue reference]

---

## [1.0.0] - YYYY-MM-DD

### Added
- Initial release
- Core features [describe]

### Changed
- [Describe changes from any previous version if this isn't the first]

### Fixed
- [Any initial bug fixes]

### Security
- [Any security measures in place]

---

## Guidelines for Agents

1. **When to update:** Every PR that includes user-facing changes
2. **What to include:** Only changes visible or directly affecting end users
   - ✅ New features, breaking changes, bug fixes, security patches
   - ❌ Internal refactors, tool upgrades, documentation-only changes, test improvements
3. **Format:** One bullet per change, link the related issue (`#1234`)
4. **Version:** Follow semantic versioning
   - `MAJOR.MINOR.PATCH` (e.g., 1.2.3)
   - MAJOR: breaking changes
   - MINOR: backward-compatible features
   - PATCH: bug fixes
5. **Location:** Add entries to the `Unreleased` section under the appropriate category
6. **On release:** Human moves `Unreleased` section to a dated release section with version number
7. **No merge without update:** If the PR changes user-facing behavior, CHANGELOG must be updated

---

## Example Format

```markdown
### Added
- User registration API (#1234)
- Email verification flow (#1235)

### Fixed
- Null pointer exception in login endpoint (#1236)

### Security
- Updated bcrypt dependency to 4.0.0 to fix CVE-2023-12345 (#1237)
```
