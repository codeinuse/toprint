# The Agentic Coding Initiative

A comprehensive framework and set of resources for building software development lifecycles where AI agents are treated as first-class team members alongside human engineers.

## What's in This Repository

### 📖 Core Documents

- **[agentic-coding.md](agentic-coding.md)** (~1,700 lines) — The definitive playbook for agentic SDLC
  - Philosophy and core beliefs
  - Non-negotiable harness scaffolding (AGENTS.md, specs, ADRs, plans, tests)
  - Four agent profiles with multiple modes (Discovery, Builder, Reviewer, Release)
  - 9-phase SDLC with clear human gates and autonomous phases
  - Testing philosophy: BDD with Gherkin, TDD for unit tests
  - Git as the coordination backbone
  - Human-in-the-loop governance model
  - Tooling: GitHub Copilot agents/prompts and OpenCode agents/commands
  - Hotfix track for production incidents
  - Two-week incremental adoption blitz
  - Rollback and error recovery strategies

### 📋 Templates & Guides (Reusable Across Projects)

- **[AGENTS.md](AGENTS.md)** — Template for your project's agent rules of engagement (~120 lines, 5 sections)
  - Agent Mindset: persona, anti-sycophancy, plan-before-build, re-plan on failure
  - Required Workflow: build/test/lint commands, post-change checklist
  - Development Rules: code style deviations, git conventions, error recovery
  - Domain Knowledge: project-specific conventions, deprecated APIs, gotchas
  - Escalation & Self-Improvement: when to stop, max 3 attempts, propose amendments

- **[rules/security.md](rules/security.md)** — Secrets, input validation, auth, CVE scanning
- **[rules/testing.md](rules/testing.md)** — TDD, coverage thresholds, test pyramid, BDD/Gherkin
- **[rules/code-review.md](rules/code-review.md)** — Definition of Done, PR checklist, review standards
- **[rules/REFACTORING.md](rules/REFACTORING.md)** — Design principles, SOLID, refactoring patterns

- **Skills** (in `.github/skills/` and `.opencode/skills/`):
  - `research-topic` — Research options and record decisions (ADRs)
  - `write-spec` — Write feature specifications with Gherkin acceptance criteria
  - `write-plan` — Write implementation plans from approved specs
  - `post-change-checklist` — Format, lint, test, commit procedure after every change
  - `task-tracking` — Plan, track progress, and capture lessons for multi-step tasks
  - `capture-lessons` — Preserve reusable lessons before handoff, subagent context loss, or compaction

- **[CHANGELOG.md](CHANGELOG.md)** — Example changelog structure following [Keep a Changelog](https://keepachangelog.com/)

## Quick Start: Adopting Agentic Development

1. **Read the playbook** — Start with [agentic-coding.md](agentic-coding.md) to understand the philosophy and phases
2. **Copy to your project** — Copy `AGENTS.md`, `rules/`, `.github/skills/`, and `.opencode/skills/` to your repo and customize
3. **Follow the two-week blitz** — Section 12 of the playbook has a concrete adoption plan
4. **Bootstrap your harness** — Complete the Day Zero checklist (Section 2.8)
5. **Set up tooling** — Configure agent files for your IDE (Section 9: GitHub Copilot or OpenCode)
6. **Start small** — Run one real feature through the full 9-phase cycle to learn the process

## Key Principles

- 🤖 **Agents as Staff Engineers** — Not tools, not autocomplete. First-class team members operating as Staff Engineer / Technical Lead.
- 📦 **Artifacts over chat** — All work produces durable, versioned artifacts in Git.
- 🚪 **Humans hold the gates** — Spec approval, plan approval, PR merge are mandatory human decisions.
- ✅ **Tests define correctness** — BDD acceptance tests and TDD unit tests are the contract.
- 🔄 **Git is the backbone** — Issues, branches, commits, PRs, docs — everything lives in Git.
- 📊 **Measure and iterate** — Track metrics, identify bottlenecks, evolve `AGENTS.md` continuously.

## The 9-Phase SDLC at a Glance

```text
Issue/Intake → Research → Spec + ADRs → Planning → Test Scaffolding
                   ↓           ↓           ↓           ↓              
                [Human]    [Human]     [Human]    [Human]          
                                                      ↓
                                        Implementation + Tests (CI gates)
                                                      ↓
                                            Code Review (Agent + Human)
                                                      ↓
                                              Human Approves & Merges
                                                      ↓
                                         Documentation & Release
                                                      ↓
                                          Retrospective & Metrics
```

See Section 4 of [agentic-coding.md](agentic-coding.md) for full details.

## Issue To Release Flow

When starting from a GitHub issue, the workflow is:

1. Read the issue and gather repo context from `AGENTS.md`, `rules/`, and `tasks/lessons.md`.
2. Research the problem and write a spec in `docs/specs/`.
3. Write a step-by-step implementation plan in `docs/plans/`.
4. Get human approval on the spec and plan when required.
5. Build the change: write tests, implement the code, and update `CHANGELOG.md`.
6. Run code review and security review.
7. Capture reusable lessons from failures, reviews, and corrections into `tasks/lessons.md`.
8. Fix review findings and repeat review if needed.
9. Merge, update documentation and release artifacts, then capture any final lessons.

The key rule is that each issue should improve the repo's playbook. Do not leave useful lessons trapped in chat or in a one-off review.

OpenCode commands that support this flow:

- `issue-to-release` — runs the issue-driven workflow until a required human gate or completion
- `capture-lessons` — updates `tasks/lessons.md` with short reusable patterns after work, review, or correction

Recommended split:

- Use `issue-to-release` as the user-invoked orchestration command
- Use `capture-lessons` as a core skill that runs around handoffs, subagent results, and compaction boundaries

Inside `issue-to-release`, prefer named skills and best-fit agents over ad hoc execution:

- `task-tracking`, `write-spec`, `write-plan`, `post-change-checklist`, and `capture-lessons`
- Builder for implementation
- Code Reviewer for review and security audit
- Release for documentation, deployment, and monitoring
- Focused subagents for exploration, parallel risk analysis, review categories, and isolated subtasks when file ownership stays clear

Default orchestration pattern inside `issue-to-release`:

- Use 5 parallel subagents for research, planning, build strategy, and review when diversity of thought is useful
- Run a critique/synthesis step after each subagent round before moving forward
- For build work, allow parallel code changes only when ownership is isolated; otherwise use subagents to propose or critique approaches first

## Agent Profiles

Four agents, each with distinct modes. The only hard boundary: **the agent that writes code must not review it.**

| Agent | Modes | Mandate |
| ----- | ----- | ------- |
| **Discovery** | `research` · `architecture` · `planning` | Understand the problem, design the solution, plan the build |
| **Builder** | `test-first` · `implement` · `refactor` | Write tests and production code — TDD loop |
| **Reviewer** | `code-review` · `security-audit` | Independent quality gate on PRs (cannot approve/merge) |
| **Release** | `documentation` · `deployment` · `monitoring` | Post-merge: docs, deploy, metrics |

See Section 3 of [agentic-coding.md](agentic-coding.md) for full agent details and the rationale for 4 agents over 9.

## Mandatory Human Gates

These phases require human approval before proceeding:

1. **Issue Prioritisation** — Human moves issue to "Ready for Research"
2. **Spec Approval** — Human reviews and approves spec + ADRs
3. **Plan Approval** — Human reviews and approves implementation plan
4. **Test Intent** — Human confirms the right things are being tested
5. **PR Merge** — Human approves and merges (never autonomous)
6. **Infrastructure Changes** — Human approves Release Agent deployment proposals

## Using These Resources

### For a New Project

1. Copy `AGENTS.md` to your repo root and customize it for your codebase
2. Copy `rules/`, `.github/skills/`, and `.opencode/skills/` directories — delete any you don't need
3. Create `docs/research/`, `docs/specs/`, `docs/plans/` directories
4. Follow the Day Zero bootstrap checklist from Section 2.8
5. Reference [agentic-coding.md](agentic-coding.md) when questions arise

### For an Existing Project

1. Read Section 12: Incremental Adoption — it's designed for retrofit
2. Execute the two-week blitz plan
3. Start with new code; phase in legacy code gradually
4. Update `AGENTS.md` as you discover new conventions

### For Your Organization

- Copy `AGENTS.md` as an org-level template
- Create a shared `docs/` with common architecture patterns and ADRs
- Link this repo in your engineering handbook
- Run regular retros to evolve the framework (Section 10)

## Philosophy Summary

> Coding agents are not autocomplete. They are first-class members of the engineering team. This framework defines how a software development lifecycle must be structured when agents are treated as peers — not tools.

The engineer's role shifts from "person who writes every line of code" to **curator, reviewer, and orchestrator** of a team of specialized agents. This is not a loss of craft — it is an elevation of it. Agents amplify output; humans ensure correctness, coherence, and intent.

## Contributing

This framework is a living document. As you adopt and adapt it:

- Update `AGENTS.md` with new conventions and lessons learned
- Refine templates based on what works for your team
- Document non-obvious decisions as ADRs
- Share patterns and improvements

## License

MIT — adapt freely for your organization.

---

**Start with the playbook.** Everything else flows from a shared understanding of how agents and humans work together.
