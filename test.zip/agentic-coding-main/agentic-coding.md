# The Agentic SDLC: A Prescriptive Playbook

> Coding agents are not autocomplete. They are first-class members of the engineering team. This document defines how a software development lifecycle must be structured when agents are treated as peers — not tools.

---

## Table of Contents

1. [Philosophy](#1-philosophy)
2. [The Harness: Non-Negotiable Scaffolding](#2-the-harness-non-negotiable-scaffolding)
3. [Agent Profiles](#3-agent-profiles)
4. [The SDLC Phases](#4-the-sdlc-phases)
5. [Testing Philosophy](#5-testing-philosophy)
6. [Git as the Backbone](#6-git-as-the-backbone)
7. [Human-in-the-Loop Governance](#7-human-in-the-loop-governance)
8. [Orchestration Model](#8-orchestration-model)
9. [Tooling: Invoking Agent Modes](#9-tooling-invoking-agent-modes)
10. [Artifacts & Templates](#10-artifacts--templates)
11. [Metrics & Continuous Improvement](#11-metrics--continuous-improvement)
12. [Hotfix Track](#12-hotfix-track)
13. [Incremental Adoption](#13-incremental-adoption)
14. [Rollback & Error Recovery](#14-rollback--error-recovery)

---

## 1. Philosophy

The role of the engineer is shifting. You are no longer the person who writes every line of code. You are the **curator, reviewer, and orchestrator** of a team of agents that research, design, implement, test, and document software on your behalf.

This is not a loss of craft — it is an elevation of it. The engineer's judgement, taste, and domain expertise become *more* critical, not less. Agents amplify output; humans ensure correctness, coherence, and intent.

### Core Beliefs

- **Agents must operate within constraints.** Unconstrained agents produce unconstrained chaos. Every repo must have an explicit harness that defines how agents behave.
- **Artifacts over chat.** Agent work must produce durable, versioned artifacts (markdown files, code, tests, ADRs) — not ephemeral conversation. If it isn't committed to Git, it didn't happen.
- **Small, atomic, reviewable units.** Agents must work in small steps. Each step produces a reviewable commit. No monolithic PRs.
- **Humans approve; agents propose.** Agents never merge their own work. Humans hold the merge button. Certain phases (spec approval, plan approval, PR merge) are mandatory human gates.
- **Tests are the contract.** Tests define what the software must do. Agents write code to satisfy tests, not the other way around. Tests are written *before* or *alongside* implementation — never after as an afterthought.
- **Git is the single source of truth.** Issues, branches, commits, PRs, documentation, specs, ADRs, changelogs — everything lives in Git. Agents coordinate through Git artifacts, not hidden state or external tools.

---

## 2. The Harness: Non-Negotiable Scaffolding

Before a single agent writes a single line of code, the repository must contain the following scaffolding. This is the **harness** — the set of constraints and structures that make agentic development reliable and repeatable.

### 2.1 `AGENTS.md`

The rules of engagement. Every repo must have an `AGENTS.md` at the root that defines:

- **Coding standards** — language, formatting, linting rules, naming conventions.
- **Architectural constraints** — patterns in use (e.g., hexagonal architecture, CQRS), forbidden patterns, dependency rules.
- **Project-specific nuances** — domain terminology, legacy quirks, integration points, known pitfalls.
- **Agent behaviour rules** — commit message format, branch naming, PR template adherence, test coverage requirements.
- **Escalation triggers** — conditions under which an agent must stop and ask a human (e.g., security-sensitive changes, schema migrations, breaking API changes).

`AGENTS.md` is a living document. It is updated whenever a new convention is established or a lesson is learned.

### 2.2 `CHANGELOG.md`

Maintained by agents, reviewed by humans. Every user-facing change must be logged here following [Keep a Changelog](https://keepachangelog.com/) format. Agents must update this file as part of the implementation phase — it is not a post-release chore.

### 2.3 `docs/research/`

Architecture Decision Records. Every non-trivial technical decision must be captured as an ADR before implementation begins. ADRs follow the format:

```
docs/research/
├── 0001-use-postgresql-over-mysql.md
├── 0002-adopt-hexagonal-architecture.md
├── 0003-event-sourcing-for-orders.md
└── INDEX.md
```

`INDEX.md` is an auto-maintained table of all ADRs with status (Proposed, Accepted, Deprecated, Superseded).

### 2.4 `docs/specs/`

Feature specifications. Each feature has a spec that defines: the problem, the desired outcome, acceptance criteria (in Gherkin), scope boundaries, and non-goals. Specs are the input to the Discovery Agent (for architecture and planning) and the Builder Agent (for test scaffolding and implementation).

### 2.5 `docs/research/`

Research artifacts. When an agent investigates a problem, gathers context, or evaluates options, the output is a research summary committed here. Research is not throwaway — it informs future decisions and prevents repeated investigation.

### 2.6 `docs/plans/`

Implementation plans. The step-by-step breakdown of how a feature will be built. Each plan references the spec, relevant ADRs, and research. Plans are reviewed and approved by a human before execution begins.

### 2.7 Test Suites

Every repo must have:

- **Unit tests** — fast, isolated, covering individual functions/modules.
- **Integration tests** — covering service boundaries, database interactions, API contracts.
- **Acceptance tests** — Gherkin `.feature` files mapping to user stories.
- **CI gates** — all three layers must pass before a PR can merge. Minimum coverage thresholds enforced.

### 2.8 Bootstrap Checklist (Day Zero)

The harness must exist before agents do any work. For a new project, complete this checklist in order before assigning any issue to an agent:

- [ ] `AGENTS.md` created at repo root with coding standards, architectural constraints, and escalation triggers
- [ ] Branch protection rules enabled on `main` (no direct push, PR required, CI must pass)
- [ ] Conventional commits enforced via commit-msg hook or CI check
- [ ] `docs/research/`, `docs/specs/`, `docs/research/`, `docs/plans/` directories created with placeholder `README.md` files
- [ ] `CHANGELOG.md` initialised
- [ ] CI pipeline configured (at minimum: lint, unit tests, integration tests, acceptance tests, coverage report)
- [ ] PR template committed to `.github/PULL_REQUEST_TEMPLATE.md` (see Section 6.4)
- [ ] Issue templates configured for feature requests, bug reports, and hotfixes
- [ ] Coverage thresholds configured in CI (80% unit, all integration boundaries, all acceptance scenarios)
- [ ] At least one dummy test in each layer (unit, integration, acceptance) to validate the pipeline end-to-end
- [ ] `AGENTS.md` reviewed and signed off by the lead engineer

**Existing projects:** Do not try to retrofit the full harness at once. See [Section 12: Incremental Adoption](#12-incremental-adoption).

---

## 3. Agent Profiles

An agentic team requires **distinct agents with multiple modes** — not nine narrow specialists, but not one do-everything generalist either. The industry has converged on a principle: **separate agents where the quality gate demands independence; use modes within an agent where context preservation matters more than separation.**

Modern frontier LLMs are strong generalists. Splitting into narrow roles that use the same model and tools isn't real specialisation — it's a prompt wrapper with a lossy handoff. The 4-agent model below reduces handoffs from ~7 to ~3, preserves all human gates, and aligns with how production agentic tools (Copilot, Cursor, Devin, Claude Code) and multi-agent frameworks (CrewAI, MetaGPT, AutoGen) structure work.

### 3.1 Discovery Agent

**Mandate:** Understand the problem, design the solution, and plan the build. One agent owns the full journey from "what is this?" to "here's how we build it" — because the context gathered during research directly informs design, and design directly informs planning. Splitting these into separate agents forces lossy serialisation at each boundary.

| | |
|---|---|
| **Modes** | `research` · `architecture` · `planning` |
| **Inputs** | Git issue, codebase access, external documentation, existing ADRs, `AGENTS.md` constraints |
| **Outputs** | Research summary (`docs/research/`), feature spec with Gherkin acceptance criteria (`docs/specs/`), ADR(s) (`docs/research/`), implementation plan (`docs/plans/`) |

**Mode: Research**
- Read relevant code, identify existing patterns, surface prior ADRs, find external references, identify risks and unknowns.
- Output: research summary artifact committed to `docs/research/XXXX-topic.md`.
- Autonomy: fully autonomous. No human gate required to begin research.

**Mode: Architecture**
- Define system design, evaluate trade-offs, write acceptance criteria in Gherkin, document decisions as ADRs.
- Output: feature spec (`docs/specs/`) and ADR(s) (`docs/research/`).
- Autonomy: produces drafts. **Human must approve** specs and ADRs before they are marked Accepted.
- Rule of thumb for ADRs: *if a reasonable engineer might disagree with this decision, it needs an ADR.*

**Mode: Planning**
- Decompose the approved spec into an ordered list of atomic plan steps. Each step must be completable in a single commit.
- Each step specifies: what code to write/change, which tests to write/update, and the expected commit message.
- Output: implementation plan (`docs/plans/XXXX-feature.md`), referencing the spec and ADRs by filename.
- Autonomy: produces draft. **Human must approve** the plan before execution begins.

### 3.2 Builder Agent

**Mandate:** Write tests and production code. The TDD loop — red, green, refactor — belongs in one agent because test-writing and implementation are tightly coupled activities that share full code context. Separating them into different agents forces awkward coordination and duplicate context loading.

| | |
|---|---|
| **Modes** | `test-first` · `implement` · `refactor` |
| **Inputs** | Approved plan, approved spec (with Gherkin acceptance criteria), `AGENTS.md`, existing codebase |
| **Outputs** | Failing test scaffolding, production code, passing tests, coverage reports, one commit per plan step |

**Mode: Test-First**
- Read the approved spec (Gherkin acceptance criteria) and plan. Write Gherkin `.feature` files, step definition stubs, and unit test stubs.
- All tests are committed. **They must fail at this point** — there is no implementation yet.
- Autonomy: fully autonomous for test creation. Human reviews test intent.

**Mode: Implement**
- Work through the plan step by step. Each step produces one atomic commit on a feature branch.
- Write code specifically to pass the next failing test. Update `CHANGELOG.md`.
- Must not deviate from the approved plan. If the plan is insufficient, **escalate to human** rather than improvise.
- Conventional commit messages are mandatory (e.g., `feat:`, `fix:`, `refactor:`, `test:`, `docs:`).

**Mode: Refactor**
- Clean up code without changing behaviour. Improve naming, extract abstractions, reduce duplication.
- Only after tests are green. Refactoring must not break any passing test.

### 3.3 Reviewer Agent

**Mandate:** Independent quality gate — code review and security audit in a single pass. This **must** be a separate agent from the Builder to prevent self-review ("grading your own homework"). Code review and security review inspect the same artifact (the diff) with overlapping tools, so they belong in one agent rather than two.

| | |
|---|---|
| **Modes** | `code-review` · `security-audit` |
| **Inputs** | PR diff, `AGENTS.md`, approved plan, spec, dependency manifests |
| **Outputs** | Review comments on the PR, security findings, CVE reports, escalations |

**Mode: Code Review**
- Check code against coding standards, verify plan adherence, flag deviations, check test coverage, verify changelog updates, validate conventional commits.
- Posts review comments. **Cannot approve or merge** — that is a human action.

**Mode: Security Audit**
- Static analysis (SAST) on changed code, dependency CVE scanning, review of authentication/authorisation logic, validation of secrets management (no hardcoded credentials), review of input validation and output encoding.
- **Blocks PR** if critical or high-severity issues are found. Human must explicitly acknowledge and resolve before merge.
- Security audit is mandatory for projects handling authentication, PII, payments, or regulated data. For all other projects it is strongly recommended. Critical findings are blockers, not advisories.

### 3.4 Release Agent

**Mandate:** Post-merge operations — documentation, deployment, and monitoring. These activities share a common trigger (merged PR), require a different tool set than code authoring, and operate on the merged result rather than the working branch. Combining them reduces the number of post-merge handoffs to zero.

| | |
|---|---|
| **Modes** | `documentation` · `deployment` · `monitoring` |
| **Inputs** | Merged PR, code changes, specs, ADRs, changelog, repo CI config, infrastructure definitions |
| **Outputs** | Updated README, API docs, ADR index, pipeline updates, deployment execution, environment configs, metrics |

**Mode: Documentation**
- Regenerate API documentation from code, update ADR index, ensure README reflects current state, maintain architecture diagrams, verify onboarding guides.
- Fully autonomous. Reviewed in the next PR cycle.

**Mode: Deployment**
- Ensure CI/CD picks up the change and deploys to the appropriate environment.
- Update CI workflows when test structure changes, manage environment variables, configure deployment pipelines, troubleshoot build failures.
- Proposes infrastructure changes. **Human must approve** any infrastructure or pipeline modifications.

**Mode: Monitoring**
- Log metrics for completed work: time per phase, revision cycles, test coverage delta, lines changed, commit count.
- Surface anomalies: coverage drops, build time regressions, deployment failures.

### Why 4 Agents, Not 9

The previous 9-agent model (Researcher, Architect, Planner, Implementer, Test, Reviewer, DevOps, Documentation, Security) suffered from three structural problems:

1. **Context loss at every handoff.** Each serialisation of context into artifacts is lossy. With 9 agents, a feature traversed 5-7 handoffs. With 4 agents, it's 3.
2. **False specialisation.** Most of the 9 agents used the same LLM with the same tools — they were prompt wrappers, not genuine specialists. Modes achieve the same behavioural differentiation without the handoff cost.
3. **Orchestration overhead.** Coordinating 9 agents requires complex routing, state machines, and error handling that scales superlinearly. 4 agents can be orchestrated with a simple linear pipeline.

The only structural separation that earns its keep is **Builder vs. Reviewer** — the agent that writes the code must not be the agent that reviews it. Every other boundary is better served by a mode switch within the same agent.

---

## 4. The SDLC Phases

Every piece of work flows through these phases, in order. Some phases can overlap (the Builder Agent runs test-first and implement modes in a tight loop during TDD), but the sequence of gates is strict.

### Track Selection

Not all work warrants the full nine-phase cycle. Use the appropriate track:

| Track | When to Use | Phases Required |
|---|---|---|
| **Standard** | New features, non-trivial changes, anything touching a public API or data schema | All 9 phases |
| **Lightweight** | Config changes, dependency bumps, copy fixes, minor refactors with no behaviour change | Build → Review → Merge (automated CI still required) |
| **Hotfix** | Production incidents requiring immediate resolution | See [Section 12](#12-hotfix-track) |

The engineer selects the track when triaging the issue. Track selection must be recorded on the issue. Agents must not self-promote from Lightweight to Standard — that is a human judgement.

### Phase 1: Issue 

**Trigger:** A human creates a Git issue, or an agent triages an incoming request into an issue.

**What happens:**
- Work is captured as a Git issue with a clear title and description.
- Agents can enrich the issue: add labels, estimate complexity, link related issues, identify affected areas of the codebase.
- The issue is assigned to a project board column (Backlog → Triaged).

**Gate:** Human prioritises the issue and moves it to "Ready for Research."

---

### Phase 2: Research

**Owner:** Discovery Agent (`research` mode)

**What happens:**
- The Discovery Agent reads the issue, explores the codebase, examines prior ADRs and specs, and gathers any external context needed.
- Output: a research summary committed to `docs/research/XXXX-issue-title.md`.
- The summary includes: current state analysis, relevant code pointers, prior decisions, risks, open questions, and recommended approach.

**Gate:** Human reviews research summary. If open questions remain, they are resolved before proceeding.

---

### Phase 3: Specification

**Owner:** Discovery Agent (`architecture` mode)

**What happens:**
- The Discovery Agent switches to architecture mode and drafts a feature spec based on its own research.
- The spec includes: problem statement, desired outcome, acceptance criteria written in Gherkin, scope boundaries, non-goals, and dependencies.
- If the feature involves a non-trivial technical decision, an ADR is drafted alongside the spec.
- Because the same agent performed the research, full context is preserved — no lossy handoff.

**Gate:** **Human must approve** the spec and any ADRs. Approval means: acceptance criteria are correct, scope is appropriate, and the technical approach is sound.

> **Note on ADRs:** ADRs are produced during the specification phase, not as a separate step. They are outputs of the design process, tightly coupled with the spec. The Discovery Agent decides when an ADR is warranted — the rule of thumb is: *if a reasonable engineer might disagree with this decision, it needs an ADR.*

---

### Phase 4: Planning

**Owner:** Discovery Agent (`planning` mode)

**What happens:**
- The Discovery Agent switches to planning mode and produces an implementation plan from the approved spec, accepted ADRs, and its own research context.
- The plan is a numbered list of atomic steps. Each step must be completable in a single commit.
- Each step specifies: what code to write/change, which tests to write/update, and the expected commit message.
- The plan references the spec and ADRs by filename.

**Output:** `docs/plans/XXXX-feature.md`

**Gate:** **Human must approve** the plan. This is the last checkpoint before code is written.

---

### Phase 5: Test Scaffolding (TDD Start)

**Owner:** Builder Agent (`test-first` mode)

**What happens:**
- The Builder Agent reads the approved spec (specifically the Gherkin acceptance criteria) and plan, then writes:
  - Gherkin `.feature` files with scenarios.
  - Step definition stubs.
  - Unit test stubs for the expected functions/modules (based on the plan).
- All tests are committed. **They must fail at this point** — there is no implementation yet.

**Gate:** Human reviews test intent. Are the right things being tested? Are edge cases covered?

---

### Phase 6: Implementation

**Owner:** Builder Agent (`implement` mode, with `test-first` and `refactor` modes interleaved)

**What happens:**
- The Builder Agent works through the plan, step by step, switching between modes as needed.
- Each step produces one atomic commit on a feature branch.
- As implementation progresses, previously-failing tests should start passing. The Builder Agent writes additional unit tests as implementation reveals edge cases.
- `CHANGELOG.md` is updated as part of this phase.
- Conventional commit messages are mandatory (e.g., `feat:`, `fix:`, `refactor:`, `test:`, `docs:`).

**Branch naming:** `feat/XXXX-short-description`, `fix/XXXX-short-description`, `chore/XXXX-short-description` — where `XXXX` is the issue number.

**Gate:** All tests pass. Coverage thresholds met. Implementation matches the plan.

---

### Phase 7: Review

**Owner:** Reviewer Agent (`code-review` + `security-audit` modes) + Human

**What happens:**
- A PR is opened (auto-generated from the feature branch).
- The PR description includes: linked issue, plan reference, spec reference, ADR references, summary of changes, test results, coverage delta.
- The Reviewer Agent performs first-pass review in both modes: checks coding standards, plan adherence, test coverage, changelog updates, commit message format, and runs security analysis (SAST, CVE scanning).
- The Reviewer Agent posts comments on the PR.
- The human performs second-pass review: validates intent, checks for subtle bugs, assesses design coherence.

**Gate:** **Human approves and merges.** Agents never merge their own work.

**Merge strategy: rebase-merge is mandatory.** Squash-merge is forbidden. The commit history — one commit per plan step — is the audit trail of how the feature was built. Squashing destroys it. Every commit must land on `main` individually, preserving the precise sequence of test → implementation → documentation commits.

---

### Phase 8: Documentation & Release

**Owner:** Release Agent (`documentation` + `deployment` modes)

**What happens:**
- The Release Agent updates documentation: README (if needed), API docs, ADR index, architecture diagrams.
- The Release Agent ensures CI/CD picks up the change and deploys to the appropriate environment.
- `CHANGELOG.md` is verified as current.
- The Git issue is closed with a reference to the merged PR.
- The project board is updated (Done).

**Gate:** None — this phase is autonomous. Outputs are verified in the next cycle.

---

### Phase 9: Retrospective & Metrics

**Owner:** Human (with agent-gathered data)

**What happens:**
- Agents log metrics for the completed work: time per phase, number of revision cycles, test coverage delta, lines of code changed, number of commits.
- Periodically (e.g., per sprint), the human reviews these metrics to identify:
  - Phases that consistently bottleneck.
  - Agent modes that need tuning (e.g., Builder Agent frequently deviates from plans in implement mode).
  - Harness gaps (e.g., `AGENTS.md` missing a convention that caused review churn).
- `AGENTS.md` and process docs are updated with lessons learned.

---

## 5. Testing Philosophy

This section is deliberately opinionated. Testing in an agentic SDLC is not optional or flexible — it is the **primary mechanism of correctness**.

### 5.1 BDD with Gherkin for Acceptance Tests

**Gherkin is the standard for acceptance-level tests.** Here's why:

- **Structured and unambiguous.** Agents parse Gherkin reliably. `Given/When/Then` maps directly to setup/action/assertion — there is no room for misinterpretation.
- **Human-readable.** Stakeholders, product managers, and engineers can all read and validate Gherkin scenarios. This makes spec review meaningful.
- **Directly tied to specs.** Acceptance criteria in the spec *are* Gherkin scenarios. There is no translation step.
- **Living documentation.** Feature files serve as always-up-to-date documentation of system behaviour.

Example:

```gherkin
Feature: User Registration

  Scenario: Successful registration with valid details
    Given the registration page is displayed
    When the user enters a valid email "alice@example.com"
    And the user enters a password that meets complexity requirements
    And the user submits the registration form
    Then the user account is created
    And a confirmation email is sent to "alice@example.com"
    And the user is redirected to the onboarding page

  Scenario: Registration rejected with duplicate email
    Given a user with email "alice@example.com" already exists
    When a new user attempts to register with email "alice@example.com"
    Then the registration is rejected
    And the error message "An account with this email already exists" is displayed
```

### 5.2 TDD for Unit Tests

**Agents must write failing unit tests before writing implementation code.** The TDD loop is:

1. **Red** — Builder Agent writes a test for the next piece of functionality. It fails.
2. **Green** — Builder Agent writes the minimum code to make the test pass.
3. **Refactor** — Builder Agent (or Reviewer Agent) cleans up without changing behaviour.

This is not aspirational. The CI pipeline must enforce that test commits precede or accompany implementation commits on the same branch.

### 5.3 Integration Tests

Integration tests cover **boundaries**: database queries, API calls, message queues, third-party service interactions. They use real (or containerised) dependencies, not mocks.

- Every external integration must have at least one happy-path and one failure-path integration test.
- Integration tests run in CI on every PR.

### 5.4 The Test Pyramid — Enforced

```
        /  E2E / Acceptance  \        ← Few, slow, high-confidence (Gherkin)
       /   Integration Tests   \      ← Moderate count, moderate speed
      /      Unit Tests          \    ← Many, fast, isolated
```

CI gates enforce minimum coverage at each layer. The following thresholds are **mandatory**. Teams that want stricter thresholds must encode them in `AGENTS.md` — but they may not go lower than these baselines:

| Layer | Minimum Coverage |
|---|---|
| Unit | **80% line coverage** — enforced by CI, PR blocked if not met |
| Integration | **All external boundaries covered** — at minimum one happy-path and one failure-path test per integration point. No PR merges with an uncovered integration boundary. |
| Acceptance | **Every Gherkin scenario in the spec must have a passing step definition.** No orphaned scenarios. No passing scenarios without a matching spec criterion. |

### 5.5 How Agents Work in TDD/BDD

The workflow for making agents operate in a test-first manner:

1. **Spec delivered** → Discovery Agent has written Gherkin acceptance criteria.
2. **Test scaffolding** → Builder Agent generates `.feature` files and unit test stubs. All fail.
3. **Plan references tests** → Each plan step specifies which test(s) it aims to make pass.
4. **Implementation drives to green** → Builder Agent writes code specifically to pass the next failing test.
5. **CI validates** → No PR merges unless all tests pass and coverage thresholds are met.

The key insight: **agents are exceptionally good at TDD** because they can hold the full context of the test, the specification, and the codebase simultaneously. TDD with agents is *easier* than TDD with humans alone. The Builder Agent's tight mode loop (test-first → implement → refactor) mirrors exactly how a senior engineer works — but without losing context between steps.

### 5.6 Definition of Done

A piece of work is **Done** when every item in the following checklist is true. This is a hard gate, not a guideline. Agents must verify this checklist before opening a PR. Humans must verify it before merging.

**Code**
- [ ] All plan steps are implemented
- [ ] Code passes linting and formatting checks (zero warnings)
- [ ] No TODO, FIXME, or placeholder comments remain in changed code

**Tests**
- [ ] All unit tests pass
- [ ] All integration tests pass
- [ ] All Gherkin acceptance scenarios pass
- [ ] Unit test coverage meets or exceeds the 80% baseline
- [ ] Every integration boundary has at least one happy-path and one failure-path test
- [ ] Every acceptance criterion in the spec has a corresponding passing scenario
- [ ] No tests are skipped, marked as pending, or commented out (without an approved ADR explaining why)

**Artifacts**
- [ ] `CHANGELOG.md` updated with user-facing changes under the correct version heading
- [ ] All ADRs referenced in the plan are in `Accepted` status
- [ ] Spec is updated if implementation deviated from original design (with reasoning noted)
- [ ] API docs regenerated (if applicable)
- [ ] Architecture diagrams updated (if applicable)

**Review**
- [ ] Reviewer Agent has completed first-pass review with no unresolved critical comments
- [ ] Reviewer Agent security audit has run with no unresolved high/critical findings
- [ ] Human has reviewed and approved the PR
- [ ] PR description is complete (linked issue, references, test results, coverage delta)

**Git**
- [ ] Branch is up to date with `main`
- [ ] Commit history follows conventional commits format
- [ ] One commit per plan step (no stray or merge commits)
- [ ] No secrets, credentials, or sensitive data in any commit

If any item is unchecked, the PR must not merge. Period.

---

## 6. Git as the Backbone

Git is not just version control. In an agentic SDLC, Git is the **coordination layer, communication medium, and single source of truth** for all work.

### 6.1 Issues

- All work starts as a Git issue (GitHub Issues, GitLab Issues, etc.).
- Agents can create sub-issues to decompose complex work.
- Issue templates enforce structure: problem statement, acceptance criteria, affected areas.
- Labels are managed by agents during triage: `type/feature`, `type/bug`, `priority/high`, `agent/research-needed`, etc.

### 6.2 Branches

- **One branch per issue.** Named: `{type}/{issue-number}-{short-description}`
  - `feat/1234-user-registration`
  - `fix/1235-null-pointer-on-login`
  - `chore/1236-upgrade-dependencies`
- Branches are created by the Discovery Agent (or Builder Agent) when the plan is approved.
- Branches are deleted after merge.

### 6.3 Commits

- **Conventional Commits** are mandatory. Format: `{type}({scope}): {description}`
  - `feat(auth): add registration endpoint`
  - `test(auth): add unit tests for password validation`
  - `docs(adr): record decision to use bcrypt for password hashing`
- **One commit per plan step.** Each commit is atomic and reviewable in isolation.
- Agents must not squash their own commits. The commit history tells the story of the implementation.

### 6.4 Pull Requests

- PRs are auto-generated when an implementation is complete (or at defined checkpoints for large features).
- PR description template (enforced by repo config):

```markdown
## Summary
[Brief description of changes]

## Linked Issue
Closes #XXXX

## References
- Spec: `docs/specs/XXXX-feature.md`
- Plan: `docs/plans/XXXX-feature.md`
- ADR(s): `docs/research/XXXX-decision.md`

## Test Results
- Unit: ✅ XX passed, 0 failed
- Integration: ✅ XX passed, 0 failed
- Acceptance: ✅ XX scenarios passed, 0 failed
- Coverage delta: +X.X%

## Changelog
Updated: Yes / No
```

- Reviewer Agent posts first-pass review.
- **Human merges.** Always.

### 6.5 Project Boards

- Agents update issue status as work progresses:
  - **Backlog** → **Triaged** → **Research** → **Spec Review** → **Planning** → **In Progress** → **In Review** → **Done**
- Board state is the live status of all work. Humans monitor the board; agents keep it current.

### 6.6 Documentation as Code

All documentation lives in the repo:

```
repo/
├── AGENTS.md
├── CHANGELOG.md
├── README.md
├── docs/
│   ├── adrs/
│   │   ├── INDEX.md
│   │   └── 0001-*.md
│   ├── specs/
│   │   └── XXXX-*.md
│   ├── research/
│   │   └── XXXX-*.md
│   ├── plans/
│   │   └── XXXX-*.md
│   └── architecture/
│       └── diagrams, overviews, etc.
├── src/
├── tests/
│   ├── unit/
│   ├── integration/
│   └── acceptance/
│       └── features/
│           └── *.feature
```

No wikis. No Confluence. No Google Docs. **If it's not in Git, it doesn't exist.**

---

## 7. Human-in-the-Loop Governance

Not every phase requires a human. But some phases **must** have human approval before proceeding. This is the governance model.

### Mandatory Human Gates

| Phase | Human Action Required |
|---|---|
| Issue prioritisation | Human moves issue to "Ready for Research" |
| Spec approval | Human reviews and approves the spec + ADRs |
| Plan approval | Human reviews and approves the implementation plan |
| Test intent review | Human confirms the right things are being tested |
| PR merge | Human approves and merges the PR |
| Infrastructure changes | Human approves Release Agent deployment proposals |

### Autonomous Agent Phases

| Phase | Agent Operates Independently |
|---|---|
| Research | Discovery Agent gathers context without waiting for approval |
| Test writing | Builder Agent writes tests based on approved spec |
| Implementation | Builder Agent follows the approved plan |
| Code + security review (first pass) | Reviewer Agent posts review comments and security findings |
| Documentation updates | Release Agent keeps docs current |
| Changelog updates | Builder Agent updates changelog during implementation |
| Issue enrichment | Agents add labels, link issues, estimate complexity |

### Escalation Protocol

Agents must stop and escalate to a human when:

- **Ambiguity:** The spec or plan is unclear or contradictory.
- **Scope creep:** Implementation reveals that the plan is insufficient — more work is needed than expected.
- **Security:** Any change touching authentication, authorisation, encryption, or secrets management.
- **Breaking changes:** Any change to a public API, database schema, or shared contract.
- **Confidence threshold:** The agent is uncertain about the correct approach (this must be made explicit, not hidden).
- **Conflict:** Two agents produce contradictory recommendations.

Escalation format: a comment on the Git issue or PR, tagged with `@human-review-needed`, clearly stating what is blocked and why.

### Scope-Based Automatic Checkpoints

Agent self-reported confidence is unreliable. Agents are frequently wrong without knowing it. Do not depend on agents to volunteer uncertainty. Instead, enforce hard scope thresholds that **trigger automatic human checkpoints regardless of agent confidence**:

| Threshold | Automatic Trigger |
|---|---|
| > 10 files changed in a single plan step | Step must be decomposed further before proceeding |
| Any change to a shared contract (API, schema, event) | Discovery Agent must co-review before implementation |
| Any new dependency added | Release Agent + human review of licence and CVE status |
| Test coverage drops | CI blocks PR, human must explicitly acknowledge and override |
| > 500 lines of net new production code in a single PR | Plan must be split into smaller PRs |

These thresholds are the minimum. Teams should adjust them in `AGENTS.md` based on codebase sensitivity. The guiding principle: **the larger the change, the more certain you must be it is correct before merging — and certainty requires human eyes, not agent confidence scores.**

---

## 8. Orchestration Model

The engineer is the **orchestrator** — the person who assigns work, reviews outputs, resolves conflicts, and keeps the pipeline moving.

### 8.1 How the Engineer Curates the Agent Team

The engineer does not work *with* one agent. They orchestrate a **team of four agents**, each with distinct modes that map to SDLC phases. The engineer's workflow is:

1. **Triage** — Review incoming issues. Prioritise. Kick off Discovery Agent (research mode).
2. **Review research** — Read the Discovery Agent's research summary. Resolve open questions.
3. **Review spec + ADRs** — Approve or request changes from the Discovery Agent (architecture mode).
4. **Review plan** — Approve or request changes from the Discovery Agent (planning mode).
5. **Review tests** — Ensure test intent from the Builder Agent (test-first mode) is correct.
6. **Monitor implementation** — Watch commits land from the Builder Agent (implement mode). Intervene if something goes off-track.
7. **Final review + merge** — Read the Reviewer Agent's comments (both code-review and security-audit). Add own review. Merge.
8. **Retro** — Review metrics from the Release Agent (monitoring mode). Tune `AGENTS.md` and process.

The engineer's time is spent **reading, thinking, and deciding** — not typing code.

### 8.2 Sequential vs. Parallel Execution

The Discovery Agent works sequentially through its modes (research → architecture → planning), with human gates between architecture and planning. The Builder Agent's modes (test-first → implement → refactor) interleave in a tight TDD loop.

Parallelism exists between agents, not within them:

- **Builder Agent + Reviewer Agent** overlap when the Reviewer Agent begins reviewing early commits while the Builder is still implementing later steps.
- **Release Agent** works in parallel with Review, updating docs as the PR is finalised.
- **Release Agent** works in parallel with implementation, adjusting CI/CD if the plan requires it.

The engineer decides when to parallelise based on dependencies.

### 8.3 Agent Communication Medium

Agents communicate through **Git artifacts**, not direct messages:

- Discovery Agent research summaries, specs, and plans inform the Builder Agent.
- PRs inform the Reviewer Agent.
- Merged PRs inform the Release Agent.
- All artifacts are versioned and auditable.

There is no "agent-to-agent chat." The shared medium is the repository. This is deliberate: it ensures all context is durable, versioned, and visible to humans.

---

## 9. Tooling: Invoking Agent Modes

The 4-agent model maps directly to 4 agent files — one per agent, not one per mode. Modes are invoked by commanding the active agent to shift behaviour, not by switching to a different agent. This preserves the full context window across all phases within an agent's scope (e.g., the Discovery Agent retains research context when moving into architecture and planning).

### 9.1 File Structure

```
your-repo/
├── AGENTS.md                              # Always-on context (both tools read this)
├── .github/
│   ├── copilot-instructions.md            # Copilot always-on project instructions
│   ├── agents/                            # 4 Copilot custom agents
│   │   ├── discovery.agent.md
│   │   ├── builder.agent.md
│   │   ├── code-reviewer.agent.md
│   │   └── release.agent.md
│   └── prompts/                           # Mode-invocation slash commands
│       ├── research.prompt.md
│       ├── architecture.prompt.md
│       ├── planning.prompt.md
│       ├── test-first.prompt.md
│       ├── implement.prompt.md
│       ├── refactor.prompt.md
│       ├── code-review.prompt.md
│       ├── security-audit.prompt.md
│       ├── documentation.prompt.md
│       └── deployment.prompt.md
└── .opencode/
    ├── agents/                            # 4 OpenCode custom agents
    │   ├── discovery.md
    │   ├── builder.md
    │   ├── reviewer.md
    │   └── release.md
    └── commands/                          # Mode-invocation commands
        ├── research.md
        ├── architecture.md
        ├── planning.md
        ├── test-first.md
        ├── implement.md
        ├── refactor.md
        ├── code-review.md
        ├── security-audit.md
        ├── documentation.md
        └── deployment.md
```

The agent files define identity and permissions. The prompt/command files invoke specific modes within the active agent — shifting its focus without losing context.

### 9.2 GitHub Copilot (VS Code)

Copilot uses **custom agents** (`.agent.md` in `.github/agents/`) for the 4 agents, and **prompt files** (`.prompt.md` in `.github/prompts/`) as slash commands to activate modes within each agent.

**How to switch:** Click the agent picker dropdown in Chat view to select an agent. Within a session, type `/research`, `/architecture`, `/planning` etc. to invoke the mode-shift prompt for that phase.

#### The 4 Agent Files

**`.github/agents/discovery.agent.md`**

```markdown
---
description: "Understand the problem, design the solution, plan the build"
name: "discovery"
tools: ['search', 'codebase', 'fetch', 'editFiles']
model: Claude Sonnet 4 (copilot)
---

# Discovery Agent

You handle Phases 2-4: research, architecture, and planning.
You move through these modes sequentially — research first, then architecture once
the human has reviewed the research, then planning once the spec is approved.

Active mode is set by the prompt command used to invoke you (e.g., `/research`,
`/architecture`, `/planning`). Follow that command's instructions precisely.

Always follow the conventions in #file:AGENTS.md.
Artifacts go in: docs/research/, docs/specs/, docs/research/, docs/plans/.
```

**`.github/agents/builder.agent.md`**

```markdown
---
description: "Write tests and production code — TDD loop"
name: "builder"
tools: ['search', 'codebase', 'editFiles', 'runInTerminal']
model: Claude Sonnet 4 (copilot)
---

# Builder Agent

You handle Phases 5-6: test scaffolding, implementation, and refactoring.
You work in a tight TDD loop within a single session, retaining full codebase context.

Active mode is set by the prompt command (e.g., `/test-first`, `/implement`, `/refactor`).
Follow the approved plan in docs/plans/ exactly.
If the plan is insufficient, STOP and escalate — do not improvise.

Follow conventions in #file:AGENTS.md.
```

**`.github/agents/code-reviewer.agent.md`**

```markdown
---
name: code-reviewer
description: "Independent quality gate — code review and security audit. Reviews diffs and proposes minimal, high-signal changes."
tools: ['vscode', 'execute', 'read', 'agent', 'search', 'web']
model: Claude Sonnet 4.6 (copilot)
argument-hint: The diff, PR link, or files to review
agents: ["*"]
---

# Code Reviewer Agent

You are the **independent quality gate** (Phase 7). You review code and surface issues — you must **never modify code**.

Active mode is set by the prompt command (`/code-review`, `/security-audit`). Run both on every PR.
You **cannot** approve or merge — that is a human action.

Follow conventions in #file:AGENTS.md, #file:rules/code-review.md, and #file:rules/security.md.
```

**`.github/agents/release.agent.md`**

```markdown
---
description: "Post-merge operations — documentation, deployment, monitoring"
name: "release"
tools: ['search', 'codebase', 'editFiles', 'runInTerminal']
model: Claude Sonnet 4 (copilot)
---

# Release Agent

You handle Phase 8: documentation updates, deployment, and monitoring.
You operate on the merged result. No feature code authoring.

Active mode is set by the prompt command (`/documentation`, `/deployment`).
Follow conventions in #file:AGENTS.md.
```

#### Mode-Invocation Prompt Files

Prompt files are slash commands typed within an active agent session. They shift the agent's focus to a specific mode without losing session context.

**`.github/prompts/research.prompt.md`** (type `/research` in Discovery session)

```markdown
---
description: "Enter research mode — gather context, produce research summary"
---

Enter RESEARCH mode. Your mandate for this phase:

1. Read the issue: ${input:Issue number or description}
2. Explore the codebase — read relevant files, search for patterns
3. Examine prior ADRs in docs/research/ and specs in docs/specs/
4. Gather external context via fetch if needed
5. Produce a research summary following the `research-topic` skill

Save to: docs/research/XXXX-issue-title.md
Do NOT write production code. Do NOT design a solution yet.
When done, tell me so I can review before you proceed to architecture mode.
```

**`.github/prompts/architecture.prompt.md`** (type `/architecture` in Discovery session)

```markdown
---
description: "Enter architecture mode — design solution, write spec and ADRs"
---

Enter ARCHITECTURE mode. The research has been reviewed. Your mandate:

1. Read the research summary in docs/research/
2. Design the technical solution and evaluate trade-offs
3. Write a feature spec with Gherkin acceptance criteria → docs/specs/XXXX-feature.md
4. Draft ADRs for non-trivial decisions → docs/research/XXXX-decision.md
   Rule: if a reasonable engineer might disagree, it needs an ADR

Follow the `write-spec` and `research-topic` skills.
Do NOT write implementation code or a plan.
When done, tell me so I can review spec + ADRs before you proceed to planning mode.
```

**`.github/prompts/planning.prompt.md`** (type `/planning` in Discovery session)

```markdown
---
description: "Enter planning mode — produce step-by-step implementation plan"
---

Enter PLANNING mode. The spec has been approved. Your mandate:

1. Read the approved spec and ADRs
2. Decompose into atomic steps — each completable in one commit
3. For each step: what to change, which tests to write/pass, commit message
4. Reference spec and ADRs by filename

Save to: docs/plans/XXXX-feature.md
Follow the `write-plan` skill.
Do NOT write code or tests.
When done, tell me so I can approve the plan before implementation begins.
```

**`.github/prompts/test-first.prompt.md`** (type `/test-first` in Builder session)

```markdown
---
description: "Enter test-first mode — write failing tests from spec"
---

Enter TEST-FIRST mode. The plan has been approved. Your mandate:

1. Read the approved spec (Gherkin acceptance criteria) and plan
2. Write .feature files with all scenarios
3. Write step definition stubs
4. Write unit test stubs for expected functions/modules

All tests MUST FAIL — there is no implementation yet.
Commit: test(scope): scaffold failing tests for XXXX
Do NOT write production code.
When done, tell me so I can review test intent before implementation.
```

**`.github/prompts/implement.prompt.md`** (type `/implement` in Builder session)

```markdown
---
description: "Enter implement mode — write code to pass failing tests, one step at a time"
---

Enter IMPLEMENT mode. Test intent has been reviewed. Your mandate:

1. Follow the plan in docs/plans/ step by step
2. Write minimum code to make the next failing test pass
3. Run tests after each change to confirm green
4. One atomic commit per plan step
5. Update CHANGELOG.md with user-facing changes

Commit format: feat(scope): description
If the plan is insufficient, STOP and tell me — do not improvise.
Do not move to the next step until the current step's tests are green.
```

**`.github/prompts/code-review.prompt.md`** (type `/code-review` in Reviewer session)

```markdown
---
description: "Enter code-review mode — review diff against standards and plan"
---

Enter CODE-REVIEW mode. Your mandate:

1. Run: git diff main...HEAD
2. Check against coding standards in #file:AGENTS.md
3. Verify plan adherence — compare changes to docs/plans/
4. Check test coverage — are all acceptance criteria covered?
5. Verify CHANGELOG.md is updated
6. Validate commit messages: git log main..HEAD --oneline

Post findings as a structured report: blockers / warnings / notes.
You CANNOT approve or merge. When done, proceed to /security-audit.
```

**`.github/prompts/security-audit.prompt.md`** (type `/security-audit` in Reviewer session)

```markdown
---
description: "Enter security-audit mode — SAST, secrets detection, CVE scanning"
---

Enter SECURITY-AUDIT mode. Your mandate:

1. Review changed files: git diff main...HEAD
2. Check for: hardcoded secrets, injection, XSS, auth issues, input validation gaps
3. Check dependency manifests for known CVEs
4. Validate no credentials in code

Severity: Critical/High = BLOCKER. Medium = must address. Low = advisory.
Follow #file:rules/security.md.
When done, post combined code-review + security findings for human review.
```

### 9.3 OpenCode

OpenCode uses **4 agent files** (`.opencode/agents/*.md`) for identity and permissions, and **commands** (`.opencode/commands/*.md`) to invoke modes within the active agent via `Ctrl+K`.

**How to switch agents:** `Tab` cycles primary agents. **How to invoke a mode:** `Ctrl+K` → select the command. The command is injected into the current agent's session — context is preserved.

#### The 4 Agent Files

**`.opencode/agents/discovery.md`**

```markdown
---
description: "Understand the problem, design the solution, plan the build (Phases 2-4)"
mode: primary
color: "#38A3EE"
permission:
  read: allow
  edit: allow
  write: allow
  bash: deny
---

# Discovery Agent

You handle research, architecture, and planning — sequentially, in one session.
Your active mode is set by the command invoked at the start of each phase.

Follow all conventions in AGENTS.md.
Artifacts: docs/research/, docs/specs/, docs/research/, docs/plans/.
```

**`.opencode/agents/builder.md`**

```markdown
---
description: "Write tests and production code — TDD loop (Phases 5-6)"
mode: primary
color: "#2ECC71"
steps: 50
permission:
  read: allow
  edit: allow
  write: allow
  bash: allow
---

# Builder Agent

You handle test scaffolding, implementation, and refactoring in a tight TDD loop.
Your active mode is set by the command invoked at the start of each step.

Follow the approved plan in docs/plans/ exactly.
If the plan is insufficient, STOP and escalate — do not improvise.
Follow all conventions in AGENTS.md.
```

**`.opencode/agents/reviewer.md`**

```markdown
---
description: "Independent quality gate — code review and security audit (Phase 7)"
mode: primary
color: "#E74C3C"
permission:
  read: allow
  edit: deny
  write: deny
  bash: allow
---

# Reviewer Agent

You handle code review and security audit in a single pass.
edit: deny and write: deny are enforced — you physically cannot modify the code you review.

Your active mode is set by the command invoked. Run both code-review then security-audit
on every PR. Post findings as a structured report.
You CANNOT approve or merge — that is a human action.

Follow AGENTS.md and rules/security.md.
```

**`.opencode/agents/release.md`**

```markdown
---
description: "Post-merge operations — documentation, deployment, monitoring (Phase 8)"
mode: primary
color: "#8E44AD"
permission:
  read: allow
  edit: allow
  write: allow
  bash: ask
---

# Release Agent

You handle documentation updates, deployment, and monitoring after merge.
No feature code authoring. bash: ask ensures human confirms any shell operations.

Follow AGENTS.md.
```

#### Mode-Invocation Commands

Commands are invoked with `Ctrl+K` within the active agent session. They inject mode-specific instructions without switching agents or losing context.

**`.opencode/commands/research.md`**

```markdown
Enter RESEARCH mode.

1. Read the issue: $ISSUE
2. Explore the codebase — grep, glob, and read relevant files
3. Examine prior ADRs in docs/research/ and specs in docs/specs/
4. Use webfetch/websearch for external context if needed
5. Produce a research summary following the `research-topic` skill

RUN ls docs/research/ docs/specs/

Save to: docs/research/XXXX-issue-title.md
Do NOT write production code. Do NOT design a solution yet.
Tell me when done so I can review before you proceed to architecture.
```

**`.opencode/commands/architecture.md`**

```markdown
Enter ARCHITECTURE mode. Research has been reviewed.

1. Read the research summary: RUN ls docs/research/
2. Design the technical solution and evaluate trade-offs
3. Write a feature spec with Gherkin acceptance criteria → docs/specs/
4. Draft ADRs for non-trivial decisions → docs/research/
   Rule: if a reasonable engineer might disagree, it needs an ADR

Follow the `write-spec` and `research-topic` skills.
Do NOT write implementation code or a plan.
Tell me when done so I can approve spec + ADRs before planning.
```

**`.opencode/commands/planning.md`**

```markdown
Enter PLANNING mode. Spec has been approved.

1. RUN ls docs/specs/ docs/research/
2. Decompose into atomic steps — each completable in one commit
3. For each step: what to change, which tests to write/pass, commit message
4. Reference spec and ADRs by filename

Save to: docs/plans/XXXX-feature.md (follow the `write-plan` skill).
Do NOT write code or tests.
Tell me when done so I can approve the plan before implementation begins.
```

**`.opencode/commands/test-first.md`**

```markdown
Enter TEST-FIRST mode. Plan has been approved.

1. RUN cat docs/plans/$(ls docs/plans/ | tail -1)
2. Write .feature files with all Gherkin scenarios
3. Write step definition stubs
4. Write unit test stubs for expected functions

All tests MUST FAIL — no implementation yet.
RUN the test suite to confirm all fail.
Commit: test(scope): scaffold failing tests for XXXX
Tell me when done so I can review test intent.
```

**`.opencode/commands/implement.md`**

```markdown
Enter IMPLEMENT mode. Test intent reviewed.

1. RUN cat docs/plans/$(ls docs/plans/ | tail -1)
2. Work through the plan step by step
3. Write minimum code to pass the next failing test
4. RUN tests after each change — confirm green before moving on
5. One commit per plan step
6. Update CHANGELOG.md with user-facing changes

Commit format: feat(scope): description
If the plan is insufficient, STOP and tell me — do not improvise.
```

**`.opencode/commands/code-review.md`**

```markdown
Enter CODE-REVIEW mode.

RUN git diff main...HEAD --stat
RUN git log main..HEAD --oneline

For each changed file:
1. Check against coding standards in AGENTS.md
2. Compare changes to docs/plans/
3. Verify test coverage — all acceptance criteria covered?
4. Verify CHANGELOG.md updated
5. Validate conventional commit messages

Post structured findings: blockers / warnings / notes.
Then proceed directly to security-audit mode.
```

**`.opencode/commands/security-audit.md`**

```markdown
Enter SECURITY-AUDIT mode.

RUN git diff main...HEAD

Check for:
- Hardcoded secrets, API keys, credentials
- SQL injection, XSS, input validation gaps
- Auth/authz logic issues
- Dependency CVEs — check lock files
- Output encoding gaps

Severity: Critical/High = BLOCKER. Medium = must address. Low = advisory.
Follow rules/security.md.
Append findings to the code-review report above.
```

**`.opencode/commands/documentation.md`**

```markdown
Enter DOCUMENTATION mode.

RUN git diff main...$(git merge-base main HEAD) --name-only

1. Update README if user-facing behaviour changed
2. Regenerate API docs if endpoints changed
3. RUN cat docs/research/INDEX.md and update with any new ADRs
4. Verify CHANGELOG.md is current and accurate

Commit: docs(scope): update documentation for XXXX
```

### 9.4 Quick Reference

| SDLC Phase | Agent | Copilot: slash command | OpenCode: `Ctrl+K` command |
|---|---|---|---|
| 2. Research | Discovery | `/research` | `research` |
| 3. Specification | Discovery | `/architecture` | `architecture` |
| 4. Planning | Discovery | `/planning` | `planning` |
| 5. Test Scaffolding | Builder | `/test-first` | `test-first` |
| 6. Implementation | Builder | `/implement` | `implement` |
| 6. Cleanup | Builder | `/refactor` | `refactor` |
| 7. Code Review | Reviewer | `/code-review` | `code-review` |
| 7. Security Audit | Reviewer | `/security-audit` | `security-audit` |
| 8. Documentation | Release | `/documentation` | `documentation` |
| 8. Deployment | Release | `/deployment` | `deployment` |

### 9.5 Why Permissions Matter

OpenCode's permission system enforces structural boundaries at the OS level — not just via instructions:

| Agent | `edit`/`write` | `bash` | Effect |
|---|---|---|---|
| Discovery | `allow` | `deny` | Can produce artifacts; cannot run arbitrary shell. Prevents accidental code changes. |
| Builder | `allow` | `allow` | Full access needed for TDD loop (run tests, write code). |
| Reviewer | **`deny`** | `allow` | **Cannot modify the code it reviews.** Separation is enforced, not instructed. |
| Release | `allow` | `ask` | Can update docs; must confirm before any shell operation (deploy, pipeline change). |

Copilot achieves the same separation via `tools:` scoping in `.agent.md` frontmatter, backed by instruction constraints. The Reviewer's inability to call `editFiles` is the critical boundary in both tools.

---

## 10. Artifacts & Templates

Every artifact produced in this SDLC follows a standardised template. Templates reduce ambiguity, make agent output consistent, and simplify human review.

### 10.1 Research Summary Template

```markdown
# Research: [Issue Title]

**Issue:** #XXXX
**Date:** YYYY-MM-DD
**Agent:** Discovery (research mode)

## Problem Statement
[What are we trying to solve?]

## Current State
[How does the codebase handle this today? Relevant code pointers.]

## Prior Decisions
[Relevant ADRs, past discussions, related issues.]

## External Context
[Libraries, standards, industry patterns relevant to this problem.]

## Risks & Unknowns
[What could go wrong? What don't we know yet?]

## Recommended Approach
[The Researcher's suggested direction, with rationale.]

## Open Questions
[Questions that must be answered before spec can be written.]
```

### 10.2 Feature Spec Template

```markdown
# Spec: [Feature Title]

**Issue:** #XXXX
**Date:** YYYY-MM-DD
**Status:** Draft | Under Review | Approved

## Problem Statement
[What problem does this feature solve?]

## Desired Outcome
[What does success look like?]

## Acceptance Criteria

​```gherkin
Feature: [Feature Title]

  Scenario: [Happy path]
    Given ...
    When ...
    Then ...

  Scenario: [Edge case]
    Given ...
    When ...
    Then ...
​```

## Scope
[What is included in this feature.]

## Non-Goals
[What is explicitly excluded.]

## Non-Functional Requirements
| Requirement | Target | How Verified |
|---|---|---|
| Performance | e.g., p99 < 200ms | Load test / profiling |
| Scalability | e.g., handles 10k concurrent users | Load test |
| Accessibility | WCAG 2.1 AA | Automated audit + manual review |
| Security | No new CVEs introduced, input validated | Reviewer Agent security audit + SAST |
| Availability | e.g., 99.9% uptime | Monitoring / alerting |

(Remove rows that are not applicable. If all are not applicable, justify why in the spec.)

## Dependencies
[Other features, services, or teams this depends on.]

## ADRs
[Links to any ADRs produced alongside this spec.]
```

### 10.3 ADR Template

```markdown
# ADR-XXXX: [Decision Title]

**Date:** YYYY-MM-DD
**Status:** Proposed | Accepted | Deprecated | Superseded by ADR-YYYY

## Context
[Why is this decision needed? What is the problem?]

## Decision
[What is the decision? Be specific.]

## Consequences
[What are the positive and negative consequences of this decision?]

## Alternatives Considered
[What other options were evaluated, and why were they rejected?]
```

### 10.4 Implementation Plan Template

```markdown
# Plan: [Feature Title]

**Issue:** #XXXX
**Spec:** `docs/specs/XXXX-feature.md`
**ADRs:** `docs/research/XXXX-decision.md`
**Date:** YYYY-MM-DD
**Status:** Draft | Approved

## Steps

### Step 1: [Short description]
- **Agent:** Builder
- **Action:** [What code to write or change]
- **Tests:** [Which tests this step should make pass]
- **Commit message:** `feat(scope): description`

### Step 2: [Short description]
- **Agent:** ...
- **Action:** ...
- **Tests:** ...
- **Commit message:** ...

[... repeat for all steps ...]

## Risks & Mitigations
[Anything that might go wrong during implementation and how to handle it.]
```

---

## 11. Metrics & Continuous Improvement

What gets measured gets improved. The agentic SDLC must track key metrics to identify bottlenecks, tune agent behaviour, and improve the process over time.

### 11.1 Metrics to Track

| Metric | What It Measures |
|---|---|
| **Cycle time** | Time from issue creation to PR merge |
| **Phase duration** | Time spent in each SDLC phase |
| **Revision count** | Number of times a spec, plan, or PR was sent back for changes |
| **Test coverage delta** | Coverage change per PR |
| **Agent deviation rate** | How often the Builder Agent deviates from the approved plan |
| **Escalation frequency** | How often agents escalate to humans (too high = poor specs; too low = agents hiding uncertainty) |
| **Review comment density** | Number of review comments per PR (trending down = improving quality) |
| **Time in review** | How long PRs sit before merge (bottleneck indicator) |

### 11.2 Feedback Loops

- **Per-PR:** Reviewer Agent notes are reviewed. Recurring issues trigger an `AGENTS.md` update.
- **Per-sprint:** Human reviews metrics dashboard. Identifies slow phases, high-revision artifacts, and agent quality trends.
- **Per-quarter:** Process retro. Are the phases right? Do we need new agent profiles? Is `AGENTS.md` effective?

### 11.3 Evolving the Harness

The harness is not static. As the team learns:

- `AGENTS.md` gets new rules when patterns emerge.
- Templates get refined when agents consistently produce suboptimal artifacts.
- New agent modes are introduced when a gap is identified (e.g., a dedicated compliance mode for the Reviewer Agent in regulated domains).
- Phases are adjusted if a gate is consistently unnecessary or a missing gate is causing issues.

### 11.4 Agent Model Updates

When an agent's underlying model is updated or replaced, treat it like a new hire — it must be onboarded. The process:

1. Run the new agent against a set of previously-completed issues (with known-good outputs for comparison).
2. Identify any behavioural changes against `AGENTS.md` expectations.
3. Update `AGENTS.md` if new capabilities make old rules redundant, or add new constraints if the model introduces new failure modes.
4. Do not swap agent models mid-sprint. Model updates are planned changes, not hotfixes.

### 11.5 Multi-Repo and Monorepo

This SDLC is designed to be repo-agnostic, with two common configurations:

- **Monorepo:** A single root `AGENTS.md` sets baseline conventions. Sub-packages may have their own `AGENTS.md` to define package-specific overrides. The root always wins on conflicts.
- **Multi-repo:** Each repo has its own full harness. A shared organisation-level `AGENTS.md` template should be maintained so conventions stay consistent across repos. Cross-repo work requires an issue in each affected repo, linked together, with a coordinating plan that explicitly sequences work across repos.

---

---

## 12. Hotfix Track

Production incidents cannot wait for Research → Spec → Plan → Test Scaffolding → Implementation. A compressed track exists for urgent production fixes.

### When to Use the Hotfix Track

- A production system is down or severely degraded.
- A security vulnerability is actively being exploited or imminently exploitable.
- Data integrity is at risk.

The engineer declares a hotfix. This is a human decision, not an agent decision.

### Hotfix Phases

```
Hotfix Issue → Diagnose → Implement → Test → Human Review → Merge → Backfill
```

| Phase | Owner | Notes |
|---|---|---|
| **Hotfix Issue** | Human | Created with `type/hotfix` label. Describes the incident, impact, and urgency. |
| **Diagnose** | Discovery Agent | Rapid (time-boxed to 30 minutes). Identify root cause. Commit a brief diagnosis note to the issue. |
| **Implement** | Builder Agent | Minimal change to address root cause. No refactoring. No scope expansion. Branch: `hotfix/{issue-number}-{description}`. |
| **Test** | Builder Agent | Must write at least one regression test that would have caught this bug before it reached production. |
| **Human Review** | Human | Expedited review. Reviewer Agent still runs — but Human does not wait for a full first-pass. Human and agent review simultaneously. |
| **Merge** | Human | Rebase-merge onto `main`. Deploy immediately. |
| **Backfill** | All agents | After the incident is resolved: write a proper spec, update CHANGELOG, file an ADR if a design decision was made under pressure, and add the full test coverage that was skipped. |

### Hotfix Rules

- **Minimum viable fix.** The hotfix must change only what is necessary to resolve the incident. Anything else goes on a follow-up issue in the standard track.
- **Regression test is mandatory.** A hotfix without a regression test is not done — it is deferred.
- **Backfill is not optional.** The backfill work is created as a standard-track issue at the time of merge, not later. It gets prioritised in the next sprint.
- **Post-incident ADR.** If the hotfix involved a design decision (e.g., disabling a feature, changing a default), that decision must be documented as an ADR in the backfill.
- **Changelog updated.** Even under pressure, `CHANGELOG.md` must be updated before merge.

---

## 13. Incremental Adoption

This SDLC is designed for greenfield projects but most real codebases are not greenfield. Do not attempt to retrofit the full harness at once — but equally, do not take months to get there. The industry is moving at pace. A team that takes three months to adopt agentic coding is already behind. **The target is full adoption in two weeks.**

### The Two-Week Blitz

This is an intensive, deliberate adoption sprint. It requires dedicated engineering time — pull at least one senior engineer off feature work for the two weeks. The cost is front-loaded; the productivity gain is compounding.

**Days 1–2: Lock the foundations**
- Create `AGENTS.md`. Document every coding convention the team already follows — even informal ones. Treat this as the most important document the team will write this year.
- Enable branch protection on `main`. No direct push. PRs required. CI must pass.
- Enforce conventional commits via commit-msg hook and CI check. No exceptions from Day 1.
- Create the full `docs/` directory structure (`adrs/`, `specs/`, `research/`, `plans/`) with placeholder `README.md` files.
- Initialise `CHANGELOG.md`.
- Set up the PR template.

**Days 3–4: Wire the CI pipeline**
- Configure unit test runner with diff-based coverage gate (new/changed code only — do not gate on total coverage for legacy code).
- Configure integration test runner. If no integration tests exist, write one for the most critical external boundary (auth, payments, core data layer).
- Configure acceptance test runner. If no Gherkin infrastructure exists, set up the framework and write one passing dummy scenario to confirm the pipeline works end to end.
- Configure SAST / Reviewer Agent security audit scanning on the PR pipeline.
- Confirm the full pipeline runs green before Day 5.

**Days 5–7: Run a live feature through the full process**
- Pick a real, planned feature (not a toy). Run it through all 9 phases with agents from Day 1.
- This is the proof of concept. Everything will feel slow — that is normal. The goal is to identify friction in the process, not to ship fast.
- Document friction points in `AGENTS.md` as lessons learned in real time.
- By the end of Day 7: a committed spec, a committed plan, failing tests, a partial implementation, and a draft PR with agent review comments.

**Days 8–10: Complete and ship**
- Finish the feature. Merge it using the full process. Ship it.
- Retrospective: what did agents do well? Where were human gates slow? Were templates right? Update `AGENTS.md` and all templates with everything learned.
- Identify the two or three biggest gaps in `AGENTS.md` and fill them immediately.

**Days 11–14: Scale to the whole team**
- Every engineer follows the process for their next task. No exemptions.
- Run a 30-minute orientation: walk through `AGENTS.md`, the template files, and the live feature that was just shipped as a worked example.
- Assign a "harness owner" — one engineer responsible for keeping `AGENTS.md` and templates current. This rotates quarterly.
- Begin tracking phase duration metrics. The first two weeks of data establish the baseline.

### Why Two Weeks, Not Three Months

The three-month model was designed to avoid disrupting teams that couldn't pause to adopt. But that tradeoff has flipped. The cost of slow adoption now exceeds the cost of the disruption. Waiting until Month 3 to write specs means two months of unspecced agent code that nobody fully understands. **Ship one real feature the right way in the first two weeks, and the rest of the team will follow — because they will have seen it work.**

### Rules for Adoption

- **New code must meet new standards from Day 1.** Old code gets a pass; new code does not. The PR is the boundary.
- **Never rewrite legacy code for its own sake.** Refactor only when it unblocks a feature or fixes a defect.
- **Track adoption honestly in `AGENTS.md`.** Mark sections as: `✅ Adopted`, `⚠️ Partial`, or `🔲 Aspirational`. Agents must not treat aspirational rules as enforced.
- **The harness owner has veto power.** If a PR shortcuts the process without a documented reason, the harness owner blocks it. No exceptions.

---

## 14. Rollback & Error Recovery

Merged code can cause production incidents. The SDLC must have a clear stance on how to respond, and a clear comparison of the options available. There are three distinct rollback strategies — each with different trade-offs. Choosing the wrong one makes a bad situation worse.

---

### Strategy Comparison

| | **Deploy Rollback** | **Feature Flags** | **Git Revert** |
|---|---|---|---|
| **What it is** | Redeploy the previous known-good artifact (container image, binary, package) — no code change | A runtime switch that disables the broken code path without a deployment | A new commit that inverts the changes of the bad merge commit |
| **Time to stability** | Seconds to minutes | Near-instant if flag infrastructure exists | Medium — commit, CI run, deploy |
| **Code state after** | Same as pre-deploy — artifact and code match previous release | Bad code still in `main`, just disabled at runtime | Clean — `main` reflects production |
| **Database migrations** | ❌ Does not reverse migrations | ❌ Does not reverse migrations | ❌ Does not reverse migrations |
| **Requires prior investment** | Yes — artifact retention and deploy automation must exist | Yes — flag infrastructure + feature built to respect the flag | No — always available |
| **Best for** | Any stateless deployment where the artifact is retained | Features being progressively rolled out or released to a subset | Code-only changes with no schema side-effects |
| **Agent can execute autonomously?** | ✅ Release Agent triggers redeploy from CI/CD | ✅ Release Agent flips the flag value in config store | ✅ Release Agent raises the revert PR |
| **Human approval required?** | Yes — human confirms before rollback executes | Yes — for disabling flags in production | Yes — revert PR must be approved |

---

### When to Use Which

**Deploy Rollback — use this first** when:
- Artifact retention exists in your CI/CD pipeline (it should — this is a hard requirement).
- The change is self-contained with no schema migration.
- You need production stable in under 5 minutes.

This is the fastest path to stability. No code change, no CI run. The Release Agent triggers redeployment of the previous artifact through the CI/CD platform. Once stable, investigate at leisure.

**Feature Flags — use these** when:
- The feature was already behind a flag (significant features always should be).
- You need to disable behaviour without any deployment cycle — instant effect.
- Only a subset of users is affected (flag lets you disable for all, or roll back gradually).

Feature flags require prior investment: the infrastructure must exist and the feature must have been built to respect it. This is why **significant features must be built behind a flag by default**. The Release Agent flips the flag value in the config store or flag service. No redeployment. No code change. Fastest possible user-facing recovery.

**Git Revert — use this** when:
- No artifact retention exists (only acceptable in very early-stage projects — fix this gap).
- Deploy rollback would restore a different broken state (e.g., multiple subsequent deploys have landed).
- The change is code-only, CI is fast, and revert → CI → deploy is still the fastest path.

The Release Agent creates a `git revert` of the bad merge commit and opens a PR tagged `@human-review-needed`. The revert PR skips the full harness — CI must pass and a human must approve, nothing more.

---

### Decision Flow

```
Production incident detected
          |
          v
  Was a migration run? --Yes--> Deploy rollback is unsafe. Feature flag is only safe option.
          |                      If no flag exists: fix forward via hotfix track.
          No
          |
          v
  Is artifact retention available AND no subsequent deploys?
       Yes --> Deploy Rollback. Target: stable within 5 minutes.
       No  --> Was feature behind a flag?
                    Yes --> Flip flag. Instant user-facing recovery.
                    No  --> Git Revert via Release Agent.
```

---

### Post-Incident Process

Regardless of which rollback strategy was used, the post-incident process is identical:

1. **Root cause analysis** — Discovery Agent produces a root cause summary committed to `docs/research/`.
2. **Regression test** — Builder Agent writes a test that would have caught the issue before production.
3. **ADR (if applicable)** — If the incident revealed a flawed design decision, an ADR documents the original decision, why it was wrong, and what replaces it. The original ADR is marked Superseded.
4. **AGENTS.md update** — If an agent violated a convention not in `AGENTS.md`, add it.
5. **Fix in standard track** — The corrected implementation goes through the full SDLC with a proper spec and plan.
6. **Infrastructure gap review** — If the incident was made worse by missing rollback infrastructure (no artifact retention, no feature flags), raise an issue to add it. That gap is the actual root cause.

### The Rollback-Readiness Rule

A system that cannot be restored in under 5 minutes is not production-ready. Before shipping any significant feature, confirm:

- [ ] Previous artifact is retained and redeployable by the Release Agent
- [ ] OR the feature is behind a feature flag that can be disabled without a deploy
- [ ] Schema migrations (if any) are backwards-compatible with the previous code version
- [ ] Release Agent has the access and tooling to execute the chosen rollback strategy (pending human approval)

---

## Summary: The Agentic SDLC at a Glance

### The 4-Agent Model

```
 ┌─────────────────────────────────────────────────────────────┐
 │  DISCOVERY AGENT                                            │
 │  Modes: research · architecture · planning                  │
 │  Outputs: research docs, specs, ADRs, plans                 │
 └──────────────────────────┬──────────────────────────────────┘
                            │ plan approved by human
                            ▼
 ┌─────────────────────────────────────────────────────────────┐
 │  BUILDER AGENT                                              │
 │  Modes: test-first · implement · refactor                   │
 │  Outputs: tests, production code, one commit per step       │
 └──────────────────────────┬──────────────────────────────────┘
                            │ PR opened
                            ▼
 ┌─────────────────────────────────────────────────────────────┐
 │  REVIEWER AGENT                                             │
 │  Modes: code-review · security-audit                        │
 │  Outputs: review comments, security findings                │
 └──────────────────────────┬──────────────────────────────────┘
                            │ human approves + merges
                            ▼
 ┌─────────────────────────────────────────────────────────────┐
 │  RELEASE AGENT                                              │
 │  Modes: documentation · deployment · monitoring             │
 │  Outputs: docs, deployments, metrics                        │
 └─────────────────────────────────────────────────────────────┘
```

### Standard Track (9 Phases)

```
 ┌─────────────┐    ┌────────────┐    ┌──────────────┐    ┌──────────┐
 │  1. Issue / │  ▶ │2. Research │ ▶ │ 3. Spec + ADRs │ ▶ │ 4. Plan  │
 │   Intake    │    │ (Discovery │    │  (Discovery   │    │(Discovery│
 │             │    │ /research) │    │ /architecture)│    │/planning)│
 └─────────────┘    └────────────┘    └──────────────┘    └──────────┘
  [Human: Triage]    [Human: Research     [Human: Spec +     [Human: Plan
                      Review]              ADR Approval]      Approval]
                                                                  │
                                                                  ▼
 ┌─────────────┐    ┌────────────┐    ┌──────────────┐    ┌──────────┐
 │ 9. Retro &  │ ◄ │ 8. Docs &  │ ◄ │  7. Review   │ ◄ │ 5. Test  │
 │  Metrics    │    │  Release   │    │  (Reviewer   │    │ Scaffold │
 │  (Release)  │    │ /docs+dep) │    │  /review+sec)│    │(Builder  │
 └─────────────┘    └────────────┘    └──────────────┘    │/test-1st)│
  [Human: Retro]    [Autonomous]      [Human: Merge]    └──────────┘
                                                          [Human: Test
                                                          Intent Review]
                                                                  │
                                                                  ▼
                                               ┌──────────────┐
                                               │ 6. Implement │
                                               │  (Builder    │
                                               │  /implement) │
                                               └──────────────┘
                                                [CI gates enforce
                                                 DoD automatically]
```

### Human Gates at a Glance

| Phase | Gate |
|---|---|
| 1. Issue / Intake | Human prioritises → Research |
| 2. Research | Human approves research summary |
| 3. Spec + ADRs | Human approves spec and all ADRs |
| 4. Plan | Human approves implementation plan |
| 5. Test Scaffolding | Human confirms test intent |
| 6. Implementation | CI gates (automated DoD enforcement) |
| 7. Review | Human approves and rebase-merges |
| 8. Docs & Release | Autonomous |
| 9. Retro & Metrics | Human-led periodic review |

**The harness makes it work. Four agents do the heavy lifting. The human holds the reins.**

---

*This is a living document. Update it as the process evolves. Version it in Git. Practice what it preaches.*
