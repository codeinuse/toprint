# Sample Workflow: End-to-End Agentic SDLC

> A complete walkthrough of the 9-phase Standard track, simulating a real feature
> from issue to deployment. Shows every agent/mode, prompt command, artifact, commit,
> and human gate — using only the tooling that exists in this repo.

**Feature:** User Password Reset  
**Track:** Standard (all 9 phases)  
**Issue:** #42

---

## Quick Reference

| Phase | Who / Mode | Prompt Command | Artifact(s) | Human Gate |
|-------|------------|----------------|-------------|------------|
| 1. Issue | Human | — | GitHub Issue #42 | Prioritise → "Ready for Research" |
| 2. Research | **Agent mode** (default) | `/research-topic` | `docs/research/0042-password-reset.md` | Review research summary |
| 3. Specification | **Agent mode** (default) | `/write-spec` | `docs/specs/0042-password-reset.md`, `docs/research/0043-hashed-opaque-tokens.md` | Approve spec + ADR |
| 4. Planning | **Plan mode** (default) | `/write-plan` | `docs/plans/0042-password-reset.md` | Approve plan |
| 5. Test Scaffolding | **@builder** agent | `/test-first` | `.feature` files, unit test stubs | Review test intent |
| 6. Implementation | **@builder** agent | `/implement`, `/refactor` | Production code, passing tests, CHANGELOG | — (CI gates) |
| 7. Review | **@code-reviewer** agent | `/code-review`, `/security-audit` | Review comments, security findings | Approve + merge PR |
| 8. Docs & Release | **@release** agent | `/documentation`, `/deployment` | Updated README, ADR index, API docs | Approve infra changes (if any) |
| 9. Retrospective | Human | — | Metrics, `AGENTS.md` updates | — |

> **Key distinction:** Phases 2–3 use **Agent mode** (Copilot's default built-in agent
> with full tool access). Phase 4 uses **Plan mode** (Copilot's built-in planning agent
> that researches and plans without executing). Phases 5–8 use **custom agents**
> (`@builder`, `@code-reviewer`, `@release`) selected via the agent picker.

---

## Phase 1: Issue

**Actor:** Human (engineer or product manager)

A user reports they cannot recover their account when they forget their password.
The engineer creates a GitHub Issue:

```
Title:  feat: User Password Reset via Email
Labels: type/feature, priority/high, agent/research-needed
```

**Issue body:**
> Users need the ability to reset their password via an email link.  
> The reset token must expire after 1 hour.  
> The flow must work for both web and mobile clients.  
> Affected areas: auth module, email service, user database.

**Human gate:** Engineer moves the issue from **Backlog** → **Triaged** →
**Ready for Research** on the project board.

---

## Phase 2: Research

**Mode:** Agent mode (Copilot's default built-in agent)  
**Prompt:** `/research-topic`

### How to Invoke

1. Open Copilot Chat → ensure **Agent mode** is selected (the default)
2. Type: `/research-topic`
3. When prompted, provide: `#42 — User Password Reset via Email`

Agent mode has full tool access — it can search the codebase, read files, fetch web
content, and create the research artifact directly.

The `/research-topic` prompt (defined in `.github/prompts/research-topic.prompt.md`)
instructs the agent to:

```
1. Analyze current state — how does the system handle this today?
2. Review prior decisions — relevant ADRs, past choices
3. Research externally — industry practices, libraries, standards
4. Evaluate options — pros, cons, effort, confidence
5. Recommend — pick one with clear reasoning
6. Define next steps
```

### What the Agent Does

```
1. Reads Issue #42 description and comments
2. Searches codebase for existing auth patterns:
   - grep for "password", "token", "reset", "forgot" across src/
   - Reads existing auth module (src/auth/)
   - Reads database schema/migrations for users table
3. Checks prior ADRs:
   - ls docs/research/ → finds 0001-agents-md-best-practices.md (not relevant)
4. Checks prior specs:
   - ls docs/specs/ → empty
5. Examines email service integration
6. Researches external context:
   - OWASP password reset guidelines
   - Token generation best practices (CSPRNG, opaque vs JWT)
   - Rate limiting requirements for reset endpoints
```

### Output Artifact

**File:** `docs/research/0042-password-reset.md`

```markdown
# Research: User Password Reset

**Date:** 2026-02-26
**Status:** Complete
**Question:** How should we implement password reset for web and mobile clients?

## Summary
No reset flow exists. Recommend two new API endpoints using opaque
CSPRNG tokens (not JWTs), SHA-256 hashed and stored server-side in a
dedicated table. Follows OWASP guidelines. Reuses existing email service
and rate limiter.

## Current State
- Auth module at src/auth/ handles login/logout and JWT session tokens.
- Users table has columns: id, email, password_hash, created_at, updated_at.
- No reset_token or token_expiry columns exist.
- Email service exists at src/services/email.ts — currently used for
  welcome emails only. Supports HTML templates.
- Rate limiter middleware exists at src/middleware/rate-limit.ts.

## Options

### Option A: Opaque tokens in a dedicated `password_resets` table
- **Pros:** Secure (hashed storage), supports multiple tokens, clean schema
- **Cons:** Requires DB migration, slightly more complex
- **Effort:** Medium
- **Confidence:** High

### Option B: JWT-based tokens (stateless)
- **Pros:** No DB storage needed
- **Cons:** Cannot revoke server-side without blocklist, self-contained
  (leaks user info if decoded)
- **Effort:** Low
- **Confidence:** Low (violates OWASP guidance)

### Option C: Token columns on the users table
- **Pros:** Simple, no new table
- **Cons:** One token per user, clutters schema
- **Effort:** Low
- **Confidence:** Medium

## Recommendation
**Option A** — opaque tokens in a dedicated table. Aligns with OWASP, scales
for future token-based features (email verification, etc.).

## Risks & Unknowns
- Email deliverability untested beyond welcome emails.
- Password hashing algorithm not documented (verify bcrypt usage).
- Mobile client may need a deep link vs. web URL for the reset page.

## Next Steps
1. Human resolves open questions (table design, front-end URL, session invalidation)
2. Proceed to spec writing via /write-spec
```

### Commit

```bash
git add docs/research/0042-password-reset.md
git commit -m "docs(research): add research summary for password reset #42"
```

### Human Gate

The engineer reads the research summary. Resolves open questions:
1. **Separate `password_resets` table** — confirmed (Option A)
2. **Front-end URL:** `https://app.example.com/reset-password?token={token}`
3. **Yes**, invalidate existing sessions on successful password reset

Engineer comments answers on Issue #42 and tells the agent to proceed.

---

## Phase 3: Specification

**Mode:** Agent mode (same session — context preserved)  
**Prompt:** `/write-spec`

### How to Invoke

1. In the same Agent mode session, type: `/write-spec`
2. Provide: `#42 — Password Reset, based on research in docs/research/0042-password-reset.md`

Agent mode reads the research doc it just created, then produces the spec and ADR files
directly. The `/write-spec` prompt (defined in `.github/prompts/write-spec.prompt.md`)
instructs the agent to:

```
1. Define the problem and current state
2. Write acceptance criteria as Gherkin scenarios
3. Define scope boundaries — be explicit about exclusions
4. List non-functional requirements
5. Identify dependencies and blockers
6. Set status to Draft — escalate to human for approval
```

### Output Artifacts

**File 1:** `docs/specs/0042-password-reset.md`

```markdown
# Spec: User Password Reset

**Issue:** #42
**Date:** 2026-02-26
**Status:** Draft

## Problem Statement
Users who forget their password have no self-service recovery mechanism.
They must contact support, creating friction and support load.

## Desired Outcome
Users can request a password reset email, click a tokenized link, and
set a new password. The flow is secure, rate-limited, and works across
web and mobile clients.

## Acceptance Criteria

Feature: User Password Reset

  Background:
    Given a registered user with email "user@example.com"

  Scenario: Request password reset email
    When the user submits a forgot-password request for "user@example.com"
    Then the system sends a password reset email to "user@example.com"
    And the email contains a reset link with a valid token
    And the token expires in 1 hour

  Scenario: Reset password with valid token
    Given the user has a valid password reset token
    When the user submits a new password "N3wP@ssw0rd!" with the token
    Then the password is updated successfully
    And the reset token is marked as used
    And all existing sessions for the user are invalidated
    And the user receives a confirmation email

  Scenario: Reject expired token
    Given the user has an expired password reset token
    When the user submits a new password with the expired token
    Then the system returns a 400 error with message "Token expired"
    And the password is not changed

  Scenario: Reject already-used token
    Given the user has already used their reset token
    When the user submits a new password with the used token
    Then the system returns a 400 error with message "Token already used"

  Scenario: Rate limit forgot-password requests
    Given the user has requested 5 password resets in the last 15 minutes
    When the user submits another forgot-password request
    Then the system returns a 429 error
    And no email is sent

  Scenario: Non-existent email returns success (no enumeration)
    When the user submits a forgot-password request for "nobody@example.com"
    Then the system returns a 200 success response
    And no email is sent

## Scope
- POST /auth/forgot-password endpoint
- POST /auth/reset-password endpoint
- password_resets database table + migration
- Password reset email template
- Rate limiting on forgot-password endpoint
- Session invalidation on successful reset

## Non-Goals
- SMS-based reset (future feature)
- Admin-triggered password reset
- Password strength validation (assumed to exist already)

## Non-Functional Requirements
| Requirement | Target | How Verified |
|---|---|---|
| Security | OWASP password reset guidelines | @code-reviewer security audit |
| Performance | Reset email sent within 5 seconds | Integration test |
| Availability | No downtime for deployment | Rolling deploy |

## Dependencies
- Existing email service (src/services/email.ts)
- Existing rate limiter middleware

## ADRs
- docs/research/0043-hashed-opaque-tokens.md
```

**File 2:** `docs/research/0043-hashed-opaque-tokens.md`

If the decision warrants an ADR (a reasonable engineer might disagree), the agent
also produces it during the same `/write-spec` session:

```markdown
# ADR-0043: Use Separate Table with Hashed Opaque Tokens for Password Reset

**Date:** 2026-02-26
**Status:** Proposed

## Context
Password reset requires a token emailed to the user and verified
server-side. We need to decide where to store tokens and what
format/storage mechanism to use.

## Decision
- Store tokens in a dedicated `password_resets` table.
- Generate tokens using CSPRNG (crypto.randomBytes(32)).
- Store only the SHA-256 hash of the token in the database.
- Send the raw token in the email link.
- On verification: hash the submitted token and compare to stored hash
  using constant-time comparison.
- Tokens are single-use and expire after 1 hour.

## Consequences
**Positive:**
- Compromised database does not leak usable tokens.
- Separate table supports multiple pending tokens and clean expiry queries.
- Opaque tokens reveal no user information (unlike JWTs).

**Negative:**
- Requires a database migration.
- Slightly more complex than storing raw tokens on the users table.

## Alternatives Considered
1. **JWT-based tokens:** Rejected — cannot revoke server-side without blocklist.
2. **Columns on users table:** Rejected — limits to one token per user.
3. **Raw token storage:** Rejected — DB compromise exposes all active tokens.
```

### Commits

```bash
git add docs/specs/0042-password-reset.md
git commit -m "docs(spec): draft password reset specification #42"

git add docs/research/0043-hashed-opaque-tokens.md
git commit -m "docs(adr): propose hashed opaque tokens for password reset #42"
```

### Human Gate

Engineer reviews:
- ✅ Gherkin scenarios cover happy path, expiry, reuse, rate limiting, enumeration prevention
- ✅ ADR is sound — hashed opaque tokens per OWASP
- ✅ Scope well-bounded, non-goals clear

**Engineer approves spec and ADR.** ADR status updated to `Accepted`.

---

## Phase 4: Planning

**Mode:** Plan mode (Copilot's built-in planning agent)  
**Prompt:** `/write-plan`

### How to Invoke

1. Switch to **Plan mode** in the Copilot Chat mode selector
2. Type: `/write-plan`
3. Provide: `Spec: docs/specs/0042-password-reset.md, ADR: docs/research/0043-hashed-opaque-tokens.md`

Plan mode researches the codebase and produces a structured plan as a draft for
human review. It will not execute changes — only plan. The `/write-plan` prompt
(defined in `.github/prompts/write-plan.prompt.md`) instructs:

```
1. Decompose the spec into atomic steps — each completable in one commit
2. Order steps by dependency
3. Map tests to steps — which tests get written/updated at each step
4. Define the test strategy (TDD: tests first, then implementation)
5. Identify risks and mitigations
6. Set status to Draft — escalate to human for approval
```

### Output Artifact

**File:** `docs/plans/0042-password-reset.md`

```markdown
# Plan: User Password Reset

**Spec:** docs/specs/0042-password-reset.md
**ADRs:** docs/research/0043-hashed-opaque-tokens.md
**Date:** 2026-02-26
**Status:** Draft
**Branch:** `feat/42-password-reset`

## Steps

### Step 1: Database migration — create password_resets table
**Changes:** Create migration file to add `password_resets` table with
columns: id (PK), user_id (FK → users), token_hash (varchar, indexed),
expires_at (timestamp), used_at (timestamp, nullable), created_at.
**Tests:** Integration test — migration runs cleanly up and down.
**Commit:** `feat(db): add password_resets table migration #42`

### Step 2: Token service — generate and verify reset tokens
**Changes:** Create `src/auth/token-service.ts` with:
  - `generateResetToken(userId)` → { rawToken, hashedToken }
  - `verifyResetToken(rawToken)` → userId or throws
  - Uses crypto.randomBytes(32), SHA-256, crypto.timingSafeEqual
**Tests:** Unit tests — generation, valid verification, expired token,
used token, invalid token.
**Commit:** `feat(auth): add token service for password reset #42`

### Step 3: Forgot-password endpoint
**Changes:** Create `POST /auth/forgot-password` handler. Accepts { email }.
Lookup user → generate token → store hash → send email. Always returns 200.
Apply rate limiter: 5 req / 15 min per IP.
**Tests:** Unit tests for handler. Integration test for DB + email.
Acceptance scenarios: 1, 5, 6 from spec.
**Commit:** `feat(auth): add forgot-password endpoint #42`

### Step 4: Reset-password endpoint
**Changes:** Create `POST /auth/reset-password` handler. Accepts { token,
new_password }. Verify token → update password → mark used → invalidate
sessions → send confirmation.
**Tests:** Unit tests for handler. Integration test for full flow.
Acceptance scenarios: 2, 3, 4 from spec.
**Commit:** `feat(auth): add reset-password endpoint #42`

### Step 5: Email templates
**Changes:** Create `src/templates/password-reset.html` and
`src/templates/password-reset-confirmation.html`.
**Tests:** Unit test — template renders with expected variables.
Integration test — email service sends rendered template.
**Commit:** `feat(email): add password reset email templates #42`

### Step 6: Refactor + cleanup
**Changes:** Extract shared validation logic if duplicated. Ensure error
responses follow existing API format. Add JSDoc/docstrings. Update
CHANGELOG.md.
**Tests:** All existing tests still pass. No new tests.
**Commit:** `refactor(auth): clean up password reset implementation #42`

## Risks & Mitigations
- **Email flakiness:** Verify retry logic applies to reset emails.
- **Timing attacks:** Use crypto.timingSafeEqual (specified in Step 2).
- **Migration on prod:** Additive only (new table) — no destructive changes.
```

### Commit

```bash
git add docs/plans/0042-password-reset.md
git commit -m "docs(plan): add implementation plan for password reset #42"
```

### Human Gate

Engineer reviews the plan:
- ✅ 6 steps, each atomic and completable in one commit
- ✅ Tests specified per step
- ✅ References spec and ADR
- ✅ Risks acknowledged with mitigations

**Engineer approves the plan.** Status updated to `Approved`.

---

## Phase 5: Test Scaffolding

**Agent:** @builder  
**Mode:** `/test-first`

### How to Invoke

1. Open Copilot Chat → **select @builder** from the agent picker dropdown
2. Type: `/test-first`

The @builder agent reads from its session start checklist
(`.github/agents/builder.agent.md`):
```
1. Read the approved plan in docs/plans/ — confirm it exists and is approved
2. Read tasks/lessons.md — apply relevant patterns from prior sessions
3. Read the spec in docs/specs/ — understand acceptance criteria
4. Confirm scope: list files to touch and stop if it exceeds plan
```

Then follows the `/test-first` prompt:
```
1. Read the approved spec (Gherkin acceptance criteria) and plan
2. Write .feature files with all scenarios
3. Write step definition stubs
4. Write unit test stubs for expected functions/modules
All tests MUST FAIL — no implementation yet.
```

### Files Created

| File | Contents |
|------|----------|
| `tests/acceptance/features/password-reset.feature` | All 6 Gherkin scenarios from spec |
| `tests/acceptance/step_definitions/password-reset.steps.ts` | Step definition stubs (`pending()`) |
| `tests/unit/auth/token-service.test.ts` | Unit test stubs for generate, verify, hash |
| `tests/unit/auth/forgot-password.test.ts` | Unit test stubs for handler, rate limiting |
| `tests/unit/auth/reset-password.test.ts` | Unit test stubs for handler, session invalidation |
| `tests/integration/auth/password-reset.test.ts` | Integration test stubs for full flow |

### @builder Runs Tests (all must fail)

```bash
# Unit tests
[test-runner] tests/unit/auth/ -x -q
# Result: 12 tests, 0 passed, 12 failed ✅ (expected)

# Integration tests
[test-runner] tests/integration/auth/password-reset.test.ts -x -q
# Result: 4 tests, 0 passed, 4 failed ✅

# Acceptance tests
[test-runner] tests/acceptance/features/password-reset.feature
# Result: 6 scenarios, 0 passed, 6 pending ✅
```

### Commit

```bash
git checkout -b feat/42-password-reset
git add tests/
git commit -m "test(auth): scaffold failing tests for password reset #42"
```

### Human Gate

Engineer reviews test intent:
- ✅ Gherkin scenarios match spec 1:1
- ✅ Unit tests cover edge cases (expiry, reuse, invalid)
- ✅ Integration tests cover DB + email boundaries
- ✅ Rate limit and enumeration prevention covered

**Engineer approves.** @builder proceeds to implementation.

---

## Phase 6: Implementation

**Agent:** @builder (same session — context preserved)  
**Mode:** `/implement`

### How to Invoke

Type `/implement` in the same @builder session.

The @builder follows the plan step by step, running the post-change checklist
from `AGENTS.md` after every change:

```
1. Format: [formatter] src/ tests/
2. Lint: [linter] src/ tests/ --fix
3. Unit tests: [test-runner] tests/unit/ -x -q
4. Integration tests: [test-runner] tests/integration/ -x -q
5. Review: git diff --stat
6. Stage: git add <files you changed>
7. Commit: git commit -m "<type>(<scope>): <summary>"
```

### Step-by-Step Execution

#### Plan Step 1: Database Migration

```bash
# @builder creates: src/db/migrations/20260226-create-password-resets.ts
# @builder runs migration
[migration-tool] migrate:up

# Post-change checklist
[formatter] src/db/migrations/
[linter] src/db/migrations/ --fix
[test-runner] tests/integration/auth/password-reset.test.ts -k "migration" -x -q
# Result: 1 passed ✅
git diff --stat
git add src/db/migrations/20260226-create-password-resets.ts
git commit -m "feat(db): add password_resets table migration #42"
```

#### Plan Step 2: Token Service

```bash
# @builder creates: src/auth/token-service.ts

# Post-change checklist
[formatter] src/auth/token-service.ts
[linter] src/auth/ --fix
[test-runner] tests/unit/auth/token-service.test.ts -x -q
# Result: 4 passed ✅ (generate, verify-valid, verify-expired, verify-used)
git diff --stat
git add src/auth/token-service.ts tests/unit/auth/token-service.test.ts
git commit -m "feat(auth): add token service for password reset #42"
```

#### Plan Step 3: Forgot-Password Endpoint

```bash
# @builder creates: src/auth/forgot-password.handler.ts
# @builder wires route in src/routes/auth.ts

# Post-change checklist
[formatter] src/auth/forgot-password.handler.ts
[linter] src/auth/ --fix
[test-runner] tests/unit/auth/forgot-password.test.ts -x -q
# Result: 3 passed ✅
[test-runner] tests/acceptance/features/password-reset.feature \
  --name "Request password reset|Rate limit|Non-existent email"
# Result: 3 scenarios passed ✅
git diff --stat
git add src/auth/forgot-password.handler.ts src/routes/auth.ts \
  tests/unit/auth/forgot-password.test.ts
git commit -m "feat(auth): add forgot-password endpoint #42"
```

#### Plan Step 4: Reset-Password Endpoint

```bash
# @builder creates: src/auth/reset-password.handler.ts
# @builder wires route in src/routes/auth.ts

# Post-change checklist
[formatter] src/auth/reset-password.handler.ts
[linter] src/auth/ --fix
[test-runner] tests/unit/auth/reset-password.test.ts -x -q
# Result: 4 passed ✅
[test-runner] tests/acceptance/features/password-reset.feature \
  --name "Reset password|expired token|already-used token"
# Result: 3 scenarios passed ✅

# Full regression
[test-runner] tests/unit/ -x -q        # 12 passed ✅
[test-runner] tests/integration/ -x -q  # 4 passed ✅

git diff --stat
git add src/auth/reset-password.handler.ts src/routes/auth.ts \
  tests/unit/auth/reset-password.test.ts \
  tests/integration/auth/password-reset.test.ts
git commit -m "feat(auth): add reset-password endpoint #42"
```

#### Plan Step 5: Email Templates

```bash
# @builder creates: src/templates/password-reset.html
# @builder creates: src/templates/password-reset-confirmation.html

# Post-change checklist
[test-runner] tests/unit/templates/ -x -q   # 2 passed ✅
[test-runner] tests/integration/auth/ -x -q  # 4 passed ✅
git diff --stat
git add src/templates/ tests/unit/templates/
git commit -m "feat(email): add password reset email templates #42"
```

#### Plan Step 6: Refactor + Cleanup

@builder switches mode — type `/refactor` in the same session.

```bash
# @builder reviews all new code for duplication, naming, clarity
# Extracts shared error-response helper if duplicated
# Adds JSDoc to all public functions
# Verifies no TODO/FIXME comments remain
# Updates CHANGELOG.md:
#   ## [Unreleased] → ### Added
#   - Password reset via email (POST /auth/forgot-password, POST /auth/reset-password)

# Full regression
[test-runner] tests/unit/ -x -q         # 12 passed ✅
[test-runner] tests/integration/ -x -q   # 4 passed ✅
[test-runner] tests/acceptance/features/password-reset.feature
                                         # 6 scenarios passed ✅
# Coverage check
[test-runner] --coverage tests/          # New code: 94% ✅ (above 80% threshold)

git diff --stat
git add src/auth/ src/templates/ CHANGELOG.md
git commit -m "refactor(auth): clean up password reset implementation #42"
```

### Branch State Summary

```bash
git log main..HEAD --oneline
# a1b2c3d refactor(auth): clean up password reset implementation #42
# d4e5f6a feat(email): add password reset email templates #42
# 7g8h9i0 feat(auth): add reset-password endpoint #42
# j1k2l3m feat(auth): add forgot-password endpoint #42
# n4o5p6q feat(auth): add token service for password reset #42
# r7s8t9u feat(db): add password_resets table migration #42
# v1w2x3y test(auth): scaffold failing tests for password reset #42
```

7 commits — one per plan step + initial test scaffold. Each is atomic and reviewable.

---

## Phase 7: Review

**Agent:** @code-reviewer  
**Mode:** `/code-review` then `/security-audit`

### How to Invoke

1. Open Copilot Chat → **select @code-reviewer** from the agent picker dropdown
2. Type: `/code-review`

Note: @code-reviewer has **no edit tools** — it physically cannot modify the code
it reviews. This is enforced by the agent's `tools:` config. It can only read, search,
and execute commands (for `git diff`, etc.).

### Code Review Pass

The @code-reviewer executes the `/code-review` prompt:

```bash
git diff main...HEAD --stat
# 14 files changed, 487 insertions(+)

git log main..HEAD --oneline
# (verifies 7 conventional commits, one per plan step)
```

**Structured Report:**

```
## Code Review: Password Reset (#42)

### Blockers
(none)

### Warnings
- W1: token-service.ts L18 — consider adding explicit return type
  annotation to generateResetToken()
- W2: forgot-password.handler.ts L45 — magic number 5 for rate limit;
  extract to config constant

### Notes
- ✅ All 6 plan steps implemented as specified
- ✅ CHANGELOG.md updated
- ✅ Conventional commits followed
- ✅ No TODO/FIXME comments
- ✅ Test coverage: 94% on new code
- ✅ All acceptance scenarios passing

Risk rating: low
```

### Security Audit Pass

Type `/security-audit` in the same @code-reviewer session:

```bash
git diff main...HEAD
# (reviews every changed line for security issues)
```

**Security Report:**

```
## Security Audit: Password Reset (#42)

### Critical/High (BLOCKERS)
(none)

### Medium (must address)
- M1: token-service.ts — Verify crypto.timingSafeEqual is used.
  STATUS: ✅ Confirmed correct.
- M2: reset-password.handler.ts — Ensure password validated before hashing.
  STATUS: ✅ Uses existing validation middleware.

### Low (advisory)
- L1: Consider adding audit logging for password reset events.
  Not a blocker — recommend follow-up issue.

### Dependency Scan
- No new dependencies added.
- Existing crypto module: Node.js built-in — no CVEs.

### Secrets Check
- ✅ No hardcoded secrets, API keys, or credentials found.

Risk rating: low
```

### Human Gate

Engineer reviews:
- Reads @code-reviewer findings (both code review and security)
- Addresses W1, W2 (or accepts as advisory)
- Creates follow-up issue for L1 (audit logging)
- Performs own review of the diff

**PR Description** (from `.github/PULL_REQUEST_TEMPLATE.md`):

```markdown
## Summary
Add password reset flow: forgot-password and reset-password endpoints
with hashed opaque tokens, email templates, rate limiting, and session
invalidation.

## Linked Issue
Closes #42

## References
- Spec: docs/specs/0042-password-reset.md
- Plan: docs/plans/0042-password-reset.md
- ADR: docs/research/0043-hashed-opaque-tokens.md

## Test Results
- Unit: ✅ 12 passed, 0 failed
- Integration: ✅ 4 passed, 0 failed
- Acceptance: ✅ 6 scenarios passed, 0 failed
- Coverage delta: +2.3% (new code: 94%)

## Changelog
Updated: Yes
```

**Engineer approves and merges** (rebase-merge — squash forbidden):

```bash
git checkout main
git merge --ff-only feat/42-password-reset
git push origin main
git branch -d feat/42-password-reset
```

---

## Phase 8: Documentation & Release

**Agent:** @release  
**Mode:** `/documentation` then `/deployment`

### How to Invoke

1. Open Copilot Chat → **select @release** from the agent picker dropdown
2. Type: `/documentation`

The @release agent runs its session start checklist
(`.github/agents/release.agent.md`):
```
1. Confirm the PR is merged — run git log --oneline -5
2. Identify changed files — run git diff main...HEAD --name-only
3. Read tasks/lessons.md — apply relevant patterns
```

### Documentation Pass

```bash
# @release checks what changed
git diff main~7...main --name-only

# @release updates:
# 1. README.md — adds "Password Reset" to API features
# 2. docs/research/INDEX.md — adds ADR-0043 entry
# 3. API docs — regenerates endpoint documentation
# 4. Verifies CHANGELOG.md is accurate

git add README.md docs/research/INDEX.md docs/api/
git commit -m "docs(auth): update documentation for password reset #42"
```

### Deployment Pass

Type `/deployment` in the same @release session:

```bash
# @release confirms merge landed
git log --oneline -5

# Verifies CI/CD pipeline status:
# - lint ✅, unit tests ✅, integration ✅, acceptance ✅
# - Coverage threshold met ✅

# Confirms migration included in deployment
# Verifies no new env vars or infrastructure changes needed

# Deployment proceeds via existing CD pipeline
# @release monitors: staging ✅ → production ✅
```

No infrastructure changes → no human gate.  
Issue #42 closed with PR reference. Board: **In Review** → **Done**.

---

## Phase 9: Retrospective & Metrics

**Actor:** Human (with @release monitoring data)

### Metrics Captured

| Metric | Value |
|--------|-------|
| Cycle time (issue → merge) | 3 days |
| Research | 2 hours |
| Spec + ADR | 3 hours |
| Planning | 1 hour |
| Test scaffolding | 1 hour |
| Implementation | 6 hours |
| Review | 2 hours |
| Docs + deploy | 1 hour |
| Revision cycles | 0 |
| Plan deviations | 0 |
| Coverage delta | +2.3% |
| Commits | 7 (+1 post-merge) |
| Files changed | 15 |
| Lines added | 487 |

### Lessons Learned → `tasks/lessons.md`

- Research caught OWASP guidelines early — prevented JWT design that
  would have required revision.
- Dedicated `password_resets` table will scale for future token features.
- Rate limit config should be centralized — follow-up issue created.

### AGENTS.md Update

```markdown
# Added to Domain Knowledge → Project-Specific Conventions:
- Password reset tokens: opaque, CSPRNG-generated, SHA-256 hashed,
  stored in password_resets table (see ADR-0043)
- All token comparisons must use constant-time comparison
```

---

## The Artifact Chain

```
Issue #42
  └─→ docs/research/0042-password-reset.md         (Agent mode: /research-topic)
       └─→ docs/specs/0042-password-reset.md        (Agent mode: /write-spec)
       └─→ docs/research/0043-hashed-opaque-tokens.md  (Agent mode: /write-spec)
            └─→ docs/plans/0042-password-reset.md   (Plan mode: /write-plan)
                 └─→ tests/ (failing)               (@builder: /test-first)
                      └─→ src/ (passing)            (@builder: /implement + /refactor)
                           └─→ PR #87               (@code-reviewer: /code-review + /security-audit)
                                └─→ main            (Human: merge)
                                     └─→ docs/      (@release: /documentation)
                                          └─→ prod  (@release: /deployment)
```

Every artifact committed to Git. Every decision traceable. Every phase has an owner.
The engineer's time was spent reviewing, deciding, and approving — not writing code.
