# Sample Workflow: End-to-End Agentic SDLC (OpenCode)

> A complete walkthrough of the 9-phase Standard track using **OpenCode**,
> simulating a real feature from issue to deployment. Shows every agent,
> command, artifact, commit, and human gate — using only the tooling that
> exists in this repo under `.opencode/`.

**Feature:** User Password Reset  
**Track:** Standard (all 9 phases)  
**Issue:** #42

---

## Quick Reference

| Phase | Who / Agent | Command (`Ctrl+K`) | Artifact(s) | Human Gate |
|-------|-------------|---------------------|-------------|------------|
| 1. Issue | Human | — | GitHub Issue #42 | Prioritise → "Ready for Research" |
| 2. Research | Default agent | `Ctrl+K` → `research-topic` | `docs/research/0042-password-reset.md` | Review research summary |
| 3. Specification | Default agent | `Ctrl+K` → `write-spec` | `docs/specs/0042-password-reset.md`, `docs/research/0043-hashed-opaque-tokens.md` | Approve spec + ADR |
| 4. Planning | Default agent | `Ctrl+K` → `write-plan` | `docs/plans/0042-password-reset.md` | Approve plan |
| 5. Test Scaffolding | **Builder** agent | `Ctrl+K` → `test-first` | `.feature` files, unit test stubs | Review test intent |
| 6. Implementation | **Builder** agent | `Ctrl+K` → `implement`, `refactor` | Production code, passing tests, CHANGELOG | — (CI gates) |
| 7. Review | **Code-Reviewer** agent | `Ctrl+K` → `code-review`, `security-audit` | Review comments, security findings | Approve + merge PR |
| 8. Docs & Release | **Release** agent | `Ctrl+K` → `documentation`, `deployment` | Updated README, ADR index, API docs | Approve infra changes (if any) |
| 9. Retrospective | Human | — | Metrics, `AGENTS.md` updates | — |

> **OpenCode navigation:** `Tab` cycles between agents. `Ctrl+K` opens the
> command picker to invoke mode-shift commands within the active agent.

---

## OpenCode Agent Inventory

Three custom agents exist in `.opencode/agents/`:

| Agent | File | Permissions | Color |
|-------|------|-------------|-------|
| **Builder** | `.opencode/agents/builder.md` | `write: true`, `edit: true`, `bash: true` | 🟢 `#2ECC71` |
| **Code-Reviewer** | `.opencode/agents/code-reviewer.md` | `write: false`, `edit: false`, `bash: allow` | 🔴 `#E74C3C` |
| **Release** | `.opencode/agents/release.md` | `write: true`, `edit: true`, `bash: ask` | 🟣 `#8E44AD` |

**Key permission boundaries:**
- **Code-Reviewer** has `write: false` and `edit: false` — it physically cannot
  modify code it reviews. Separation of concerns enforced at the OS level.
- **Release** has `bash: ask` — human must confirm every shell operation
  (deployments, pipeline changes).
- **Builder** has full access (`bash: true`) — needed for the TDD loop (run tests,
  write code, execute migrations).

Ten commands exist in `.opencode/commands/`:
`research-topic`, `write-spec`, `write-plan`, `test-first`, `implement`,
`refactor`, `code-review`, `security-audit`, `documentation`, `deployment`

---

## Phase 1: Issue

**Actor:** Human (engineer or product manager)

A user reports they cannot recover their account when they forget their password.
The engineer creates a GitHub Issue:

```
Title:  feat: User Password Reset via Email
Labels: type/feature, priority/high, agent/research-needed
```

**Issue body:**
> Users need the ability to reset their password via an email link.
> The reset token must expire after 1 hour.
> The flow must work for both web and mobile clients.
> Affected areas: auth module, email service, user database.

**Human gate:** Engineer moves the issue from **Backlog** → **Triaged** →
**Ready for Research** on the project board.

---

## Phase 2: Research

**Agent:** Default agent (no custom agent needed)  
**Command:** `Ctrl+K` → `research-topic`

### How to Invoke

1. Open OpenCode terminal UI
2. Press `Ctrl+K` → select **research-topic** from the command picker
3. Provide the issue context: `#42 — User Password Reset via Email`

The `research-topic` command (`.opencode/commands/research-topic.md`) injects
instructions into the session:

```
1. Analyze current state — how does the system handle this today?
2. Review prior decisions — relevant ADRs, past choices, lessons learned
3. Research externally — industry practices, libraries, standards, benchmarks
4. Evaluate options — pros, cons, effort, confidence for each
5. Recommend — pick one with clear reasoning
6. Record the decision and update docs/research/INDEX.md
7. Escalate to human for review and approval
```

### What the Agent Does

```
1. Reads Issue #42 description
2. Searches codebase:
   RUN grep -r "password\|token\|reset\|forgot" src/
   Reads src/auth/, database migrations, users table schema
3. Checks prior ADRs:
   RUN ls docs/research/
   → finds 0001-agents-md-best-practices.md (not relevant)
4. Checks prior specs:
   RUN ls docs/specs/
   → empty
5. Examines email service integration
6. Researches external context (OWASP, token best practices)
```

### Output Artifact

**File:** `docs/research/0042-password-reset.md`

```markdown
# Research: User Password Reset

**Date:** 2026-02-26
**Status:** Complete
**Question:** How should we implement password reset for web and mobile clients?

## Summary
No reset flow exists. Recommend two new API endpoints using opaque
CSPRNG tokens (not JWTs), SHA-256 hashed and stored server-side in a
dedicated table. Follows OWASP guidelines. Reuses existing email service
and rate limiter.

## Current State
- Auth module at src/auth/ handles login/logout and JWT session tokens.
- Users table: id, email, password_hash, created_at, updated_at.
- No reset_token or token_expiry columns exist.
- Email service at src/services/email.ts — used for welcome emails.
- Rate limiter middleware at src/middleware/rate-limit.ts.

## Options

### Option A: Opaque tokens in a dedicated `password_resets` table
- **Pros:** Secure (hashed), supports multiple tokens, clean schema
- **Cons:** Requires DB migration
- **Effort:** Medium — **Confidence:** High

### Option B: JWT-based tokens (stateless)
- **Pros:** No DB storage needed
- **Cons:** Cannot revoke without blocklist, leaks user info
- **Effort:** Low — **Confidence:** Low (violates OWASP)

### Option C: Token columns on users table
- **Pros:** Simple
- **Cons:** One token per user, clutters schema
- **Effort:** Low — **Confidence:** Medium

## Recommendation
**Option A** — aligns with OWASP, scales for future token features.

## Risks & Unknowns
- Email deliverability untested beyond welcome emails.
- Password hashing algorithm not documented.
- Mobile client may need deep link vs. web URL.

## Next Steps
1. Human resolves open questions
2. Proceed to write-spec
```

### Commit

```bash
git add docs/research/0042-password-reset.md
git commit -m "docs(research): add research summary for password reset #42"
```

### Human Gate

Engineer reads the research. Resolves open questions:
1. **Separate `password_resets` table** — confirmed (Option A)
2. **Front-end URL:** `https://app.example.com/reset-password?token={token}`
3. **Yes**, invalidate sessions on successful password reset

Engineer comments answers on Issue #42.

---

## Phase 3: Specification

**Agent:** Default agent (same session — context preserved)  
**Command:** `Ctrl+K` → `write-spec`

### How to Invoke

1. Press `Ctrl+K` → select **write-spec**
2. Provide: `#42 — Password Reset, research: docs/research/0042-password-reset.md`

The `write-spec` command (`.opencode/commands/write-spec.md`) instructs:

```
1. Define the problem and current state
2. Write acceptance criteria as Gherkin scenarios
3. Define scope boundaries — explicit about exclusions
4. List non-functional requirements
5. Identify dependencies and blockers
6. Set status to Draft — escalate to human for approval
```

### Output Artifacts

**File 1:** `docs/specs/0042-password-reset.md`

```markdown
# Spec: User Password Reset

**Issue:** #42
**Date:** 2026-02-26
**Status:** Draft

## Problem Statement
Users who forget their password have no self-service recovery mechanism.

## Desired Outcome
Users can request a password reset email, click a tokenized link, and
set a new password. Secure, rate-limited, works across web and mobile.

## Acceptance Criteria

Feature: User Password Reset

  Background:
    Given a registered user with email "user@example.com"

  Scenario: Request password reset email
    When the user submits a forgot-password request for "user@example.com"
    Then the system sends a password reset email to "user@example.com"
    And the email contains a reset link with a valid token
    And the token expires in 1 hour

  Scenario: Reset password with valid token
    Given the user has a valid password reset token
    When the user submits a new password "N3wP@ssw0rd!" with the token
    Then the password is updated successfully
    And the reset token is marked as used
    And all existing sessions for the user are invalidated
    And the user receives a confirmation email

  Scenario: Reject expired token
    Given the user has an expired password reset token
    When the user submits a new password with the expired token
    Then the system returns a 400 error with message "Token expired"
    And the password is not changed

  Scenario: Reject already-used token
    Given the user has already used their reset token
    When the user submits a new password with the used token
    Then the system returns a 400 error with message "Token already used"

  Scenario: Rate limit forgot-password requests
    Given the user has requested 5 password resets in the last 15 minutes
    When the user submits another forgot-password request
    Then the system returns a 429 error
    And no email is sent

  Scenario: Non-existent email returns success (no enumeration)
    When the user submits a forgot-password request for "nobody@example.com"
    Then the system returns a 200 success response
    And no email is sent

## Scope
- POST /auth/forgot-password endpoint
- POST /auth/reset-password endpoint
- password_resets database table + migration
- Password reset email template
- Rate limiting on forgot-password endpoint
- Session invalidation on successful reset

## Non-Goals
- SMS-based reset (future feature)
- Admin-triggered password reset
- Password strength validation (assumed existing)

## Non-Functional Requirements
| Requirement | Target | How Verified |
|---|---|---|
| Security | OWASP password reset guidelines | Code-Reviewer security audit |
| Performance | Reset email sent within 5 seconds | Integration test |
| Availability | No downtime for deployment | Rolling deploy |

## Dependencies
- Existing email service (src/services/email.ts)
- Existing rate limiter middleware

## ADRs
- docs/research/0043-hashed-opaque-tokens.md
```

**File 2:** `docs/research/0043-hashed-opaque-tokens.md`

```markdown
# ADR-0043: Use Separate Table with Hashed Opaque Tokens for Password Reset

**Date:** 2026-02-26
**Status:** Proposed

## Context
Password reset requires a token emailed to the user and verified
server-side. Need to decide storage location and format.

## Decision
- Dedicated `password_resets` table.
- CSPRNG tokens (crypto.randomBytes(32)).
- SHA-256 hash stored in DB; raw token sent in email.
- Constant-time comparison on verification.
- Single-use, 1-hour expiry.

## Consequences
**Positive:** DB compromise doesn't leak tokens. Multiple tokens supported.
**Negative:** Requires migration. Slightly more complex.

## Alternatives Considered
1. **JWT tokens:** Rejected — not revocable.
2. **Users table columns:** Rejected — one token limit.
3. **Raw token storage:** Rejected — DB compromise risk.
```

### Commits

```bash
git add docs/specs/0042-password-reset.md
git commit -m "docs(spec): draft password reset specification #42"

git add docs/research/0043-hashed-opaque-tokens.md
git commit -m "docs(adr): propose hashed opaque tokens for password reset #42"
```

### Human Gate

Engineer reviews:
- ✅ 6 Gherkin scenarios — happy path, expiry, reuse, rate limit, enumeration
- ✅ ADR sound — hashed opaque tokens per OWASP
- ✅ Scope bounded, non-goals clear

**Engineer approves.** ADR status → `Accepted`.

---

## Phase 4: Planning

**Agent:** Default agent (same session)  
**Command:** `Ctrl+K` → `write-plan`

### How to Invoke

1. Press `Ctrl+K` → select **write-plan**
2. Provide: `Spec: docs/specs/0042-password-reset.md`

The `write-plan` command (`.opencode/commands/write-plan.md`) instructs:

```
1. Decompose into atomic steps — each completable in one commit
2. Order by dependency
3. Map tests to steps
4. Define TDD strategy
5. Identify risks and mitigations
6. Set status to Draft — escalate to human
```

### Output Artifact

**File:** `docs/plans/0042-password-reset.md`

```markdown
# Plan: User Password Reset

**Spec:** docs/specs/0042-password-reset.md
**ADRs:** docs/research/0043-hashed-opaque-tokens.md
**Date:** 2026-02-26
**Status:** Draft
**Branch:** `feat/42-password-reset`

## Steps

### Step 1: Database migration — create password_resets table
**Changes:** Migration file: password_resets (id, user_id, token_hash,
expires_at, used_at, created_at).
**Tests:** Integration test — migration up/down.
**Commit:** `feat(db): add password_resets table migration #42`

### Step 2: Token service — generate and verify reset tokens
**Changes:** src/auth/token-service.ts — generateResetToken(),
verifyResetToken(). CSPRNG + SHA-256 + timingSafeEqual.
**Tests:** Unit tests — generate, verify-valid, expired, used, invalid.
**Commit:** `feat(auth): add token service for password reset #42`

### Step 3: Forgot-password endpoint
**Changes:** POST /auth/forgot-password handler. Lookup → token → store →
email. Always 200. Rate limit: 5/15min/IP.
**Tests:** Unit + integration + acceptance (scenarios 1, 5, 6).
**Commit:** `feat(auth): add forgot-password endpoint #42`

### Step 4: Reset-password endpoint
**Changes:** POST /auth/reset-password handler. Verify → update password →
mark used → invalidate sessions → confirmation email.
**Tests:** Unit + integration + acceptance (scenarios 2, 3, 4).
**Commit:** `feat(auth): add reset-password endpoint #42`

### Step 5: Email templates
**Changes:** src/templates/password-reset.html,
password-reset-confirmation.html.
**Tests:** Unit (renders) + integration (sends).
**Commit:** `feat(email): add password reset email templates #42`

### Step 6: Refactor + cleanup
**Changes:** Extract duplication, ensure error format, JSDoc, CHANGELOG.
**Tests:** All green, no new tests.
**Commit:** `refactor(auth): clean up password reset implementation #42`

## Risks & Mitigations
- **Email flakiness:** Verify retry logic applies.
- **Timing attacks:** crypto.timingSafeEqual in Step 2.
- **Migration:** Additive only — no destructive changes.
```

### Commit

```bash
git add docs/plans/0042-password-reset.md
git commit -m "docs(plan): add implementation plan for password reset #42"
```

### Human Gate

- ✅ 6 atomic steps, tests per step, references spec + ADR, risks addressed

**Engineer approves.** Status → `Approved`.

---

## Phase 5: Test Scaffolding

**Agent:** Builder  
**Command:** `Ctrl+K` → `test-first`

### How to Invoke

1. Press `Tab` to cycle to the **Builder** agent (green `#2ECC71`)
2. Press `Ctrl+K` → select **test-first**

The `test-first` command (`.opencode/commands/test-first.md`) injects:

```
1. RUN cat docs/plans/$(ls docs/plans/ | tail -1)
2. Write .feature files with all Gherkin scenarios
3. Write step definition stubs
4. Write unit test stubs for expected functions
All tests MUST FAIL — no implementation yet.
RUN the test suite to confirm all fail.
```

### What the Builder Does

```bash
# Builder reads the plan
RUN cat docs/plans/0042-password-reset.md
```

Then creates:

| File | Contents |
|------|----------|
| `tests/acceptance/features/password-reset.feature` | 6 Gherkin scenarios from spec |
| `tests/acceptance/step_definitions/password-reset.steps.ts` | Step definition stubs (`pending()`) |
| `tests/unit/auth/token-service.test.ts` | Unit stubs for generate, verify, hash |
| `tests/unit/auth/forgot-password.test.ts` | Unit stubs for handler, rate limit |
| `tests/unit/auth/reset-password.test.ts` | Unit stubs for handler, sessions |
| `tests/integration/auth/password-reset.test.ts` | Integration stubs for full flow |

### Builder Runs Tests (all must fail)

```bash
# The test-first command explicitly says "RUN the test suite to confirm all fail"
RUN [test-runner] tests/unit/auth/ -x -q
# Result: 12 tests, 0 passed, 12 failed ✅

RUN [test-runner] tests/integration/auth/password-reset.test.ts -x -q
# Result: 4 tests, 0 passed, 4 failed ✅

RUN [test-runner] tests/acceptance/features/password-reset.feature
# Result: 6 scenarios, 0 passed, 6 pending ✅
```

### Commit

```bash
git checkout -b feat/42-password-reset
git add tests/
git commit -m "test(auth): scaffold failing tests for password reset #42"
```

### Human Gate

Engineer reviews test intent:
- ✅ Gherkin matches spec 1:1
- ✅ Edge cases covered
- ✅ Integration boundaries covered

**Engineer approves.** Builder proceeds.

---

## Phase 6: Implementation

**Agent:** Builder (same session — `Tab` stays on Builder)  
**Command:** `Ctrl+K` → `implement`

### How to Invoke

Press `Ctrl+K` → select **implement**. The command injects:

```
1. RUN cat docs/plans/$(ls docs/plans/ | tail -1)
2. Work through the plan step by step
3. Write minimum code to pass the next failing test
4. RUN tests after each change — confirm green before moving on
5. One commit per plan step
6. Update CHANGELOG.md with user-facing changes
```

### Step-by-Step Execution

#### Plan Step 1: Database Migration

```bash
# Builder reads plan
RUN cat docs/plans/0042-password-reset.md

# Builder creates: src/db/migrations/20260226-create-password-resets.ts
# Builder runs migration
RUN [migration-tool] migrate:up

# Builder runs tests
RUN [test-runner] tests/integration/auth/password-reset.test.ts -k "migration" -x -q
# Result: 1 passed ✅

# Post-change checklist
RUN [formatter] src/db/migrations/
RUN [linter] src/db/migrations/ --fix
RUN git diff --stat
git add src/db/migrations/20260226-create-password-resets.ts
git commit -m "feat(db): add password_resets table migration #42"
```

#### Plan Step 2: Token Service

```bash
# Builder creates: src/auth/token-service.ts

RUN [formatter] src/auth/token-service.ts
RUN [linter] src/auth/ --fix
RUN [test-runner] tests/unit/auth/token-service.test.ts -x -q
# Result: 4 passed ✅ (generate, verify-valid, verify-expired, verify-used)

RUN git diff --stat
git add src/auth/token-service.ts tests/unit/auth/token-service.test.ts
git commit -m "feat(auth): add token service for password reset #42"
```

#### Plan Step 3: Forgot-Password Endpoint

```bash
# Builder creates: src/auth/forgot-password.handler.ts
# Builder wires route in src/routes/auth.ts

RUN [formatter] src/auth/forgot-password.handler.ts
RUN [linter] src/auth/ --fix
RUN [test-runner] tests/unit/auth/forgot-password.test.ts -x -q
# Result: 3 passed ✅

RUN [test-runner] tests/acceptance/features/password-reset.feature \
  --name "Request password reset|Rate limit|Non-existent email"
# Result: 3 scenarios passed ✅

RUN git diff --stat
git add src/auth/forgot-password.handler.ts src/routes/auth.ts \
  tests/unit/auth/forgot-password.test.ts
git commit -m "feat(auth): add forgot-password endpoint #42"
```

#### Plan Step 4: Reset-Password Endpoint

```bash
# Builder creates: src/auth/reset-password.handler.ts

RUN [formatter] src/auth/reset-password.handler.ts
RUN [linter] src/auth/ --fix
RUN [test-runner] tests/unit/auth/reset-password.test.ts -x -q
# Result: 4 passed ✅

RUN [test-runner] tests/acceptance/features/password-reset.feature \
  --name "Reset password|expired token|already-used token"
# Result: 3 scenarios passed ✅

# Full regression
RUN [test-runner] tests/unit/ -x -q        # 12 passed ✅
RUN [test-runner] tests/integration/ -x -q  # 4 passed ✅

RUN git diff --stat
git add src/auth/reset-password.handler.ts src/routes/auth.ts \
  tests/unit/auth/reset-password.test.ts \
  tests/integration/auth/password-reset.test.ts
git commit -m "feat(auth): add reset-password endpoint #42"
```

#### Plan Step 5: Email Templates

```bash
# Builder creates templates

RUN [test-runner] tests/unit/templates/ -x -q   # 2 passed ✅
RUN [test-runner] tests/integration/auth/ -x -q  # 4 passed ✅

RUN git diff --stat
git add src/templates/ tests/unit/templates/
git commit -m "feat(email): add password reset email templates #42"
```

#### Plan Step 6: Refactor + Cleanup

Builder switches mode: `Ctrl+K` → select **refactor**

The `refactor` command injects:

```
1. RUN the full test suite — confirm all green before touching code
2. Identify refactoring targets
3. Apply one refactoring at a time
4. RUN tests after each change — if anything breaks, revert immediately
5. Follow rules/REFACTORING.md
6. Audit for dead code
```

```bash
# Builder cleans up code, adds JSDoc, extracts duplication
# Updates CHANGELOG.md:
#   ## [Unreleased] → ### Added
#   - Password reset via email (POST /auth/forgot-password, POST /auth/reset-password)

# Full regression
RUN [test-runner] tests/unit/ -x -q         # 12 passed ✅
RUN [test-runner] tests/integration/ -x -q   # 4 passed ✅
RUN [test-runner] tests/acceptance/features/password-reset.feature
                                             # 6 scenarios passed ✅

# Coverage
RUN [test-runner] --coverage tests/          # New code: 94% ✅

RUN git diff --stat
git add src/auth/ src/templates/ CHANGELOG.md
git commit -m "refactor(auth): clean up password reset implementation #42"
```

### Branch State Summary

```bash
RUN git log main..HEAD --oneline
# a1b2c3d refactor(auth): clean up password reset implementation #42
# d4e5f6a feat(email): add password reset email templates #42
# 7g8h9i0 feat(auth): add reset-password endpoint #42
# j1k2l3m feat(auth): add forgot-password endpoint #42
# n4o5p6q feat(auth): add token service for password reset #42
# r7s8t9u feat(db): add password_resets table migration #42
# v1w2x3y test(auth): scaffold failing tests for password reset #42
```

7 commits — one per plan step + initial test scaffold.

---

## Phase 7: Review

**Agent:** Code-Reviewer  
**Command:** `Ctrl+K` → `code-review` then `security-audit`

### How to Invoke

1. Press `Tab` to cycle to the **Code-Reviewer** agent (red `#E74C3C`)
2. Press `Ctrl+K` → select **code-review**

**Critical:** Code-Reviewer has `write: false` and `edit: false` — it physically
cannot modify the code it reviews. This is enforced by OpenCode's permission
system at the OS level, not just via instructions.

### Code Review Pass

The `code-review` command injects and auto-runs:

```bash
RUN git diff main...HEAD --stat
# 14 files changed, 487 insertions(+)

RUN git log main..HEAD --oneline
# (verifies 7 conventional commits, one per plan step)
```

Then for each changed file:
1. Check against coding standards in `AGENTS.md`
2. Compare changes to `docs/plans/0042-password-reset.md`
3. Verify test coverage — all acceptance criteria covered?
4. Verify `CHANGELOG.md` updated
5. Validate conventional commit messages

**Structured Report:**

```
## Code Review: Password Reset (#42)

### Blockers
(none)

### Warnings
- W1: token-service.ts L18 — add explicit return type to generateResetToken()
- W2: forgot-password.handler.ts L45 — magic number 5; extract to config

### Notes
- ✅ All 6 plan steps implemented as specified
- ✅ CHANGELOG.md updated
- ✅ Conventional commits followed
- ✅ No TODO/FIXME comments
- ✅ Coverage: 94% on new code
- ✅ All acceptance scenarios passing

Risk rating: low
```

### Security Audit Pass

The `code-review` command says "Then proceed directly to security-audit mode,"
so the Code-Reviewer automatically continues. Alternatively:
`Ctrl+K` → select **security-audit**

The `security-audit` command auto-runs:

```bash
RUN git diff main...HEAD
```

Then checks for:
- Hardcoded secrets, API keys, credentials
- SQL injection, XSS, input validation gaps
- Auth/authz logic issues
- Dependency CVEs (lock files)
- Output encoding gaps

**Security Report (appended to code review):**

```
## Security Audit: Password Reset (#42)

### Critical/High (BLOCKERS)
(none)

### Medium (must address)
- M1: crypto.timingSafeEqual confirmed in use ✅
- M2: Password validated before hashing ✅ (existing middleware)

### Low (advisory)
- L1: Add audit logging for reset events — follow-up issue recommended

### Dependency Scan
- No new dependencies. Node.js crypto built-in — no CVEs.

### Secrets Check
- ✅ No hardcoded secrets found.

Risk rating: low
```

### Human Gate

Engineer reviews Code-Reviewer's combined findings:
- Addresses W1, W2 (or accepts as advisory)
- Creates follow-up issue for L1

**PR Description** (from `.github/PULL_REQUEST_TEMPLATE.md`):

```markdown
## Summary
Add password reset: forgot-password + reset-password endpoints with hashed
opaque tokens, email templates, rate limiting, session invalidation.

## Linked Issue
Closes #42

## References
- Spec: docs/specs/0042-password-reset.md
- Plan: docs/plans/0042-password-reset.md
- ADR: docs/research/0043-hashed-opaque-tokens.md

## Test Results
- Unit: ✅ 12 passed, 0 failed
- Integration: ✅ 4 passed, 0 failed
- Acceptance: ✅ 6 scenarios passed, 0 failed
- Coverage delta: +2.3% (new code: 94%)

## Changelog
Updated: Yes
```

**Engineer approves and merges** (rebase-merge — squash forbidden):

```bash
git checkout main
git merge --ff-only feat/42-password-reset
git push origin main
git branch -d feat/42-password-reset
```

---

## Phase 8: Documentation & Release

**Agent:** Release  
**Command:** `Ctrl+K` → `documentation` then `deployment`

### How to Invoke

1. Press `Tab` to cycle to the **Release** agent (purple `#8E44AD`)
2. Press `Ctrl+K` → select **documentation**

**Note:** Release agent has `bash: ask` — every shell command requires human
confirmation before executing. This prevents accidental deployments.

### Documentation Pass

The `documentation` command auto-runs:

```bash
RUN git diff main...$(git merge-base main HEAD) --name-only
```

Then:
1. Updates `README.md` — adds "Password Reset" to API features
2. Regenerates API docs if endpoints changed
3. `RUN cat docs/research/INDEX.md` and updates with ADR-0043
4. Verifies `CHANGELOG.md` is accurate

```bash
# Human confirms each RUN via bash: ask
git add README.md docs/research/INDEX.md docs/api/
git commit -m "docs(auth): update documentation for password reset #42"
```

### Deployment Pass

`Ctrl+K` → select **deployment**

The `deployment` command auto-runs:

```bash
RUN git log --oneline -5
# (human confirms — bash: ask)

RUN cat .github/workflows/*.yml 2>/dev/null || echo "No CI workflows found"
# (human confirms — bash: ask)
```

Then verifies:
1. CI/CD picks up the merged change
2. No test structure changes requiring CI updates
3. Environment variables — nothing missing or stale
4. No new services or deployment targets needed

```
# Pipeline status:
# - lint ✅, unit tests ✅, integration ✅, acceptance ✅
# - Coverage threshold met ✅
# - Migration included ✅
# Deployment: staging ✅ → production ✅
```

No infrastructure changes → no additional approval needed beyond `bash: ask` prompts.  
Issue #42 closed. Board: **In Review** → **Done**.

---

## Phase 9: Retrospective & Metrics

**Actor:** Human (with Release agent monitoring data)

### Metrics Captured

| Metric | Value |
|--------|-------|
| Cycle time (issue → merge) | 3 days |
| Research | 2 hours |
| Spec + ADR | 3 hours |
| Planning | 1 hour |
| Test scaffolding | 1 hour |
| Implementation | 6 hours |
| Review | 2 hours |
| Docs + deploy | 1 hour |
| Revision cycles | 0 |
| Plan deviations | 0 |
| Coverage delta | +2.3% |
| Commits | 7 (+1 post-merge) |
| Files changed | 15 |
| Lines added | 487 |

### Lessons Learned → `tasks/lessons.md`

- Research caught OWASP guidelines early — prevented JWT design revision.
- Dedicated `password_resets` table scales for future token features.
- Rate limit config should be centralized — follow-up issue created.
- OpenCode's `bash: ask` on Release agent added useful friction before deploy.

### AGENTS.md Update

```markdown
# Added to Domain Knowledge → Project-Specific Conventions:
- Password reset tokens: opaque, CSPRNG-generated, SHA-256 hashed,
  stored in password_resets table (see ADR-0043)
- All token comparisons must use constant-time comparison
```

---

## The Artifact Chain

```
Issue #42
  └─→ docs/research/0042-password-reset.md         (Ctrl+K → research-topic)
       └─→ docs/specs/0042-password-reset.md        (Ctrl+K → write-spec)
       └─→ docs/research/0043-hashed-opaque-tokens.md  (Ctrl+K → write-spec)
            └─→ docs/plans/0042-password-reset.md   (Ctrl+K → write-plan)
                 └─→ tests/ (failing)               (Builder: Ctrl+K → test-first)
                      └─→ src/ (passing)            (Builder: Ctrl+K → implement + refactor)
                           └─→ PR #87               (Code-Reviewer: Ctrl+K → code-review + security-audit)
                                └─→ main            (Human: merge)
                                     └─→ docs/      (Release: Ctrl+K → documentation)
                                          └─→ prod  (Release: Ctrl+K → deployment)
```

---

## Copilot vs OpenCode: Key Differences

| Aspect | Copilot (VS Code) | OpenCode (Terminal) |
|--------|--------------------|---------------------|
| Agent switching | Agent picker dropdown | `Tab` to cycle |
| Command invocation | `/slash-command` in chat | `Ctrl+K` → command picker |
| Phases 2–4 | Agent mode + Plan mode (built-in) | Default agent + commands |
| Phases 5–8 | @builder, @code-reviewer, @release | Builder, Code-Reviewer, Release |
| Permission enforcement | `tools:` scoping in `.agent.md` | `write:`, `edit:`, `bash:` flags |
| Reviewer write-block | No `editFiles` tool | `write: false`, `edit: false` |
| Release shell safety | Instruction-based | `bash: ask` (OS-level prompt) |
| Config location | `.github/agents/` + `.github/prompts/` | `.opencode/agents/` + `.opencode/commands/` |
| Command auto-runs | Slash command sets instructions | Commands include `RUN` directives |

Both tools produce identical artifacts through the same 9-phase SDLC. The difference
is interaction model and permission enforcement mechanism.
