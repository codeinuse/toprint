# Research: AGENTS.md Best Practices

**Date:** 2026-02-25
**Status:** Complete
**Question:** What are evidence-backed best practices for authoring AGENTS.md files to maximise agent effectiveness while minimising inference cost and context overhead?

## Summary

Two peer-reviewed papers published in early 2026 resolve the AGENTS.md debate empirically: human-written files containing only non-discoverable information reduce agent runtime by ~29 % and output token consumption by ~17 % (Lulla et al.); auto-generated or bloated files reduce task success by 2–3 % while inflating inference cost by >20 % (ETH Zurich). The actionable conclusion is to treat every line in AGENTS.md as a non-discoverable codebase fact — tooling gotchas, naming landmines, non-obvious commands — and delete everything an agent can find by listing directories or reading existing docs. The current repo AGENTS.md contains several sections (directory structure, generic code style) that fail this filter and should be pruned. The recommended path forward is a refined human-authored monolithic file in the short term, with a hierarchical scoped-context architecture as the long-term target once tooling catches up.

## Current State

The project maintains a single root-level [AGENTS.md](../../AGENTS.md) with six sections:

| Section | Content | Discoverable? |
|---------|---------|--------------|
| 1 — Agent Mindset | Behavioural rules for agent persona | Partially — tone/escalation rules are non-discoverable |
| 2 — Required Workflow | Commands, post-change checklist | Non-discoverable (tool choices, flags) |
| 3 — Repository Structure | Directory table | **Fully discoverable** — an agent lists dirs in the first tool call |
| 4 — Development Rules | Code style, engineering limits, Git discipline | Mostly discoverable from linter config and existing code |
| 5 — Domain Knowledge | Project-specific gotchas | Non-discoverable — this is the high-value section |
| 6 — Escalation & Self-Improvement | When to stop, lessons loop | Non-discoverable |

Sections 3 and most of 4 are candidates for removal per the research findings. The modular `rules/` files linked from section 4 add further context surface area that compounds the overhead on every agent invocation.

## Options

### Option A: Auto-generated via `/init`

- **How it works:** Run the agent's built-in `/init` command; it scans the repo and writes a comprehensive AGENTS.md.
- **Pros:**
  - Zero effort to generate
  - Covers the full repo surface at a point in time
- **Cons:**
  - 100 % of Sonnet-class model outputs contain codebase overviews — content the agent rediscovers anyway
  - ETH Zurich: LLM-generated files reduced task success by 2–3 % vs. no file
  - Cost overhead >20 % per run; compounds heavily in CI/CD pipelines
  - Stale within weeks; no maintenance mechanism
- **Effort:** Low (to create), High (to maintain correctly)
- **Confidence:** Low — empirically inferior to no file at all when repo has existing docs

### Option B: Human-written monolithic file (refined current approach)

- **How it works:** Keep a single root AGENTS.md, but apply a strict "non-discoverable" filter: every line must represent information the agent cannot find by reading the codebase, READMEs, or config files.
- **Pros:**
  - Lulla et al.: human-authored files cut median runtime 28.64 % and output tokens 16.58 %
  - Low tooling overhead — works with every agent today
  - Pruned file reduces anchoring bias and "lost in the middle" degradation
  - Maintainable by the team without new infrastructure
- **Cons:**
  - Static — instructions load identically for a CSS tweak and a security patch
  - Single file conflates concerns across all modules and task types
  - Requires ongoing discipline to prune lines as codebase evolves
  - No automated staleness detection
- **Effort:** Low (ongoing editorial discipline)
- **Confidence:** High — directly supported by Lulla et al. with measurable efficiency gains

### Option C: Hierarchical, dynamically-loaded context files + maintenance sub-agent

- **How it works:** Three-layer architecture — (1) root protocol file as a routing document only, (2) scoped persona/skill files loaded on demand per task type, (3) a maintenance sub-agent whose sole job is keeping context files accurate.
- **Pros:**
  - ACE framework (ICLR 2026): dynamic context loading outperformed static approaches by 12.3 % on agent benchmarks
  - Each task receives only relevant context — eliminates cross-concern noise
  - Maintenance sub-agent prevents documentation rot
  - Bounds total context per task regardless of project size
- **Cons:**
  - No major coding agent exposes lifecycle hooks needed to implement cleanly today
  - Requires non-trivial infrastructure: routing logic, sub-agent wiring, context evaluation
  - Higher initial setup cost; approximations via manual sub-agents are brittle
  - ETH Zurich notes this architecture has not yet been empirically tested end-to-end
- **Effort:** High
- **Confidence:** Medium — theoretically well-motivated but empirically unvalidated in this exact form

## Recommendation

**Option B (refined)** — Keep the human-written AGENTS.md but apply the non-discoverable filter aggressively before the next agent session. Remove Section 3 (Repository Structure) entirely; strip generic code-style rules from Section 4 that any agent can infer from the linter config and existing code; keep only tooling commands with non-obvious flags, project-specific gotchas, escalation triggers, and the skills/rules routing pointers. Treat the file as a diagnostic of codebase friction: when a line is added, investigate and fix the underlying issue, then delete the line. Option C is the correct long-term architecture; revisit when agent tooling exposes scoped context loading natively.

## Risks & Unknowns

- **Model trajectory**: Every generation of LLMs requires fewer explicit instructions as codebase navigation improves. Lines that are essential today may be pure overhead in 6 months; schedule periodic reviews.
- **Anchoring bias**: Mentioning any technology or pattern biases the agent toward it for the entire session — even deprecated ones. Stale content is actively harmful, not just neutral noise (Liu et al. "Lost in the Middle", 2024).
- **Documentation rot**: ETH Zurich used fresh context files and still found degraded performance; real-world files that are months old perform materially worse.
- **Measurement gap**: The Lulla paper measures efficiency only, not correctness. A faster, cheaper agent that produces wrong code is not a win. Combine efficiency metrics with task success rates.
- **Untested architecture**: Neither 2026 paper evaluated a properly hierarchical, dynamically-loaded context system. The 12.3 % gain from ACE was on a different benchmark; direct comparability is uncertain.
- **Prompt optimisation gap**: Arize AI's automated optimisation loop yielded +5.19 % cross-repo accuracy by discovering what the model actually needs vs. what developers think it needs — the two often differ. Manual AGENTS.md assumptions should be held loosely and tested empirically where possible.

## Next Steps

1. **Audit and prune AGENTS.md**: Apply the non-discoverable filter line-by-line; open a PR removing Section 3 and discoverable items from Section 4. Target: reduce file by ~40 %.
2. **Create ADR**: Document the decision to prefer lean, human-authored AGENTS.md with the non-discoverable filter as the acceptance criterion (`docs/research/0001-agents-md-authoring-strategy.md`).
3. **Add maintenance cadence**: Add a recurring task to `tasks/lessons.md` — on any AGENTS.md addition, record the triggering failure and investigate whether the underlying code issue can be fixed instead.
4. **Instrument cost baseline**: Before pruning, capture a baseline of agent runtime and token consumption on a representative task set so the improvement can be measured, not assumed.
5. **Monitor tooling**: Track whether Copilot, Claude Code, or Cursor expose lifecycle hooks for scoped context loading; re-evaluate Option C when available.

## References

- Lulla et al. (2026). *On the Impact of AGENTS.md Files on the Efficiency of AI Coding Agents.* ICSE JAWs 2026. [arXiv:2601.20404](https://arxiv.org/abs/2601.20404)
- Gloaguen et al. (2026). *Evaluating AGENTS.md: Are Repository-Level Context Files Helpful for Coding Agents?* ETH Zurich. [arXiv:2602.11988](https://arxiv.org/abs/2602.11988)
- Addy Osmani (2026). *Stop Using /init for AGENTS.md.* [addyosmani.com](https://addyosmani.com/blog/agents-md/)
- Arize AI / Jindal (2025). *CLAUDE.md: Best Practices Learned from Optimizing Claude Code with Prompt Learning.* [arize.com](https://arize.com/blog/claude-md-best-practices-learned-from-optimizing-claude-code-with-prompt-learning/)
- ACE Framework (2025). *Agentic Context Engineering.* ICLR 2026. [arXiv:2510.04618](https://arxiv.org/abs/2510.04618)
- Liu et al. (2024). *Lost in the Middle: How Language Models Use Long Contexts.* TACL.
