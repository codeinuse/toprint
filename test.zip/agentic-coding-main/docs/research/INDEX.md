# Research & ADR Index

| ID | Title | Date | Status |
|----|-------|------|--------|
| [0001](0001-agents-md-best-practices.md) | AGENTS.md Best Practices | 2026-02-25 | Complete |
