# Refactoring Patterns & Engineering Philosophy

Reference material for engineering best practices. AGENTS.md has the rules — this file explains the *why* and *how*.

## Design Principles

### Kent Beck's Four Rules of Simple Design (priority order)

1. **Passes the Tests** — Functionality first
2. **Reveals Intention** — Names explain *why*, not just *what*
3. **No Duplication (DRY)** — Write it twice, refactor to abstraction
4. **Fewest Elements** — Remove classes/functions that serve no purpose

### Martin Fowler's Refactoring

- **Rule of Three** — Refactor only after doing the same thing three times. No premature abstraction (YAGNI).
- **Function Size** — Functions do one thing. Sections separated by whitespace should be their own functions.
- **Extract Method** → name describes *what*, body describes *how*

### Sandi Metz's Rules

- Classes ≤ 100 lines (≤ 200 for orchestrators with justification)
- Methods ≤ 5 lines (≤ 15 acceptable for complex logic)
- ≤ 4 parameters per method
- **SLAP** (Single Level of Abstraction) — High-level policy should not mix with low-level details
- **Small Interfaces** — Many small, specific interfaces over one "God Class"

### SOLID Principles

- **S**ingle Responsibility — One reason to change per class/module
- **O**pen/Closed — Open for extension, closed for modification
- **L**iskov Substitution — Subtypes must be substitutable for base types
- **I**nterface Segregation — Many specific interfaces > one general
- **D**ependency Inversion — Depend on abstractions, not concretions

---

## Refactoring Patterns

- **Extract Method** → name describes *what*, body describes *how*
- **Replace Conditional with Polymorphism**
- **Compose Method** → same level of abstraction per function
- **Replace Magic Numbers with Named Constants**
- **Introduce Parameter Object** → when ≥ 3 related params travel together
- **Pull Up / Push Down** → move methods to the appropriate abstraction level

---

## Batch Small Modules (Efficiency Principle)

When decomposing a monolith, batch extractions of **independent leaf modules** into a single phase:

- **Independent**: No dependencies between the extracted modules
- **Leaf**: No internal imports from the parent module (only external dependencies)
- **Small**: Each module < 150 lines

This reduces commit overhead while maintaining atomic, reviewable changes.

---

## Testing Philosophy (Kent Beck)

- Red → Green → Refactor
- Test behavior, not implementation
- One assertion per test (logical, not literal)
- Tests are documentation
- **Test First**: Propose test case *before* writing implementation for new features
- **Unit Tests**: Must be isolated. Prefer in-memory replacements over mocks.
- **Integration Tests**: Essential for service boundaries. Ensure I/O shapes match expected schema.

---

## Dead Code Detection (Post-Refactor Hygiene)

After extracting modules, audit for unused code:

1. **Unused Types**: Defined but never instantiated
2. **Test-Only Functions**: Called only in tests, not production → candidate for removal or `_` prefix
3. **Documented-Only Functions**: In API docs but never called → remove or deprecate
4. **Orphaned Imports**: Needed pre-refactor, now dead

Tools: `grep -r "function_name"` to find usages; if only in definition + tests → candidate for removal.

---

## Facade API Design (Public Interface Hygiene)

When a class serves as a facade over collaborators:

1. **Minimal Surface**: Only expose methods actually used by callers
2. **Deprecation Path**: Mark unused public methods with deprecation warnings before removal
3. **Internal vs Public**: Prefix truly internal methods with `_` to signal non-public
4. **Backward Compat Period**: Keep deprecated methods for 1 release, then remove

---

*This file is reference material. Size limits above are the authoritative thresholds.*
