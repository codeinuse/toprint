# Code Review Rules

> Standards for PR review, Definition of Done, and merge requirements.

---

## Definition of Done

A piece of work is **Done** when **all** items are true. Agents verify before opening PR. Humans verify before merging.

### Code
- [ ] All plan steps implemented
- [ ] Code passes linting and formatting (zero warnings)
- [ ] No TODO/FIXME/placeholder comments in changed code
- [ ] No hardcoded secrets, credentials, or PII

### Tests
- [ ] All unit tests pass
- [ ] All integration tests pass
- [ ] All Gherkin acceptance scenarios pass
- [ ] Unit coverage ≥ 80% for new/changed code
- [ ] Every integration boundary has happy-path + failure-path tests
- [ ] No tests skipped or commented out

### Artifacts
- [ ] `CHANGELOG.md` updated for user-facing changes
- [ ] ADRs in `Accepted` status (if applicable)
- [ ] Spec updated if implementation deviated (with reasoning)
- [ ] API docs regenerated (if applicable)

### Git
- [ ] Branch up to date with `main`
- [ ] Conventional commit messages
- [ ] One commit per plan step (no stray or merge commits)
- [ ] `git diff --stat` reviewed — no unintended changes

## Reviewer Checklist

**Agent reviewer checks:**
- Coding standards (formatting, naming, imports)
- Plan adherence (does implementation match approved plan?)
- Test coverage thresholds met
- Conventional commits validated
- CHANGELOG.md updated
- No secrets or PII in diff

**Agent reviewer CANNOT:** approve or merge. That is human-only.

**Human reviewer checks:**
- Intent correctness — does the change solve the right problem?
- Design coherence — does it fit the existing architecture?
- Subtle bugs — edge cases, off-by-ones, concurrency issues
- Security implications

## PR Description Requirements

Every PR must include:

```markdown
## Summary
[Brief description of changes]

## Linked Issue
Closes #XXXX

## References
- Spec: docs/specs/XXXX-feature.md
- Plan: docs/plans/XXXX-feature.md
- ADR(s): docs/research/XXXX-decision.md

## Test Results
- Unit: ✅ XX passed, 0 failed
- Integration: ✅ XX passed, 0 failed
- Acceptance: ✅ XX scenarios passed
- Coverage delta: +X.X%

## Changelog
Updated: Yes / No
```

## Branch & Merge Rules

- **Branches**: `feat/<topic>` or `fix/<topic>` for non-trivial changes. Direct `main` commits only for single-file fixes under 10 lines.
- **Rebase-merge only.** No squash, no merge commits.
- Commit history (one per plan step) is the audit trail. Squashing destroys it.
- **Human merges.** Always. Agents never merge their own work.
- All CI checks must pass before merge is allowed.
- Branch deleted after merge.

---

*If a PR doesn't meet Definition of Done, it doesn't merge. No exceptions.*
