# Security Rules

> Load these rules when touching auth, crypto, secrets, permissions, or user data.

---

## Secrets Management

- **NEVER** hardcode credentials (API keys, passwords, tokens, connection strings).
- **NEVER** log or print secrets, tokens, or PII — not even in debug mode.
- **NEVER** commit `.env` files. Use `.env.example` for structure without values.
- Load all secrets from environment variables. No fallback defaults for credentials.
- Secrets must not appear in error messages, stack traces, or commit history.

## Input Validation

- Validate **all** external input at the boundary (API handlers, file parsers, CLI args).
- Output-encode for context: HTML escaping, SQL parameterization, shell escaping.
- SQL via parameterized queries or ORM only — **NEVER** string concatenation.
- Reject unexpected input types early. Fail fast, fail loud.

## Authentication & Authorization

- [customize] Auth mechanism: [e.g., OAuth2, JWT, session-based, API keys]
- Passwords hashed with bcrypt or Argon2. **NEVER** plaintext, MD5, or SHA-256 alone.
- Rate limiting on authentication endpoints.
- CSRF protection on state-changing endpoints.
- Principle of least privilege for all service accounts and API tokens.

## Dependency Security

- CVE scans run on every PR. **Critical/high findings block merge.**
- No dependencies with unpatched known vulnerabilities.
- License compliance checked — no copyleft without explicit ADR approval.
- Pin all dependency versions in lock files.
- Review new dependencies for maintenance status and security track record.

## Sensitive Environment Variables

```bash
# [customize] List your sensitive env vars here
# DATABRICKS_TOKEN, AZURE_OPENAI_API_KEY, DATABASE_URL, etc.
```

## Config Protection

- **NEVER** weaken linter, formatter, or static analysis configs to silence errors — fix the code instead.
- Do not disable rules, widen ignore patterns, or lower thresholds unless an ADR justifies it.
- If a lint/format rule conflicts with project conventions, escalate — don't silently relax the config.
- Treat `.eslintrc`, `biome.json`, `.prettierrc`, `pyproject.toml [tool.*]`, `golangci.yml`, and similar config files as **protected** — changes require human review.

## Escalation

Any change touching authentication, authorization, encryption, or secrets management
**requires human review** — no exceptions. Tag `@human-review-needed` on the PR.

---

*If this file doesn't cover a security concern you've encountered, propose an amendment.*
