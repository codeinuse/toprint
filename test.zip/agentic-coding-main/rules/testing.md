# Testing Rules

> Standards for test-first development, coverage enforcement, and the test pyramid.

---

## TDD Workflow

1. **Red** — Write a failing test for the next piece of functionality.
2. **Green** — Write the minimum code to make it pass.
3. **Refactor** — Clean up without changing behavior.

Test commits must precede or accompany implementation commits on the same branch.
**NEVER** write tests after implementation as an afterthought.

## Test Pyramid

```
        /  Acceptance (Gherkin)  \     ← Few, slow, high-confidence
       /   Integration Tests      \    ← Moderate count, real dependencies
      /      Unit Tests             \  ← Many, fast, isolated
```

## Coverage Thresholds

| Layer | Minimum | Enforcement |
|-------|---------|-------------|
| **Unit** | 80% line coverage | CI blocks PR if not met |
| **Integration** | All external boundaries | 1 happy-path + 1 failure-path per boundary |
| **Acceptance** | Every Gherkin scenario | Step definitions must exist and pass |

## BDD / Gherkin

- Acceptance criteria in specs **are** Gherkin scenarios. No translation step.
- Format: `Given/When/Then` — maps directly to setup/action/assertion.
- One scenario per test path (happy + edge cases + error conditions).
- Feature files live in `tests/acceptance/features/`.
- Scenarios must be testable and unambiguous — no implementation details.

```gherkin
Feature: [Feature Name]

  Scenario: Happy path
    Given [precondition]
    When [action]
    Then [expected outcome]

  Scenario: Error case
    Given [precondition]
    When [invalid action]
    Then [error handling]
```

## Test Quality Rules

- **Test behavior, not implementation.** Tests should survive refactors.
- **One logical assertion per test.** Test names describe the behavior being verified.
- **No skipped, pending, or commented-out tests** without an approved ADR.
- **No mocks for integration tests.** Use real (or containerized) dependencies.
- **Deterministic tests only.** No flaky tests depending on timing, order, or external state.
- **Fast unit tests.** If a unit test takes >1 second, it's probably an integration test.

## Proposing Tests

For new features, propose test cases **before** implementation:
1. List the scenarios (happy path, edge cases, error conditions)
2. Get confirmation from human or plan
3. Write failing tests
4. Implement to green

---

*Agents are exceptionally good at TDD — they hold full context of test, spec, and codebase simultaneously.*
