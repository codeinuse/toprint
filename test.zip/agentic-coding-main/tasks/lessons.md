# Lessons Learned

Use this file as the repo's lessons log. Keep entries additive, concise, and reusable.

## Delta Format

- One lesson per bullet.
- Format: `- [YYYY-MM-DD] [area] signal -> action (repeat: N, confidence: L|M|H, scope: repo|global, promote: no|yes)`
- `signal` captures the trigger: failed test, review finding, user correction, or success worth reusing.
- `action` states the concrete behavior to repeat or avoid next time.
- `confidence`: **L** = tentative (observed once), **M** = moderate (observed 2–3 times), **H** = proven (repeated pattern or user-confirmed).
- `scope`: **repo** = applies to this project only, **global** = applies across all projects.
- Increment `repeat` when the same lesson recurs; upgrade `confidence` as evidence accumulates.
- Set `promote: yes` only when the lesson is **H confidence** and ready to move into `AGENTS.md` or `rules/`.

## Lessons

- [2026-03-17] [workflow] Unrelated workspace changes can slip into a commit -> restore or leave untouched files outside the agreed scope before staging (repeat: 1, confidence: M, scope: global, promote: no)
- [2026-03-17] [context] Large prompt rewrites lose durable detail -> capture incremental deltas in lessons instead of rewriting whole instructions (repeat: 1, confidence: H, scope: global, promote: yes)
- [2026-03-17] [instructions] Framework jargon can confuse agents -> prefer plain workflow language unless the term is already defined in repo rules (repeat: 1, confidence: M, scope: global, promote: yes)
- [2026-03-17] [orchestration] Generic workflow steps are too implicit -> name the exact skills and best-fit agents to invoke in orchestration commands (repeat: 1, confidence: M, scope: global, promote: yes)
- [2026-03-17] [orchestration] Parallel subagents need synthesis, not just fan-out -> use a critique step after each 5-subagent round before acting (repeat: 1, confidence: M, scope: global, promote: yes)

